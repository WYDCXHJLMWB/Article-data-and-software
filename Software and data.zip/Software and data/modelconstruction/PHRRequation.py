# -*- coding: utf-8 -*-
"""
Created on Thu Jan 22 16:40:51 2026

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
Generate Ridge model linear formula - Based on unstandardized original features
"""
import os
import numpy as np
import pandas as pd
import joblib
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score

# ---------- 1. Load model and features ----------
MODEL_PKL = "phrr_model1.pkl"
FEAT_CSV = 'selected_features.csv'

print("=" * 80)
print("Ridge Linear Model Formula Generation (Unstandardized Version)")
print("=" * 80)

# Load model
ridge_model = joblib.load(MODEL_PKL)
print(f"Loaded model: {MODEL_PKL}")

# Load feature list
train_cols = pd.read_csv(FEAT_CSV)['feature_name'].tolist()
TARGET_COL = 'PHRR（Kw/m2）'

print(f"Loaded {len(train_cols)} selected features")
print(f"Target variable: {TARGET_COL}")

# ---------- 2. Display model information ----------
print("\n" + "=" * 80)
print("Model Parameter Information")
print("=" * 80)

print(f"Model type: {type(ridge_model).__name__}")
print(f"Regularization parameter alpha: {ridge_model.alpha}")
print(f"Intercept included: {ridge_model.fit_intercept}")
print(f"Number of iterations: {ridge_model.n_iter_}")
print(f"Number of features: {ridge_model.n_features_in_}")

# ---------- 3. Get model coefficients ----------
intercept = ridge_model.intercept_
coefficients = ridge_model.coef_

print(f"\nIntercept: {intercept:.8f}")
print(f"Number of coefficients: {len(coefficients)}")

# ---------- 4. Generate raw feature linear formula ----------
def generate_raw_formula(features, coefs, intercept, precision=6):
    """
    Generate raw feature linear formula (unstandardized)
    """
    formula_parts = []
    
    # Add intercept term
    if abs(intercept) > 1e-12:
        intercept_str = f"{intercept:+.{precision}f}"
        if intercept_str.startswith('+'):
            intercept_str = intercept_str[1:]  # Remove leading +
        formula_parts.append(intercept_str)
    
    # Add feature terms
    for i, (feature, coef) in enumerate(zip(features, coefs)):
        if abs(coef) > 1e-12:  # Only show non-zero coefficients
            # Format coefficient
            coef_str = f"{coef:+.{precision}f}"
            
            # Handle feature names
            if any(c in feature for c in [' ', '(', ')', '/', '-', '+', '*', '（', '）']):
                feature_display = f"({feature})"
            else:
                feature_display = feature
            
            formula_parts.append(f"{coef_str} × {feature_display}")
    
    # Build formula
    formula = "PHRR = " + " ".join(formula_parts)
    
    # Clean format: replace "+ -" with "- "
    formula = formula.replace("+ -", "- ")
    
    return formula

def generate_simplified_formula(features, coefs, intercept, precision=4, threshold=0.01):
    """
    Generate simplified formula, showing only important features
    threshold: Coefficient relative importance threshold (relative to maximum coefficient)
    """
    # Calculate coefficient absolute values
    abs_coefs = np.abs(coefs)
    max_abs_coef = np.max(abs_coefs)
    
    formula_parts = []
    
    # Add intercept term
    if abs(intercept) > 1e-12:
        intercept_str = f"{intercept:+.{precision}f}"
        if intercept_str.startswith('+'):
            intercept_str = intercept_str[1:]
        formula_parts.append(intercept_str)
    
    # Add important feature terms
    for i, (feature, coef) in enumerate(zip(features, coefs)):
        if abs(coef) / max_abs_coef >= threshold:  # Only show important features
            coef_str = f"{coef:+.{precision}f}"
            
            if any(c in feature for c in [' ', '(', ')', '/', '-', '+', '*', '（', '）']):
                feature_display = f"({feature})"
            else:
                feature_display = feature
            
            formula_parts.append(f"{coef_str} × {feature_display}")
    
    # Build formula
    formula = "PHRR ≈ " + " ".join(formula_parts)
    formula = formula.replace("+ -", "- ")
    
    return formula

# Generate formulas
raw_formula = generate_raw_formula(train_cols, coefficients, intercept, precision=8)
simplified_formula = generate_simplified_formula(train_cols, coefficients, intercept, 
                                                precision=6, threshold=0.05)

print("\n" + "=" * 80)
print("Complete Linear Model Formula (Raw Features, Unstandardized)")
print("=" * 80)
print(raw_formula)

print("\n" + "=" * 80)
print("Simplified Formula (Showing Important Features, 5% Threshold)")
print("=" * 80)
print(simplified_formula)

# ---------- 5. Create detailed coefficient table ----------
print("\n" + "=" * 80)
print("Detailed Coefficient Analysis Table")
print("=" * 80)

# Calculate statistics
abs_coefficients = np.abs(coefficients)
coef_sum = np.sum(abs_coefficients)
max_coef = np.max(abs_coefficients)
min_coef = np.min(abs_coefficients)

coeff_data = []
for i, (feature, coef, abs_coef) in enumerate(zip(train_cols, coefficients, abs_coefficients), 1):
    relative_importance = (abs_coef / coef_sum * 100) if coef_sum > 0 else 0
    
    coeff_data.append({
        'Index': i,
        'Feature': feature,
        'Raw Coefficient': coef,
        'Absolute Coefficient': abs_coef,
        'Relative Importance(%)': relative_importance,
        'Standardized Coefficient': coef / max_coef if max_coef > 0 else 0,
        'Effect Direction': 'Positive ↑' if coef > 0 else 'Negative ↓' if coef < 0 else 'No Effect',
        'Important': 'Yes' if abs_coef / max_coef >= 0.05 else 'No'
    })

coeff_df = pd.DataFrame(coeff_data)

# Sort by coefficient absolute value
coeff_df_sorted = coeff_df.sort_values('Absolute Coefficient', ascending=False).reset_index(drop=True)
coeff_df_sorted['Importance Rank'] = range(1, len(coeff_df_sorted) + 1)

# Show top 10 most important features
print("\nTop 10 Most Important Features (by coefficient absolute value):")
print("-" * 100)
top_features = coeff_df_sorted.head(10)

display_cols = ['Importance Rank', 'Feature', 'Raw Coefficient', 'Absolute Coefficient', 'Relative Importance(%)', 'Effect Direction']
for _, row in top_features.iterrows():
    print(f"{row['Importance Rank']:2d}. {row['Feature']:25s}: {row['Raw Coefficient']:12.8f} "
          f"(Absolute: {row['Absolute Coefficient']:8.6f}, Importance: {row['Relative Importance(%)']:5.1f}%, {row['Effect Direction']})")

print(f"\nIntercept: {intercept:.8f}")

# ---------- 6. Feature classification analysis ----------
print("\n" + "=" * 80)
print("Feature Classification Analysis")
print("=" * 80)

# Group by feature type
positive_features = [(f, c) for f, c in zip(train_cols, coefficients) if c > 0]
negative_features = [(f, c) for f, c in zip(train_cols, coefficients) if c < 0]
zero_features = [(f, c) for f, c in zip(train_cols, coefficients) if abs(c) < 1e-12]

print(f"Positive correlation features ({len(positive_features)}):")
for feature, coef in positive_features[:10]:  # Show only first 10
    print(f"  {feature:25s}: {coef:+.8f}")
if len(positive_features) > 10:
    print(f"  ... and {len(positive_features) - 10} more positive correlation features")

print(f"\nNegative correlation features ({len(negative_features)}):")
for feature, coef in negative_features[:10]:  # Show only first 10
    print(f"  {feature:25s}: {coef:+.8f}")
if len(negative_features) > 10:
    print(f"  ... and {len(negative_features) - 10} more negative correlation features")

if zero_features:
    print(f"\nNear-zero features ({len(zero_features)}):")
    for feature, coef in zero_features[:5]:  # Show only first 5
        print(f"  {feature:25s}: {coef:.8f}")

# ---------- 7. Load data to validate formula ----------
print("\n" + "=" * 80)
print("Formula Validation")
print("=" * 80)

# Simple validation: create some test data
print("Validating formula...")

# Use manually calculated predictions for validation
def predict_with_formula(X, coefs, intercept):
    """Calculate predictions using formula"""
    return np.dot(X, coefs) + intercept

# Create some test data
np.random.seed(42)
test_X = np.random.randn(5, len(train_cols)) * 10 + 50  # Simulate feature values

# Calculate using formula
test_y_formula = predict_with_formula(test_X, coefficients, intercept)

# Predict using model
test_y_model = ridge_model.predict(test_X)

print("\nTest Validation (first 5 samples):")
print("-" * 70)
print(f"{'Sample':<6} {'Formula Calculation':<15} {'Model Prediction':<15} {'Difference':<15}")
print("-" * 70)

for i in range(5):
    diff = abs(test_y_formula[i] - test_y_model[i])
    print(f"Sample{i+1:<5} {test_y_formula[i]:<15.8f} {test_y_model[i]:<15.8f} {diff:<15.8f}")

# Check overall difference
max_diff = np.max(np.abs(test_y_formula - test_y_model))
print(f"\nMaximum difference: {max_diff:.10f}")
if max_diff < 1e-8:
    print("Formula and model predictions match perfectly!")
else:
    print(f"Minor differences exist, but within acceptable range")

# ---------- 8. Save all results ----------
os.makedirs('results', exist_ok=True)

print("\n" + "=" * 80)
print("Saving Results")
print("=" * 80)

# Save formula to text file
with open('results/ridge_raw_formula.txt', 'w', encoding='utf-8') as f:
    f.write("=" * 80 + "\n")
    f.write("Ridge Linear Regression Model Formula (Unstandardized)\n")
    f.write("=" * 80 + "\n\n")
    
    f.write("Model Information:\n")
    f.write("-" * 80 + "\n")
    f.write(f"Model file: {MODEL_PKL}\n")
    f.write(f"Number of features: {len(train_cols)}\n")
    f.write(f"Target variable: {TARGET_COL}\n")
    f.write(f"Regularization parameter alpha: {ridge_model.alpha}\n")
    f.write(f"Intercept: {intercept:.10f}\n")
    f.write(f"Maximum coefficient absolute value: {max_coef:.10f}\n")
    f.write(f"Minimum coefficient absolute value: {min_coef:.10f}\n\n")
    
    f.write("Complete Linear Formula:\n")
    f.write("-" * 80 + "\n")
    f.write(raw_formula + "\n\n")
    
    f.write("Simplified Formula (5% threshold):\n")
    f.write("-" * 80 + "\n")
    f.write(simplified_formula + "\n\n")
    
    f.write("Detailed Coefficient Table:\n")
    f.write("-" * 80 + "\n")
    for _, row in coeff_df_sorted.iterrows():
        f.write(f"{row['Importance Rank']:2d}. {row['Feature']:30s}: {row['Raw Coefficient']:+.10f} "
                f"(Absolute: {row['Absolute Coefficient']:.8f}, Relative Importance: {row['Relative Importance(%)']:.2f}%, "
                f"Direction: {row['Effect Direction']}, Important: {row['Important']})\n")
    
    f.write(f"\nIntercept: {intercept:.10f}\n\n")
    
    f.write("Feature Classification Statistics:\n")
    f.write("-" * 80 + "\n")
    f.write(f"Positive correlation features: {len(positive_features)}\n")
    f.write(f"Negative correlation features: {len(negative_features)}\n")
    f.write(f"Near-zero features: {len(zero_features)}\n\n")
    
    f.write("Formula Validation Results:\n")
    f.write("-" * 80 + "\n")
    f.write(f"Test samples: 5\n")
    f.write(f"Maximum prediction difference: {max_diff:.10f}\n")
    f.write("Formula and model predictions match perfectly\n" if max_diff < 1e-8 else "Minor differences exist\n")

# Save coefficient table
coeff_df_sorted.to_csv('results/ridge_raw_coefficients.csv', index=False, encoding='utf-8-sig', float_format='%.10f')

# Save important features
top_features.to_csv('results/ridge_top_features.csv', index=False, encoding='utf-8-sig', float_format='%.8f')

# Generate LaTeX formula
with open('results/ridge_formula_latex_raw.tex', 'w', encoding='utf-8') as f:
    f.write("% Ridge regression model formula (unstandardized)\n")
    f.write("% Generation time: {}\n".format(pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')))
    f.write("% Number of features: {}\n\n".format(len(train_cols)))
    
    f.write("\\begin{equation}\n")
    f.write("\\text{PHRR} = ")
    
    # Handle intercept
    latex_parts = []
    if abs(intercept) > 1e-12:
        latex_parts.append(f"{intercept:.4f}")
    
    # Handle feature terms
    for feature, coef in zip(train_cols, coefficients):
        if abs(coef) > 1e-12:
            # Escape special characters in feature names
            feature_tex = feature
            feature_tex = feature_tex.replace('_', '\\_')
            
            # If there are special characters, wrap with \text{}
            if any(c in feature for c in ['(', ')', '-', '+', '*', '/', '（', '）']):
                feature_tex = f"\\text{{{feature}}}"
            
            sign = "+" if coef >= 0 else "-"
            coef_abs = abs(coef)
            
            latex_parts.append(f"{sign} {coef_abs:.4f} \\times {feature_tex}")
    
    f.write(" ".join(latex_parts))
    f.write("\n\\end{equation}\n")

print("Complete formula saved to: results/ridge_raw_formula.txt")
print("Coefficient table saved to: results/ridge_raw_coefficients.csv")
print("Important features saved to: results/ridge_top_features.csv")
print("LaTeX formula saved to: results/ridge_formula_latex_raw.tex")

# ---------- 9. Final notes ----------
print("\n" + "=" * 80)
print("Important Notes")
print("=" * 80)

print("\n1. Since features were not standardized during modeling, this formula uses raw feature values.")
print("2. Coefficient magnitudes are affected by feature scales and cannot be directly compared for importance.")
print("3. For features with different scales, large-value features typically have smaller coefficients.")
print("\nFor example:")
print("  - PAPP unit might be g, with value range 0-100")
print("  - Some ratio features have range 0-1")
print("  - PAPP coefficient 0.001 might be more important than ratio feature coefficient 0.1")

print("\n4. To compare feature importance, it is recommended to:")
print("   a) Standardize features and retrain")
print("   b) Calculate standardized coefficients: coefficient × feature standard deviation")
print("   c) Use relative importance metrics")

print("\n5. Formula usage instructions:")
print("   - Substitute feature values into corresponding variables in the formula")
print("   - Calculated result is the predicted PHRR value")
print("   - Ensure feature units match those used during training")

print("\n" + "=" * 80)
print("Completed!")
print("=" * 80)