# -*- coding: utf-8 -*-
"""
PHRR Model Evaluation Program (Numerical Features Only) - Without Standardization
Improved Version: Ensure all models (regardless of quality) are used for prediction
Removed SVR model to avoid direct use of validation set for model selection
Added 5-fold prediction and test set prediction output
Added ridge regression formula output
Ensured all models participate in validation set prediction
Fixed version: Ensure complete output of all prediction data
"""

import numpy as np
import pandas as pd
import joblib  
import os       
from datetime import datetime  
from sklearn.preprocessing import RobustScaler
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score, KFold, cross_val_predict
from sklearn.metrics import r2_score, mean_squared_error  
from scipy.stats import pearsonr  
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.neural_network import MLPRegressor
from xgboost import XGBRegressor
import matplotlib.pyplot as plt
import warnings
from deap import base, tools, creator, algorithms
import random
import time  
from pathlib import Path
from sklearn.base import clone
import json

warnings.filterwarnings('ignore')
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# -------------------------- Initialize Experiment Directory --------------------------
def init_experiment_dir():
    experiment_time = datetime.now().strftime("%Y%m%d_%H%M%S")
    experiment_dir = f"PHRR_experiment_{experiment_time}"
    os.makedirs(experiment_dir, exist_ok=True)
    os.makedirs(os.path.join(experiment_dir, "models"), exist_ok=True)  
    os.makedirs(os.path.join(experiment_dir, "data_splits"), exist_ok=True)  
    os.makedirs(os.path.join(experiment_dir, "feature_selection"), exist_ok=True)  
    os.makedirs(os.path.join(experiment_dir, "scalers"), exist_ok=True)  
    os.makedirs(os.path.join(experiment_dir, "logs"), exist_ok=True)  
    os.makedirs(os.path.join(experiment_dir, "predictions"), exist_ok=True)
    os.makedirs(os.path.join(experiment_dir, "all_models_predictions"), exist_ok=True)  # New: All models prediction directory
    os.makedirs(os.path.join(experiment_dir, "regression_formulas"), exist_ok=True)  # Ridge regression formula directory
    return experiment_dir

# -------------------------- 1. Data Loading (Keep only numerical features, remove one-hot encoding) --------------------------
def load_data(random_seed):
    dataset = pd.read_excel("PHRRa1.xlsx")
    target_col = 'PHRR（Kw/m2）'
    
    # Remove NO serial column
    if 'NO' in dataset.columns:
        initial_count = len(dataset)
        dataset = dataset.drop(columns=['NO'], errors='ignore')
        print(f"⚠️ Detected NO serial column, removed (Original sample count: {initial_count}, After removal: {len(dataset)})")
    else:
        print(f"Original data sample count: {len(dataset)}")
    
    # Target value range filtering
    clean_mask = (dataset[target_col] > 10) & (dataset[target_col] <= 1000)
    dataset = dataset[clean_mask].copy().reset_index(drop=True)
    print(f"Sample count after target value filtering: {len(dataset)}")
    
    # Keep only numerical features (remove all non-numerical columns, no one-hot encoding needed)
    numeric_cols = dataset.select_dtypes(include=[np.number]).columns.tolist()
    if target_col in numeric_cols:
        numeric_cols.remove(target_col)
    # Filter non-numerical columns (completely remove matrix and other categorical columns)
    dataset = dataset[numeric_cols + [target_col]].copy()
    print(f"Only numerical features kept, feature list: {numeric_cols}")
    
    # IQR outlier filtering (only for numerical features)
    pre_iqr_count = len(dataset)
    for col in numeric_cols:
        Q1 = dataset[col].quantile(0.25)
        Q3 = dataset[col].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        dataset = dataset[(dataset[col] >= lower_bound) & (dataset[col] <= upper_bound)].copy().reset_index(drop=True)
    
    print(f"Sample count after IQR outlier filtering: {len(dataset)} (Filtered {pre_iqr_count - len(dataset)} outlier samples)")
    
    # Numerical feature missing value filling (median)
    dataset[numeric_cols] = dataset[numeric_cols].fillna(dataset[numeric_cols].median())
    
    # No one-hot encoding, return empty matrix_cols and encoder
    return dataset, target_col, numeric_cols, [], None  

def load_validation_data(train_numeric_cols, train_matrix_cols=None, encoder=None):
    try:
        validation_data = pd.read_excel("reserved_for_experiment_validation_samples.xlsx")
        target_col = 'PHRR（Kw/m2）'
        
        # Remove NO serial column
        if 'NO' in validation_data.columns:
            initial_val_count = len(validation_data)
            validation_data = validation_data.drop(columns=['NO'], errors='ignore')
            print(f"⚠️ Validation set detected NO serial column, removed (Original validation sample count: {initial_val_count}, After removal: {len(validation_data)})")
        else:
            print(f"Loading independent validation set data: {len(validation_data)} samples")
        
        # Target value range filtering
        validation_data = validation_data[(validation_data[target_col] > 10) & (validation_data[target_col] <= 1000)].copy()
        
        # Keep only numerical features (consistent with training set, no one-hot encoding)
        numeric_cols = validation_data.select_dtypes(include=[np.number]).columns.tolist()
        if target_col in numeric_cols:
            numeric_cols.remove(target_col)
        # Ensure validation set features match training set numerical features
        required_cols = train_numeric_cols + [target_col]
        missing_cols = [col for col in required_cols if col not in validation_data.columns]
        for col in missing_cols:
            validation_data[col] = 0  # Missing feature filled with 0 (only numerical features)
        validation_data = validation_data[required_cols].copy()
        
        return validation_data
    except FileNotFoundError:
        print("Warning: Validation set file not found, will only use 5-fold cross-validation for model evaluation")
        return None
    except Exception as e:
        print(f"Error loading validation set: {str(e)}")
        return None

# -------------------------- 2. Feature Engineering (Enhanced Version) --------------------------
def feature_engineering(data, target_col, train_features=None):
    df = data.copy()
    
    # Remove NO column (if exists)
    if 'NO' in df.columns:
        df = df.drop(columns=['NO'])
    
    # Feature enhancement based on numerical features (only process existing numerical columns)
    additive_cols = ['PAPP', 'MPP', 'W', 'ZS', 'ADP']
    existing_additive = [col for col in additive_cols if col in df.columns]
    if existing_additive:
        df['total_ad'] = df[existing_additive].sum(axis=1)
        # Remove one-hot encoding related matrix_sum calculation, keep only numerical feature interactions
        df['additive_ratio'] = df['total_ad'] / (df[existing_additive].max(axis=1) + 1e-6)  # Replace with numerical feature max normalization
    else:
        df['total_ad'] = 0
        df['additive_ratio'] = 0
        print("⚠️ Core additive features (PAPP/MPP/W/ZS/ADP) do not exist, skipping related feature enhancement")
    
    # Numerical feature ratio calculation
    if 'PAPP' in df.columns and 'total_ad' in df.columns:
        df['PAPP_ratio'] = df['PAPP'] / (df['total_ad'] + 1e-6)
    else:
        df['PAPP_ratio'] = 0
    
    if 'MPP' in df.columns and 'total_ad' in df.columns:
        df['MPP_ratio'] = df['MPP'] / (df['total_ad'] + 1e-6)
    else:
        df['MPP_ratio'] = 0
    
    # Synergist numerical feature processing
    synergist_cols = ['W', 'ZS', 'ADP']
    existing_synergist = [col for col in synergist_cols if col in df.columns]
    if existing_synergist:
        df['synergist_total'] = df[existing_synergist].sum(axis=1)
        if 'W' in df.columns:
            df['W_ratio_in_synergist'] = df['W'] / (df['synergist_total'] + 1e-6)
        else:
            df['W_ratio_in_synergist'] = 0
    else:
        df['synergist_total'] = 0
        df['W_ratio_in_synergist'] = 0
    
    # Numerical feature interaction terms
    if all(col in df.columns for col in ['PAPP', 'MPP', 'W']):
        df['PAPP_MPP_W_interaction'] = df['PAPP'] * df['MPP'] * df['W']
    else:
        df['PAPP_MPP_W_interaction'] = 0
    
    # Numerical feature squared terms
    if 'PAPP' in df.columns:
        df['PAPP_square'] = df['PAPP'] ** 2
    else:
        df['PAPP_square'] = 0
    
    if 'MPP' in df.columns:
        df['MPP_square'] = df['MPP'] ** 2
    else:
        df['MPP_square'] = 0
    
    # Add more feature interactions and transformations
    if all(col in df.columns for col in ['PAPP', 'MPP']):
        df['PAPP_MPP_ratio'] = df['PAPP'] / (df['MPP'] + 1e-6)
    
    if all(col in df.columns for col in ['PAPP', 'W']):
        df['PAPP_W_ratio'] = df['PAPP'] / (df['W'] + 1e-6)
    
    # Add polynomial features
    if 'PAPP' in df.columns:
        df['PAPP_sqrt'] = np.sqrt(df['PAPP'])
    
    if 'MPP' in df.columns:
        df['MPP_sqrt'] = np.sqrt(df['MPP'])
    
    if all(col in df.columns for col in ['ZS', 'total_ad']):
        df['ZS_ratio'] = df['ZS'] / (df['total_ad'] + 1e-6)
    
    if all(col in df.columns for col in ['W', 'total_ad']):
        df['W_ratio'] = df['W'] / (df['total_ad'] + 1e-6)
    if all(col in df.columns for col in ['ADP', 'total_ad']):
        df['ADP_ratio'] = df['ADP'] / (df['total_ad'] + 1e-6)
    # Keep only numerical features
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if target_col in numeric_cols:
        numeric_cols.remove(target_col)
    
    # Align with training set features (only numerical features)
    if train_features is not None:
        train_features = [f for f in train_features if f != 'NO' and f in numeric_cols + [target_col]]
        for feat in train_features:
            if feat not in df.columns:
                df[feat] = 0
        df = df[train_features + [target_col]] if target_col in df.columns else df[train_features]
    
    return df

# -------------------------- 3. GA Feature Selection (Optimized Version) --------------------------
def ga_feature_selection(X, y, feature_names, core_features=["PAPP", "MPP", "W", "ZS", "ADP", "total_ad"], 
                         experiment_dir=None, random_seed=None):
    # Keep only numerical feature names, exclude NO column
    feature_names = [f for f in feature_names if f != 'NO']
    n_features = len(feature_names)
    
    if n_features == 0:
        # Handle case with no features
        return None, None, None, None, None, None
    if len(X) < 10:
        print(f"⚠️ Small sample size ({len(X)}), GA selection may be unstable")
    
    # Core features only keep existing numerical features
    core_indices = []
    for f in core_features:
        if f in feature_names:
            core_indices.append(feature_names.index(f))
    if not core_indices:
        core_indices = list(range(min(3, n_features)))
        print(f"Warning: Specified core features not found, using default first {len(core_indices)} numerical features as core: {[feature_names[i] for i in core_indices]}")
    
    # Random seed fixing
    if random_seed is not None:
        random.seed(random_seed)
        np.random.seed(random_seed)
    
    # GA parameter configuration (adjusted based on numerical feature count)
    population_size = min(30, n_features * 2)
    ngen = 50
    cxpb = 0.7
    mutpb = 0.15
    
    # Modification point: Ensure maximum features do not exceed 15
    max_features = min(15, int(n_features * 0.8), n_features)
    min_features = max(len(core_indices) + 3, 5) if n_features >= 5 else n_features
    
    # Ensure minimum features do not exceed maximum features
    if min_features > max_features:
        min_features = max_features
    
    print(f"GA feature selection configuration: Population size={population_size}, Iterations={ngen}, Feature selection range={min_features}-{max_features} (numerical features only)")
    
    # Reset DEAP creators
    if 'FitnessMin' in dir(creator):
        del creator.FitnessMin
    if 'Individual' in dir(creator):
        del creator.Individual
    creator.create("FitnessMin", base.Fitness, weights=(-1.0,))
    creator.create("Individual", list, fitness=creator.FitnessMin)
    
    toolbox = base.Toolbox()
    
    # Initialize individual (ensure core numerical features are always selected)
    def init_individual():
        individual = [0] * n_features
        for idx in core_indices:
            individual[idx] = 1  # Core numerical features forced selected
        remaining_needed = random.randint(min_features - len(core_indices), max_features - len(core_indices))
        non_core_indices = [i for i in range(n_features) if i not in core_indices]
        if remaining_needed > len(non_core_indices):
            remaining_needed = len(non_core_indices)
        if non_core_indices and remaining_needed > 0:
            selected_non_core = random.sample(non_core_indices, remaining_needed)
            for idx in selected_non_core:
                individual[idx] = 1
        return creator.Individual(individual)
    
    toolbox.register("individual", init_individual)
    toolbox.register("population", tools.initRepeat, list, toolbox.individual, n=population_size)
    
    # Evaluation function (based on XGBoost numerical feature evaluation)
    def evaluate(individual):
        selected_count = sum(individual)
        if selected_count < min_features or selected_count > max_features:
            return (1e6,)  # Penalize if feature count is invalid
        
        selected_mask = [bool(g) for g in individual]
        X_sel = X[:, selected_mask]  # Select only numerical features
        
        # Use model that can better improve R²
        base_model = XGBRegressor(
            n_estimators=200, 
            max_depth=5, 
            learning_rate=0.05, 
            subsample=0.8,
            colsample_bytree=0.8, 
            random_state=random_seed, 
            verbose=0
        )
        
        try:
            # Calculate R² and accuracy
            cv_r2_scores = cross_val_score(base_model, X_sel, y, cv=5, scoring='r2', n_jobs=-1)
            avg_r2 = cv_r2_scores.mean()
            
            # Calculate accuracy attainment rate
            cv_y_preds = cross_val_predict(base_model, X_sel, y, cv=5, n_jobs=-1)
            cv_relative_error = np.abs(cv_y_preds - y.values) / (y.values + 1e-6)
            cv_accuracy_rate = (cv_relative_error <= 0.15).sum() / len(y)
            
            # Combined objective: prioritize R²≥0.7 and accuracy≥85%
            if avg_r2 >= 0.7 and cv_accuracy_rate >= 0.85:
                # Solutions that already meet criteria, prioritize fewer features
                fitness = -avg_r2 - cv_accuracy_rate + selected_count * 0.01
            else:
                # Solutions that don't meet criteria, penalize distance from target
                r2_penalty = max(0, 0.7 - avg_r2) * 10
                accuracy_penalty = max(0, 0.85 - cv_accuracy_rate) * 10
                fitness = r2_penalty + accuracy_penalty + selected_count * 0.01
                
            return (fitness,)
        except Exception as e:
            print(f"GA evaluation error: {str(e)[:30]}...")
            return (1e6,)
    
    toolbox.register("evaluate", evaluate)
    toolbox.register("mate", tools.cxUniform, indpb=0.2)  # Uniform crossover
    toolbox.register("select", tools.selTournament, tournsize=4)  # Tournament selection
    
    # Mutation function (ensure core numerical features are not mutated)
    def mutate(individual):
        for i in range(n_features):
            if i in core_indices:
                individual[i] = 1  # Core numerical features forbidden to mutate to 0
                continue
            if random.random() < mutpb:
                individual[i] = 1 - individual[i]
        
        # Adjust feature count to valid range
        selected_count = sum(individual)
        non_core_indices = [i for i in range(n_features) if i not in core_indices]
        
        if selected_count < min_features:
            need_add = min_features - selected_count
            available_to_add = [i for i in non_core_indices if individual[i] == 0]
            if available_to_add:
                add_indices = random.sample(available_to_add, min(need_add, len(available_to_add)))
                for idx in add_indices:
                    individual[idx] = 1
        elif selected_count > max_features:
            need_remove = selected_count - max_features
            available_to_remove = [i for i in non_core_indices if individual[i] == 1]
            if available_to_remove:
                remove_indices = random.sample(available_to_remove, min(need_remove, len(available_to_remove)))
                for idx in remove_indices:
                    individual[idx] = 0
        
        return (individual,)
    
    toolbox.register("mutate", mutate)
    
    # Start GA optimization
    pop = toolbox.population()
    hof = tools.HallOfFame(1)  # Save best individual
    stats = tools.Statistics(lambda ind: ind.fitness.values)
    stats.register("min", np.min)
    start_time = time.time()
    
    print(f"\nGA feature selection (core numerical features: {[feature_names[i] for i in core_indices]})")
    pop, log = algorithms.eaSimple(
        pop, toolbox, cxpb, mutpb, ngen=ngen, 
        halloffame=hof, stats=stats, verbose=False
    )
    
    # Print GA iteration process
    log_min = log.select("min")
    for gen in range(0, ngen, 10):
        elapsed = time.time() - start_time
        current_min_rmse = log_min[gen] if gen < len(log_min) else log_min[-1]
        print(f"Generation {gen:2d} | Best fitness: {current_min_rmse:.2f} | Time elapsed: {elapsed:.2f}s")
    
    # Extract best features
    best_ind = hof[0]
    best_mask = [bool(g) for g in best_ind]
    if len(best_mask) > X.shape[1]:
        best_mask = best_mask[:X.shape[1]]
    best_X = X[:, best_mask]
    best_names = [name for idx, name in enumerate(feature_names) if best_mask[idx] and idx < len(feature_names)]
    
    # Validate best feature performance
    val_model = XGBRegressor(
        n_estimators=200, max_depth=5, learning_rate=0.05, 
        subsample=0.8, colsample_bytree=0.8, random_state=random_seed
    )
    
    cv_r2 = cross_val_score(val_model, best_X, y, cv=5, scoring='r2').mean()
    cv_mse = -cross_val_score(val_model, best_X, y, cv=5, scoring='neg_mean_squared_error').mean()
    cv_rmse = np.sqrt(cv_mse)
    cv_y_pred = cross_val_predict(val_model, best_X, y, cv=5)
    cv_relative_error = np.abs(cv_y_pred - y.values) / (y.values + 1e-6)
    cv_accuracy_rate = (cv_relative_error <= 0.15).sum() / len(y)
    
    # Print GA results
    print(f"\nGA completed: Selected {len(best_names)} numerical features")
    print(f"Cross-validation metrics | R²: {cv_r2:.3f} | RMSE: {cv_rmse:.2f} | Accuracy attainment rate: {cv_accuracy_rate:.1%}")
    print(f"Selected numerical features: {best_names}")
    
    # Save GA results
    if experiment_dir is not None:
        with open(os.path.join(experiment_dir, "feature_selection", "selected_features.txt"), "w", encoding="utf-8") as f:
            f.write(f"GA Feature Selection Results ({datetime.now().strftime('%Y-%m-%d %H:%M:%S')})\n")
            f.write(f"Experiment random seed: {random_seed}\n")
            f.write(f"Core features: {core_features}\n")
            f.write(f"Total numerical features (excluding NO): {n_features}\n")
            f.write(f"Selected feature count: {len(best_names)}\n")
            f.write("Selected numerical feature list:\n")
            for idx, feat in enumerate(best_names, 1):
                f.write(f"{idx}. {feat}\n")
            f.write(f"\nCross-validation evaluation metrics:\n")
            f.write(f"R²: {cv_r2:.3f}\n")
            f.write(f"RMSE: {cv_rmse:.2f}\n")
            f.write(f"Accuracy attainment rate (relative error ≤15%): {cv_accuracy_rate:.1%}\n")
        
        np.save(os.path.join(experiment_dir, "feature_selection", "feature_mask.npy"), best_mask)
        
        pd.DataFrame({
            "feature_index": [idx for idx, mask in enumerate(best_mask) if mask],
            "feature_name": best_names
        }).to_csv(
            os.path.join(experiment_dir, "feature_selection", "selected_features.csv"),
            index=False, encoding="utf-8-sig"
        )
        print(f"✅ GA feature selection results saved to: {os.path.join(experiment_dir, 'feature_selection')}")
    
    return best_X, best_names, cv_r2, cv_rmse, best_mask, cv_accuracy_rate

# -------------------------- New: Ridge Regression Formula Output Function --------------------------
def output_ridge_formula(model, feature_names, experiment_dir, iteration=None):
    """
    Output mathematical formula for ridge regression model
    
    Parameters:
    - model: Trained ridge regression model
    - feature_names: List of feature names
    - experiment_dir: Experiment directory
    - iteration: Iteration number (optional)
    """
    try:
        # Extract coefficients and intercept
        coefficients = model.coef_
        intercept = model.intercept_
        
        # Get regularization parameter alpha
        alpha = model.alpha
        
        # Build formula string
        formula_parts = []
        
        # Add intercept term
        formula_parts.append(f"{intercept:.4f}")
        
        # Add feature terms
        for i, (coef, feature) in enumerate(zip(coefficients, feature_names)):
            if abs(coef) > 1e-6:  # Ignore very small coefficients
                if coef >= 0:
                    formula_parts.append(f" + {coef:.4f} * {feature}")
                else:
                    formula_parts.append(f" - {abs(coef):.4f} * {feature}")
        
        formula = "PHRR = " + "".join(formula_parts)
        
        # Output to console
        print(f"\n{'='*60}")
        print("Ridge Regression Model Formula:")
        print(f"Regularization parameter (alpha): {alpha}")
        print(f"Intercept: {intercept:.4f}")
        print(f"Formula: {formula}")
        print(f"{'='*60}")
        
        # Save to file
        if experiment_dir:
            # Create formula directory
            formula_dir = os.path.join(experiment_dir, "regression_formulas")
            os.makedirs(formula_dir, exist_ok=True)
            
            # Determine filename
            if iteration is not None:
                filename = f"ridge_formula_iteration_{iteration+1}.txt"
            else:
                filename = "ridge_formula.txt"
            
            formula_path = os.path.join(formula_dir, filename)
            
            with open(formula_path, "w", encoding="utf-8") as f:
                f.write(f"Ridge Regression Model Formula\n")
                f.write(f"Generation time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"{'='*50}\n")
                f.write(f"Regularization parameter (alpha): {alpha}\n")
                f.write(f"Intercept: {intercept:.4f}\n")
                f.write(f"\nFeature coefficients:\n")
                for i, (coef, feature) in enumerate(zip(coefficients, feature_names)):
                    f.write(f"{i+1:3d}. {feature:<25}: {coef:.6f}\n")
                f.write(f"\nModel formula:\n")
                f.write(f"{formula}\n")
                f.write(f"\nFormula explanation:\n")
                f.write(f"1. PHRR represents predicted peak heat release rate (Kw/m²)\n")
                f.write(f"2. All feature values are raw values (not standardized)\n")
                f.write(f"3. Formula form: PHRR = intercept + Σ(coefficient_i × feature_i)\n")
                f.write(f"4. Regularization parameter alpha = {alpha} used to prevent overfitting\n")
            
            print(f"✅ Ridge regression formula saved to: {formula_path}")
            
            # Also save as CSV format for easy processing
            csv_path = os.path.join(formula_dir, filename.replace('.txt', '_coefficients.csv'))
            coeff_df = pd.DataFrame({
                'feature': feature_names,
                'coefficient': coefficients
            })
            coeff_df.to_csv(csv_path, index=False, encoding='utf-8-sig')
            print(f"✅ Ridge regression coefficient table saved to: {csv_path}")
        
        return formula, coefficients, intercept
        
    except Exception as e:
        print(f"❌ Ridge regression formula output failed: {str(e)}")
        return None, None, None

# -------------------------- 4. Model Optimization (4:1 split, only numerical features, output detailed metrics) --------------------------
def optimize_models(X, y, feature_names, test_size=0.2, random_seed=None, experiment_dir=None, iteration=None):
    # Keep only numerical feature names, exclude NO column
    feature_names = [f for f in feature_names if f != 'NO']
    if not X.shape[0] == len(y):
        raise ValueError(f"Feature matrix sample count ({X.shape[0]}) does not match target variable sample count ({len(y)})")
    
    # 4:1 split training set/test set (fixed random seed)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_seed, shuffle=True
    )
    print(f"\nTraining set/test set split completed | Training set: {X_train.shape[0]} samples, {X_train.shape[1]} numerical features | Test set: {X_test.shape[0]} samples")
    print(f"Split ratio: {X_train.shape[0]}:{X_test.shape[0]} ≈ {X_train.shape[0]/X.shape[0]:.1%}:{X_test.shape[0]/X.shape[0]:.1%}")
    
    # Save test set data
    if experiment_dir is not None:
        test_data = pd.DataFrame(X_test, columns=feature_names)
        test_data['PHRR_true'] = y_test.values
        test_data_path = os.path.join(experiment_dir, "data_splits", f"test_set_data_iteration_{iteration+1}.csv")
        test_data.to_csv(test_data_path, index=False, encoding="utf-8-sig")
        print(f"Test set data saved to: {test_data_path}")
    
    # Model parameter grids (optimized for numerical features, added regularization to prevent overfitting)
    # KEPT ONLY: Ridge, MLP, KNN, RF, XGBoost
    param_grids = {
        "Ridge Regression": {"alpha": [0.1, 0.5, 1, 5, 10], "solver": ["auto", "cholesky"], "max_iter": [2000]},
        "Random Forest Regressor": {"n_estimators": [100, 150], "max_depth": [4, 5], "min_samples_split": [5, 10], "min_samples_leaf": [3, 5], "max_features": ['sqrt', 0.7], "random_state": [random_seed]},
        "XGBoost": {"n_estimators": [100, 150], "max_depth": [3, 4], "learning_rate": [0.03, 0.05], "subsample": [0.7, 0.8], "colsample_bytree": [0.7, 0.8], "reg_alpha": [0.5, 1], "reg_lambda": [1, 1.5], "random_state": [random_seed]},
        "K-Nearest Neighbors": {"n_neighbors": [3, 4, 5, 6], "weights": ["distance"], "metric": ["manhattan", "euclidean"], "leaf_size": [20, 30]},
        "Multilayer Perceptron Regressor": {"hidden_layer_sizes": [(50,), (50, 25), (100,)], "activation": ["relu"], "alpha": [0.001, 0.01], "max_iter": [2000], "learning_rate_init": [0.001, 0.0005], "early_stopping": [True], "random_state": [random_seed]}
    }
    
    models = {
        "Ridge Regression": Ridge(),
        "Random Forest Regressor": RandomForestRegressor(),
        "XGBoost": XGBRegressor(),
        "K-Nearest Neighbors": KNeighborsRegressor(),
        "Multilayer Perceptron Regressor": MLPRegressor()
    }
    
    optimized_models = {}
    qualified_models = {}  # Models with accuracy ≥85% and R²≥0.7
    algo_metrics_list = []  # Algorithm metrics summary
    model_logs = []  # Model optimization logs
    
    # New: Store test set prediction results - Fixed version: Pre-initialize all model columns
    test_predictions = pd.DataFrame({
        'sample_index': range(len(y_test)),
        'true_value': y_test.values
    })
    
    # Pre-create NaN columns for all models
    for model_name in models.keys():
        test_predictions[model_name] = np.nan
    
    print("\n=== Model Optimization (Scoring metric: negative RMSE, Training:Test=4:1, numerical features only) ===")
    print("Note: All models exclude NO serial column, automatically saved as .pkl files after optimization")
    print("Note: SVR model removed due to high computational cost and parameter sensitivity")
    print("Note: Added regularization parameters to prevent overfitting")
    
    for model_name, base_model in models.items():
        try:
            if model_name not in param_grids:
                print(f"{model_name:<25} | No parameter grid configuration, skipping optimization")
                continue
            
            # Grid search optimization (5-fold cross-validation)
            grid_search = GridSearchCV(
                estimator=base_model,
                param_grid=param_grids[model_name],
                cv=5,
                scoring="neg_mean_squared_error",
                n_jobs=-1,
                verbose=0,
                refit=True
            )
            
            start_time = time.time()
            grid_search.fit(X_train, y_train)
            train_time = round(time.time() - start_time, 2)
            
            # Extract best model and parameters
            best_model = grid_search.best_estimator_
            best_params = grid_search.best_params_
            best_cv_rmse = np.sqrt(-grid_search.best_score_)  # Cross-validation RMSE
            
            # Test set prediction and metric calculation
            y_test_pred = best_model.predict(X_test)
            test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
            test_r2 = r2_score(y_test, y_test_pred)
            test_r, test_r_pvalue = pearsonr(y_test.values, y_test_pred)
            test_relative_error = np.abs(y_test_pred - y_test.values) / (y_test.values + 1e-6)
            test_avg_accuracy = 1 - np.mean(test_relative_error)
            test_accuracy_rate = (test_relative_error <= 0.15).sum() / len(y_test)
            
            # Training set metric calculation (for overfitting judgment)
            y_train_pred = best_model.predict(X_train)
            train_rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))
            train_r2 = r2_score(y_train, y_train_pred)
            train_r, train_r_pvalue = pearsonr(y_train.values, y_train_pred)
            
            def check_overfitting(train_r2, test_r2, train_rmse, test_rmse, threshold=0.15):
                """Check if model may be overfitting"""
                r2_diff = abs(train_r2 - test_r2)
                rmse_ratio = test_rmse / train_rmse if train_rmse > 0 else 1
                
                # If training set performance is significantly better than test set, possible overfitting
                if r2_diff > threshold or rmse_ratio > 1.5:
                    return True
                return False
            
            # Check if current model may be overfitting
            is_overfitted = check_overfitting(train_r2, test_r2, train_rmse, test_rmse)
            
            # If model is overfitting, try simpler model
            if is_overfitted:
                print(f"{model_name:<25} | Possible overfitting detected, trying simplified model...")
                
                # Create simplified version of model
                if model_name == "Random Forest Regressor":
                    simple_model = RandomForestRegressor(
                        n_estimators=50, max_depth=3, min_samples_split=10, 
                        min_samples_leaf=5, random_state=random_seed
                    )
                elif model_name == "XGBoost":
                    simple_model = XGBRegressor(
                        n_estimators=50, max_depth=3, learning_rate=0.03, 
                        subsample=0.7, colsample_bytree=0.7, 
                        reg_alpha=1, reg_lambda=1.5, random_state=random_seed
                    )
                elif model_name == "Multilayer Perceptron Regressor":
                    simple_model = MLPRegressor(
                        hidden_layer_sizes=(30,), alpha=0.01, max_iter=2000, 
                        learning_rate_init=0.001, early_stopping=True, random_state=random_seed
                    )
                else:
                    # For other models, use default parameters
                    simple_model = clone(base_model)
                    simple_model.set_params(**{k: v[0] for k, v in param_grids[model_name].items() if not isinstance(v, list)})
                
                # Train simplified model
                simple_model.fit(X_train, y_train)
                
                # Re-evaluate simplified model
                y_test_pred_simple = simple_model.predict(X_test)
                test_rmse_simple = np.sqrt(mean_squared_error(y_test, y_test_pred_simple))
                test_r2_simple = r2_score(y_test, y_test_pred_simple)
                test_r_simple, test_r_pvalue_simple = pearsonr(y_test.values, y_test_pred_simple)
                test_relative_error_simple = np.abs(y_test_pred_simple - y_test.values) / (y_test.values + 1e-6)
                test_avg_accuracy_simple = 1 - np.mean(test_relative_error_simple)
                test_accuracy_rate_simple = (test_relative_error_simple <= 0.15).sum() / len(y_test)
                
                # Check if simplified model is still overfitting
                y_train_pred_simple = simple_model.predict(X_train)
                train_rmse_simple = np.sqrt(mean_squared_error(y_train, y_train_pred_simple))
                train_r2_simple = r2_score(y_train, y_train_pred_simple)
                is_overfitted_simple = check_overfitting(train_r2_simple, test_r2_simple, train_rmse_simple, test_rmse_simple)
                
                # If simplified model is not overfitting or performs better, use simplified model
                if not is_overfitted_simple or (test_r2_simple > test_r2 and test_accuracy_rate_simple > test_accuracy_rate):
                    print(f"{model_name:<25} | Using simplified model to solve overfitting")
                    best_model = simple_model
                    best_params = simple_model.get_params()
                    test_rmse = test_rmse_simple
                    test_r2 = test_r2_simple
                    test_r = test_r_simple
                    test_r_pvalue = test_r_pvalue_simple
                    test_relative_error = test_relative_error_simple
                    test_avg_accuracy = test_avg_accuracy_simple
                    test_accuracy_rate = test_accuracy_rate_simple
                    train_rmse = train_rmse_simple
                    train_r2 = train_r2_simple
                    train_r, train_r_pvalue = pearsonr(y_train.values, y_train_pred_simple)
                    is_overfitted = is_overfitted_simple
            
            # Save optimized model information
            optimized_models[model_name] = {
                "model": best_model,
                "best_params": best_params,
                "cv_rmse": best_cv_rmse,
                "train_metrics": {
                    "r": train_r,
                    "r2": train_r2,
                    "rmse": train_rmse,
                    "r_pvalue": train_r_pvalue
                },
                "test_metrics": {
                    "r": test_r,
                    "r2": test_r2,
                    "rmse": test_rmse,
                    "r_pvalue": test_r_pvalue,
                    "avg_accuracy": test_avg_accuracy,
                    "accuracy_rate": test_accuracy_rate,
                    "y_pred": y_test_pred,
                    "y_true": y_test.values,
                    "relative_error": test_relative_error
                },
                "train_time": train_time,
                "is_overfitted": is_overfitted,
                "status": "success"
            }
            
            # Update test set prediction results
            test_predictions[model_name] = y_test_pred
            
            # Special handling for ridge regression model, output formula
            if model_name == "Ridge Regression":
                print(f"\n{'-'*60}")
                print(f"Processing ridge regression model, preparing to output formula...")
                formula_result = output_ridge_formula(best_model, feature_names, experiment_dir, iteration)
                if formula_result[0]:
                    optimized_models[model_name]["formula"] = formula_result[0]
                    optimized_models[model_name]["coefficients"] = formula_result[1]
                    optimized_models[model_name]["intercept"] = formula_result[2]
                print(f"{'-'*60}")
            
            # Record algorithm metrics
            algo_metrics_list.append({
                "Model_Name": model_name,
                "Training_R": round(train_r, 4),
                "Training_R²": round(train_r2, 4),
                "Training_RMSE": round(train_rmse, 4),
                "Test_R": round(test_r, 4),
                "Test_R²": round(test_r2, 4),
                "Test_RMSE": round(test_rmse, 4),
                "CV_RMSE": round(best_cv_rmse, 4),
                "Test_Avg_Accuracy": round(test_avg_accuracy, 4),
                "Test_Accuracy_Rate": round(test_accuracy_rate, 4),
                "Overfitting": "Yes" if is_overfitted else "No",
                "Training_Time(s)": train_time,
                "Status": "Success"
            })
            
            # Record model logs
            model_logs.append({
                "Optimization_Time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "Model_Name": model_name,
                "Best_Parameters": str(best_params),
                "Training_R": round(train_r, 4),
                "Training_R²": round(train_r2, 4),
                "Training_RMSE": round(train_rmse, 4),
                "Test_R": round(test_r, 4),
                "Test_R²": round(test_r2, 4),
                "Test_RMSE": round(test_rmse, 4),
                "CV_RMSE": round(best_cv_rmse, 4),
                "Test_Avg_Accuracy": round(test_avg_accuracy, 4),
                "Test_Accuracy_Rate": round(test_accuracy_rate, 4),
                "Overfitting": "Yes" if is_overfitted else "No",
                "Training_Time(s)": train_time,
                "Status": "Success"
            })
            
            # Determine if criteria met (accuracy rate ≥85% and R²≥0.7 and not overfitting)
            if test_accuracy_rate >= 0.85 and test_r2 >= 0.7 and not is_overfitted:
                qualified_models[model_name] = optimized_models[model_name]
                status_tag = "✅ Qualified"
            else:
                status_tag = "❌ Not Qualified"
            
            # Print model results
            print(f"{model_name:<25} | Training R: {train_r:.4f} | Training R²: {train_r2:.4f} | Training RMSE: {train_rmse:.4f}")
            print(f"{'':<25} | Test R: {test_r:.4f} | Test R²: {test_r2:.4f} | Test RMSE: {test_rmse:.4f} | Accuracy Rate: {test_accuracy_rate:.1%} | Overfitting: {'Yes' if is_overfitted else 'No'} | {status_tag}")
            
            # Save model file (save regardless of quality)
            if experiment_dir is not None:
                model_filename = f"{model_name.replace(' ', '_').lower()}_iteration_{iteration+1}_{datetime.now().strftime('%H%M%S')}.pkl"
                model_save_path = os.path.join(experiment_dir, "models", model_filename)
                joblib.dump(best_model, model_save_path)
                print(f"   → {model_name} saved to: {model_save_path}")
                
                # Save model detailed information
                model_info_path = os.path.join(experiment_dir, "models", f"{model_name.replace(' ', '_').lower()}_info.json")
                model_info = {
                    "model_name": model_name,
                    "best_params": best_params,
                    "test_r2": float(test_r2),
                    "test_accuracy_rate": float(test_accuracy_rate),
                    "is_overfitted": is_overfitted,
                    "save_path": model_save_path,
                    "iteration": iteration + 1,
                    "save_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
                with open(model_info_path, 'w', encoding='utf-8') as f:
                    json.dump(model_info, f, ensure_ascii=False, indent=2)
        
        except Exception as e:
            error_msg = str(e)[:50] + "..." if len(str(e)) > 50 else str(e)
            print(f"{model_name:<25} | Optimization error: {error_msg}")
            model_logs.append({
                "Optimization_Time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "Model_Name": model_name,
                "Best_Parameters": None,
                "Training_R": None,
                "Training_R²": None,
                "Training_RMSE": None,
                "Test_R": None,
                "Test_R²": None,
                "Test_RMSE": None,
                "CV_RMSE": None,
                "Test_Avg_Accuracy": None,
                "Test_Accuracy_Rate": None,
                "Overfitting": None,
                "Training_Time(s)": None,
                "Status": f"Failed: {error_msg}"
            })
            optimized_models[model_name] = {
                "error": error_msg,
                "status": "failed"
            }
            # Test set prediction remains NaN (pre-initialized)
    
    # Check and save test set prediction results
    if experiment_dir is not None and not test_predictions.empty:
        test_pred_path = os.path.join(experiment_dir, "predictions", f"test_set_predictions_iteration_{iteration+1}.csv")
        test_predictions.to_csv(test_pred_path, index=False, encoding="utf-8-sig")
        
        # Check prediction completeness
        print(f"\n=== Test Set Prediction Data Completeness Check ===")
        print(f"Total samples: {len(test_predictions)}")
        for model_name in models.keys():
            if model_name in test_predictions.columns:
                non_nan = test_predictions[model_name].notna().sum()
                print(f"{model_name}: {non_nan}/{len(test_predictions)} predicted values")
        
        print(f"\n✅ Test set prediction results saved to: {test_pred_path}")
    
    # Print optimization summary
    print(f"\n=== Model Optimization Summary ===")
    print(f"Total models: {len(models)} | Successfully optimized: {len([m for m in optimized_models.values() if 'error' not in m])} | Qualified models (≥85% and R²≥0.7 and not overfitting): {len(qualified_models)}")
    
    # Save metrics and logs
    if experiment_dir is not None:
        algo_metrics_df = pd.DataFrame(algo_metrics_list)
        metrics_save_path = os.path.join(experiment_dir, "logs", f"algorithm_core_metrics_iteration_{iteration+1}.csv")
        algo_metrics_df.to_csv(metrics_save_path, index=False, encoding="utf-8-sig")
        print(f"\n✅ Algorithm core metrics summary table saved to: {metrics_save_path}")
        
        log_df = pd.DataFrame(model_logs)
        log_save_path = os.path.join(experiment_dir, "logs", f"model_optimization_log_iteration_{iteration+1}.csv")
        log_df.to_csv(log_save_path, index=False, encoding="utf-8-sig")
        print(f"✅ Model optimization log saved to: {log_save_path}")
    
    return optimized_models, qualified_models, test_predictions, algo_metrics_list

# -------------------------- 5. 5-Fold Cross-Validation Evaluation (only numerical features) - Fixed Version --------------------------
def cross_validation_evaluation(X, y, selected_feats, n_splits=5, experiment_dir=None, random_seed=None):
    # Keep only numerical feature names, exclude NO column
    selected_feats = [f for f in selected_feats if f != 'NO']
    if X.shape[0] < n_splits:
        raise ValueError(f"Sample count ({X.shape[0]}) less than cross-validation folds ({n_splits}), cannot perform effective evaluation")
    if X.shape[1] == 0:
        raise ValueError("No valid numerical features for cross-validation evaluation")
    
    print(f"\n=== 5-Fold Cross-Validation Evaluation (Total {n_splits} folds, numerical features only) ===")
    print(f"Evaluation sample count: {X.shape[0]} | Evaluation feature count: {X.shape[1]} | Selected numerical features: {selected_feats}")
    
    # Initialize 5-fold cross-validation (shuffle data)
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=random_seed)
    
    # Models to evaluate (using default values of optimized parameters, added regularization to prevent overfitting)
    # KEPT ONLY: Ridge, MLP, KNN, RF, XGBoost
    models = {
        "Ridge Regression": Ridge(alpha=10, max_iter=2000, random_state=random_seed),
        "Random Forest Regressor": RandomForestRegressor(n_estimators=100, max_depth=4, min_samples_split=5, min_samples_leaf=3, max_features='sqrt', random_state=random_seed),
        "XGBoost": XGBRegressor(n_estimators=100, max_depth=3, learning_rate=0.05, subsample=0.8, colsample_bytree=0.8, reg_alpha=0.5, reg_lambda=1, random_state=random_seed),
        "K-Nearest Neighbors": KNeighborsRegressor(n_neighbors=5, weights="distance", metric="manhattan"),
        "Multilayer Perceptron Regressor": MLPRegressor(hidden_layer_sizes=(50,), alpha=0.01, max_iter=2000, learning_rate_init=0.001, early_stopping=True, random_state=random_seed)
    }
    
    cv_results = {}  # Cross-validation results
    cv_detail_logs = []  # Detailed logs
    
    # Fixed version: Store 5-fold cross-validation prediction results - Pre-initialize all model columns
    cv_predictions = pd.DataFrame({
        'sample_index': range(len(y)),
        'true_value': y.values
    })
    
    # Pre-create NaN columns for all models
    for model_name in models.keys():
        cv_predictions[model_name] = np.nan
    
    print(f"\nStarting 5-fold cross-validation evaluation, total samples: {len(y)}")
    
    for model_name, model in models.items():
        try:
            print(f"\nEvaluating model: {model_name}")
            
            # Initialize current model prediction array (with NaN)
            y_cv_pred = np.full(len(y), np.nan, dtype=float)
            fold_r, fold_r2, fold_rmse, fold_accuracy_rate = [], [], [], []
            
            # Iterate through each fold
            for fold_idx, (train_idx, val_idx) in enumerate(kf.split(X), 1):
                X_train_fold, X_val_fold = X[train_idx], X[val_idx]
                y_train_fold, y_val_fold = y.iloc[train_idx], y.iloc[val_idx]
                
                # Check data validity
                if len(X_train_fold) < 5:
                    print(f"  ⚠️ Fold {fold_idx} training set insufficient samples ({len(X_train_fold)}), skipping")
                    continue
                
                if len(X_val_fold) < 2:
                    print(f"  ⚠️ Fold {fold_idx} validation set insufficient samples ({len(X_val_fold)}), skipping")
                    continue
                
                # Clone model to prevent state contamination
                model_clone = clone(model)
                
                try:
                    # Train and predict
                    model_clone.fit(X_train_fold, y_train_fold)
                    y_val_pred = model_clone.predict(X_val_fold)
                    
                    # Save prediction results
                    y_cv_pred[val_idx] = y_val_pred
                    
                    # Calculate metrics (need at least 2 samples)
                    if len(y_val_fold) >= 2:
                        r, r_pvalue = pearsonr(y_val_fold.values, y_val_pred)
                        r2 = r2_score(y_val_fold, y_val_pred)
                        rmse = np.sqrt(mean_squared_error(y_val_fold, y_val_pred))
                        relative_error = np.abs(y_val_pred - y_val_fold.values) / (y_val_fold.values + 1e-6)
                        accuracy_rate = (relative_error <= 0.15).sum() / len(y_val_fold)
                        avg_accuracy = 1 - np.mean(relative_error)
                        
                        # Save fold results
                        fold_r.append(r)
                        fold_r2.append(r2)
                        fold_rmse.append(rmse)
                        fold_accuracy_rate.append(accuracy_rate)
                        
                        # Record fold logs
                        cv_detail_logs.append({
                            "Model_Name": model_name,
                            "Fold": fold_idx,
                            "Training_Samples": len(X_train_fold),
                            "Validation_Samples": len(X_val_fold),
                            "R": r,
                            "R_p_value": r_pvalue,
                            "R²": r2,
                            "RMSE": rmse,
                            "Avg_Accuracy": avg_accuracy,
                            "Accuracy_Rate": accuracy_rate,
                            "Status": "Success"
                        })
                        
                        print(f"  Fold {fold_idx} | R²: {r2:.4f} | RMSE: {rmse:.4f} | Accuracy: {accuracy_rate:.1%}")
                    
                except Exception as fold_e:
                    error_msg = str(fold_e)[:50]
                    print(f"  Fold {fold_idx} training/prediction failed: {error_msg}")
                    cv_detail_logs.append({
                        "Model_Name": model_name,
                        "Fold": fold_idx,
                        "Training_Samples": len(X_train_fold),
                        "Validation_Samples": len(X_val_fold),
                        "R": None,
                        "R_p_value": None,
                        "R²": None,
                        "RMSE": None,
                        "Avg_Accuracy": None,
                        "Accuracy_Rate": None,
                        "Status": f"Failed: {error_msg}"
                    })
            
            # Update prediction DataFrame
            cv_predictions[model_name] = y_cv_pred
            
            # Handle case with no valid folds
            if len(fold_r2) == 0:
                print(f"  ❌ No valid fold results, cannot calculate summary metrics")
                cv_results[model_name] = {"status": "failed", "error": "No valid fold results"}
                continue
            
            # Calculate summary metrics
            cv_results[model_name] = {
                "r_mean": np.mean(fold_r),
                "r_std": np.std(fold_r),
                "r2_mean": np.mean(fold_r2),
                "r2_std": np.std(fold_r2),
                "rmse_mean": np.mean(fold_rmse),
                "rmse_std": np.std(fold_rmse),
                "accuracy_rate_mean": np.mean(fold_accuracy_rate),
                "accuracy_rate_std": np.std(fold_accuracy_rate),
                "avg_relative_error": np.mean([err for err in fold_accuracy_rate]),
                "valid_folds": len(fold_r2),
                "status": "success"
            }
            
            # Print model cross-validation results
            print(f"Completed | Valid folds: {len(fold_r2)} | Average R²: {np.mean(fold_r2):.4f} | Average accuracy: {np.mean(fold_accuracy_rate):.1%}")
        
        except Exception as e:
            error_msg = str(e)[:100]
            print(f"Model evaluation error: {error_msg}")
            cv_detail_logs.append({
                "Model_Name": model_name,
                "Fold": None,
                "Training_Samples": None,
                "Validation_Samples": None,
                "R": None,
                "R_p_value": None,
                "R²": None,
                "RMSE": None,
                "Avg_Accuracy": None,
                "Accuracy_Rate": None,
                "Status": f"Failed: {error_msg}"
            })
            cv_results[model_name] = {"status": "failed", "error": error_msg}
            # Prediction column remains NaN (pre-initialized)
    
    # Save 5-fold cross-validation prediction results
    if experiment_dir is not None and not cv_predictions.empty:
        cv_pred_path = os.path.join(experiment_dir, "predictions", "cv_predictions_detailed.csv")
        cv_predictions.to_csv(cv_pred_path, index=False, encoding="utf-8-sig")
        
        # Check prediction completeness
        print(f"\n=== 5-Fold Cross-Validation Prediction Data Completeness Check ===")
        print(f"Total samples: {len(cv_predictions)}")
        print(f"Prediction data dimensions: {cv_predictions.shape}")
        
        # Statistics for each model's prediction situation
        prediction_stats = []
        for model_name in models.keys():
            if model_name in cv_predictions.columns:
                non_nan = cv_predictions[model_name].notna().sum()
                prediction_stats.append({
                    "model": model_name,
                    "total_samples": len(cv_predictions),
                    "predicted_samples": non_nan,
                    "prediction_rate": f"{non_nan/len(cv_predictions):.1%}",
                    "status": cv_results.get(model_name, {}).get("status", "unknown")
                })
        
        stats_df = pd.DataFrame(prediction_stats)
        print(f"\nPrediction completion status:")
        print(stats_df.to_string(index=False))
        
        print(f"\nDetailed 5-fold cross-validation predictions saved to: {cv_pred_path}")
        
        # Also save statistical information
        stats_path = os.path.join(experiment_dir, "predictions", "cv_prediction_stats.csv")
        stats_df.to_csv(stats_path, index=False, encoding="utf-8-sig")
        print(f"Prediction statistics saved to: {stats_path}")
    
    # Save cross-validation results
    if cv_results:
        cv_result_list = []
        for model_name, result in cv_results.items():
            if result["status"] == "success":
                cv_result_list.append({
                    "Model_Name": model_name,
                    "Valid_Folds": result["valid_folds"],
                    "R_Mean": round(result["r_mean"], 4),
                    "R_Std": round(result["r_std"], 4),
                    "R²_Mean": round(result["r2_mean"], 4),
                    "R²_Std": round(result["r2_std"], 4),
                    "RMSE_Mean": round(result["rmse_mean"], 4),
                    "RMSE_Std": round(result["rmse_std"], 4),
                    "Accuracy_Rate_Mean": round(result["accuracy_rate_mean"], 4),
                    "Accuracy_Rate_Std": round(result["accuracy_rate_std"], 4),
                    "Avg_Relative_Error": round(result["avg_relative_error"], 4),
                    "Status": "Success"
                })
            else:
                cv_result_list.append({
                    "Model_Name": model_name,
                    "Valid_Folds": None,
                    "R_Mean": None,
                    "R_Std": None,
                    "R²_Mean": None,
                    "R²_Std": None,
                    "RMSE_Mean": None,
                    "RMSE_Std": None,
                    "Accuracy_Rate_Mean": None,
                    "Accuracy_Rate_Std": None,
                    "Avg_Relative_Error": None,
                    "Status": f"Failed: {result['error']}"
                })
        
        cv_result_df = pd.DataFrame(cv_result_list)
        if experiment_dir is not None:
            cv_result_path = os.path.join(experiment_dir, "PHRR_cross_validation_results.csv")
        else:
            cv_result_path = "PHRR_cross_validation_results.csv"
        cv_result_df.to_csv(cv_result_path, index=False, encoding="utf-8-sig")
        print(f"\n5-fold cross-validation results summary saved to: {cv_result_path}")
    
    # Save detailed logs
    if experiment_dir is not None and cv_detail_logs:
        cv_detail_df = pd.DataFrame(cv_detail_logs)
        cv_detail_path = os.path.join(experiment_dir, "logs", "cross_validation_detail_log.csv")
        cv_detail_df.to_csv(cv_detail_path, index=False, encoding="utf-8-sig")
        print(f"Cross-validation detailed log saved to: {cv_detail_path}")
    
    return cv_results, cv_predictions

# -------------------------- 6. Independent Validation Set Evaluation (All models used for prediction) - Fixed Version --------------------------
def evaluate_all_models_on_validation(optimized_models, validation_data, feature_mask, feature_names, target_col, train_features, experiment_dir=None):
    """
    Use all models (regardless of quality) to predict validation set
    """
    if validation_data is None or len(validation_data) == 0:
        print("⚠️ No valid independent validation set provided, skipping external validation step")
        return None, None, None
    
    # Keep only numerical feature names, exclude NO column
    feature_names = [f for f in feature_names if f != 'NO']
    train_features = [f for f in train_features if f != 'NO']
    
    print(f"\n=== Independent Validation Set Evaluation (All models participate in prediction) ===")
    print(f"Validation set sample count: {len(validation_data)} samples")
    
    # Validation set feature engineering (consistent with training set, only numerical features)
    validation_data_eng = feature_engineering(validation_data, target_col, train_features)
    
    # Ensure validation set features match training set numerical features
    valid_features = [f for f in train_features if f in validation_data_eng.columns and f != 'NO']
    if not valid_features:
        print("Validation set has no valid numerical features (NO column removed), cannot evaluate")
        return None, None, None
    
    # Extract validation set features and target values
    X_val = validation_data_eng[valid_features].values
    y_true = validation_data_eng[target_col].values if target_col in validation_data_eng.columns else None
    
    if y_true is not None:
        print(f"Validation set target value range: {y_true.min():.1f} - {y_true.max():.1f} (Kw/m2)")
    
    # Apply GA feature selection mask (only numerical features)
    if len(feature_mask) > X_val.shape[1]:
        feature_mask = feature_mask[:X_val.shape[1]]
    selected_feature_indices = [i for i, selected in enumerate(feature_mask) if selected and i < X_val.shape[1]]
    
    # Filter features
    if selected_feature_indices:
        X_val_sel = X_val[:, selected_feature_indices]
        print(f"Feature filtering completed | Original numerical features: {X_val.shape[1]} | Selected features: {X_val_sel.shape[1]}")
    else:
        X_val_sel = X_val
        print("⚠️ No selected features, using all original numerical features for evaluation")
    
    # Skip standardization step, directly use raw feature values
    X_val_final = X_val_sel
    print("⚠️ Skipped standardization step, using raw feature values for prediction")
    
    # Initialize result storage - Fixed version
    all_models_predictions = {}  # All models' prediction results
    val_results = {}
    
    # Create detailed result DataFrame - Pre-create columns for all models
    val_detail_df = validation_data.copy()
    
    # Remove NO column (if exists)
    if 'NO' in val_detail_df.columns:
        val_detail_df = val_detail_df.drop(columns=['NO'])
    
    # Add true value column (if exists)
    if y_true is not None:
        val_detail_df["True_Value_PHRR"] = y_true
    
    # Pre-create NaN columns for all optimized models
    for model_name in optimized_models.keys():
        pred_col = f"{model_name}_Predicted"
        val_detail_df[pred_col] = np.nan
    
    # Print header
    print(f"\n=== All Algorithms' Predictions on Validation Samples ===")
    
    # Counter
    successful_models = 0
    failed_models = 0
    
    # Iterate through all optimized models for prediction
    for model_name, model_info in optimized_models.items():
        try:
            # Check model status
            if "status" in model_info and model_info["status"] == "failed":
                print(f"{model_name:<25} | Model optimization failed, skipping prediction")
                failed_models += 1
                continue
            
            # Check if model object exists
            if "model" not in model_info:
                print(f"{model_name:<25} | Model object does not exist, skipping prediction")
                failed_models += 1
                continue
            
            # Load model and predict
            model = model_info["model"]
            y_pred = model.predict(X_val_final)
            y_pred = np.maximum(y_pred, 5)  # Avoid prediction values being too small (unreasonable)
            y_pred_rounded = np.round(y_pred, 2)
            
            # Save all prediction results
            all_models_predictions[model_name] = y_pred_rounded
            
            # Update predicted values to detailed results table
            pred_col = f"{model_name}_Predicted"
            val_detail_df[pred_col] = y_pred_rounded
            
            # Calculate evaluation metrics (if true values exist)
            if y_true is not None and len(y_true) == len(y_pred):
                rmse = np.sqrt(mean_squared_error(y_true, y_pred))
                r2 = r2_score(y_true, y_pred)
                r, r_pvalue = pearsonr(y_true, y_pred)
                relative_error = np.abs(y_pred - y_true) / (y_true + 1e-6)
                accuracy = np.maximum(1 - relative_error, 0)
                avg_accuracy = np.mean(accuracy)
                accuracy_rate = (relative_error <= 0.15).sum() / len(y_true)
                qualified_count = (relative_error <= 0.15).sum()
                
                # Save model validation results
                val_results[model_name] = {
                    "model_name": model_name,
                    "y_pred": y_pred,
                    "y_true": y_true,
                    "metrics": {
                        "r": r,
                        "r2": r2,
                        "rmse": rmse,
                        "r_pvalue": r_pvalue,
                        "relative_error": relative_error,
                        "avg_accuracy": avg_accuracy,
                        "accuracy_rate": accuracy_rate,
                        "qualified_samples": qualified_count,
                        "total_samples": len(y_true)
                    },
                    "status": "success"
                }
                
                # Determine if qualified
                if accuracy_rate >= 0.85 and r2 >= 0.7:
                    status = "Qualified"
                else:
                    status = "Not Qualified"
                
                # Print model summary results
                print(f"{model_name:<25} | R²: {r2:.3f} | Avg Accuracy: {avg_accuracy:.3f} | Accuracy Rate: {accuracy_rate:.1%} | {status}")
            
            else:
                # Only save prediction results if no true values
                val_results[model_name] = {
                    "model_name": model_name,
                    "y_pred": y_pred,
                    "y_true": None,
                    "metrics": None,
                    "status": "success_no_ground_truth"
                }
                print(f"{model_name:<25} | Prediction completed (no true values for evaluation)")
            
            successful_models += 1
            
        except Exception as e:
            error_msg = str(e)[:100]
            print(f"{model_name:<25} | Prediction error: {error_msg}")
            val_results[model_name] = {
                "model_name": model_name,
                "error": error_msg,
                "status": "failed"
            }
            failed_models += 1
            # Prediction column remains NaN (pre-initialized)
    
    print(f"\n=== Prediction Summary ===")
    print(f"Total models: {len(optimized_models)}")
    print(f"Successfully predicted models: {successful_models}")
    print(f"Failed models: {failed_models}")
    
    # Save all models' prediction results
    if experiment_dir is not None:
        # 1. Save all models' complete prediction results
        if all_models_predictions:
            all_pred_df = pd.DataFrame(all_models_predictions)
            all_pred_df.insert(0, 'sample_index', range(len(all_pred_df)))
            if y_true is not None:
                all_pred_df.insert(1, 'true_value', y_true)
            
            all_pred_path = os.path.join(experiment_dir, "all_models_predictions", "all_models_validation_predictions.csv")
            all_pred_df.to_csv(all_pred_path, index=False, encoding="utf-8-sig")
            print(f"\nAll models' complete prediction results saved to: {all_pred_path}")
            
            # Check prediction data completeness
            print(f"Prediction data statistics:")
            print(f"Total samples: {len(all_pred_df)}")
            for model_name in all_models_predictions.keys():
                pred_count = len(all_models_predictions[model_name])
                print(f"  {model_name}: {pred_count} predicted values")
    
    # Save validation set results
    if experiment_dir is not None:
        # Save detailed results (Excel)
        val_detail_path = os.path.join(experiment_dir, "PHRR_validation_all_models_details.xlsx")
        val_detail_df.to_excel(val_detail_path, index=False, engine='openpyxl')
        print(f"\nValidation set detailed results saved to: {val_detail_path}")
        
        # Check detailed results completeness
        print(f"Detailed results data dimensions: {val_detail_df.shape}")
        print(f"Included model prediction columns: {[col for col in val_detail_df.columns if 'Predicted' in col]}")
        
        # Save summary results (CSV)
        val_summary_list = []
        for model_name, result in val_results.items():
            if result.get("status") == "failed":
                val_summary_list.append({
                    "Model_Name": model_name,
                    "Validation_Samples": len(validation_data),
                    "R": None,
                    "R²": None,
                    "RMSE": None,
                    "Avg_Accuracy": None,
                    "Accuracy_Rate": None,
                    "Qualified_Samples": None,
                    "Status": f"Failed: {result.get('error', 'Unknown error')}"
                })
            elif result.get("status") == "success_no_ground_truth":
                val_summary_list.append({
                    "Model_Name": model_name,
                    "Validation_Samples": len(validation_data),
                    "R": None,
                    "R²": None,
                    "RMSE": None,
                    "Avg_Accuracy": None,
                    "Accuracy_Rate": None,
                    "Qualified_Samples": None,
                    "Status": "Success (no ground truth)"
                })
            elif result.get("metrics") is not None:
                metrics = result["metrics"]
                val_summary_list.append({
                    "Model_Name": model_name,
                    "Validation_Samples": len(validation_data),
                    "R": round(metrics["r"], 4) if "r" in metrics else None,
                    "R²": round(metrics["r2"], 4) if "r2" in metrics else None,
                    "RMSE": round(metrics["rmse"], 4) if "rmse" in metrics else None,
                    "Avg_Accuracy": round(metrics["avg_accuracy"], 4) if "avg_accuracy" in metrics else None,
                    "Accuracy_Rate": round(metrics["accuracy_rate"], 4) if "accuracy_rate" in metrics else None,
                    "Qualified_Samples": f"{metrics.get('qualified_samples', 0)}/{metrics.get('total_samples', 0)}" if "qualified_samples" in metrics else None,
                    "Status": "Success"
                })
        
        val_summary_df = pd.DataFrame(val_summary_list)
        val_summary_path = os.path.join(experiment_dir, "PHRR_validation_all_models_summary.csv")
        val_summary_df.to_csv(val_summary_path, index=False, encoding="utf-8-sig")
        print(f"Validation set metrics summary saved to: {val_summary_path}")
        
        # Output final input features for validation samples
        print("\nFinal input features for validation samples (first 3 samples, no standardization):")
        for i in range(min(3, len(X_val_final))):
            print(f"Sample {i+1}: {X_val_final[i]}")
    
    return val_results, val_detail_df, all_models_predictions

# -------------------------- Main Function (Modified: Ensure all models are used for prediction) - Fixed Version --------------------------
def main(random_seed=5):
    print("="*70)
    print(f"===== PHRR Model Evaluation Program (All models participate in prediction) - Fixed Version =====")
    print(f"===== Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} =====")
    print("="*70)
    
    # Initialize experiment directory
    experiment_dir = init_experiment_dir()
    print(f"\nExperiment directory created: {experiment_dir}")
    
    # Load data (only numerical features, no one-hot encoding)
    dataset, target_col, numeric_cols, matrix_cols, encoder = load_data(random_seed)
    if len(dataset) < 10:
        print(f"⚠️ Warning: Small sample size ({len(dataset)}), may affect model stability")
    
    # Feature engineering (only numerical feature enhancement)
    dataset_eng = feature_engineering(dataset, target_col)
    X = dataset_eng.drop(columns=[target_col]).values
    y = dataset_eng[target_col]
    feature_names = dataset_eng.drop(columns=[target_col]).columns.tolist()
    print(f"\nFeature engineering completed | Total numerical features (excluding NO and target column): {X.shape[1]} | Feature list: {feature_names}")
    
    # Skip standardization step
    X_final = X  # Directly use raw feature values
    print("⚠️ Skipped standardization step, using raw feature values for model training and evaluation")
    
    # Iterative optimization until qualified models found or maximum iterations reached
    max_iterations = 3
    best_models = {}
    all_results = {}
    all_optimized_models = {}  # Save all iterations' optimized models
    
    for iteration in range(max_iterations):
        print(f"\n{'='*70}")
        print(f"=== Iteration {iteration+1} Optimization ===")
        print(f"{'='*70}")
        
        # GA feature selection (only numerical features)
        best_X, best_feats, cv_r2, cv_rmse, feature_mask, cv_accuracy_rate = ga_feature_selection(
            X_final, y, feature_names, experiment_dir=experiment_dir, random_seed=random_seed+iteration
        )
        
        # Model optimization (4:1 split, only numerical features)
        optimized_models, qualified_models, test_predictions, algo_metrics_df = optimize_models(
            best_X, y, best_feats, test_size=0.2, random_seed=random_seed+iteration, experiment_dir=experiment_dir, iteration=iteration
        )
        
        # Save current iteration's optimized models
        all_optimized_models.update(optimized_models)
        
        # 5-fold cross-validation evaluation (only numerical features)
        cv_results, cv_predictions = cross_validation_evaluation(
            best_X, y, best_feats, n_splits=5, experiment_dir=experiment_dir, random_seed=random_seed+iteration
        )
        
        # Load validation set data
        validation_data = load_validation_data(numeric_cols, matrix_cols, encoder)
        
        # Independent validation set evaluation (all models participate in prediction)
        val_results, val_detail_df, all_predictions = evaluate_all_models_on_validation(
            optimized_models, validation_data, feature_mask, feature_names, 
            target_col, dataset_eng.drop(columns=[target_col]).columns.tolist(),
            experiment_dir=experiment_dir
        )
        
        # Save current iteration results
        all_results[iteration] = {
            "optimized_models": optimized_models,
            "qualified_models": qualified_models,
            "test_predictions": test_predictions,
            "cv_results": cv_results,
            "cv_predictions": cv_predictions,
            "val_results": val_results,
            "all_predictions": all_predictions
        }
        
        # Check if there are qualified models
        qualified_models_dict = {}
        if val_results:
            for model_name, result in val_results.items():
                if result.get("status") == "success" and result.get("metrics"):
                    if result["metrics"].get("r2", 0) >= 0.7 and result["metrics"].get("accuracy_rate", 0) >= 0.85:
                        qualified_models_dict[model_name] = result
        
        if qualified_models_dict:
            print(f"\nFound {len(qualified_models_dict)} qualified models")
            best_models.update(qualified_models_dict)
            # Continue even if qualified models found
            print("Note: Will continue using all models for prediction")
            # Don't exit immediately, continue completing iteration
        
        if iteration == max_iterations - 1:
            print(f"\n⚠️ Reached maximum iterations ({max_iterations})")
    
    # Use all models from the last round for prediction
    print(f"\n{'='*70}")
    print("=== Final Stage: Using All Models for Prediction ===")
    print(f"{'='*70}")
    
    if validation_data is not None and len(validation_data) > 0:
        # Get last round's optimized models
        if all_results:
            last_iteration = max(all_results.keys())
            last_optimized_models = all_results[last_iteration]["optimized_models"]
            last_cv_predictions = all_results[last_iteration].get("cv_predictions", None)
            last_test_predictions = all_results[last_iteration].get("test_predictions", None)
            
            print(f"Using all models from iteration {last_iteration+1} for prediction")
            print(f"Available models: {len([m for m in last_optimized_models.values() if 'status' in m and m['status'] != 'failed'])}")
            
            # Save all prediction data
            if experiment_dir is not None:
                # Save CV prediction data
                if last_cv_predictions is not None:
                    cv_final_path = os.path.join(experiment_dir, "predictions", "FINAL_cv_predictions.csv")
                    last_cv_predictions.to_csv(cv_final_path, index=False, encoding="utf-8-sig")
                    print(f" Final CV prediction data saved to: {cv_final_path}")
                
                # Save test set prediction data
                if last_test_predictions is not None:
                    test_final_path = os.path.join(experiment_dir, "predictions", "FINAL_test_predictions.csv")
                    last_test_predictions.to_csv(test_final_path, index=False, encoding="utf-8-sig")
                    print(f"Final test set prediction data saved to: {test_final_path}")
            
            # Use all models for prediction
            final_val_results, final_val_detail_df, final_all_predictions = evaluate_all_models_on_validation(
                last_optimized_models, validation_data, feature_mask, feature_names, 
                target_col, dataset_eng.drop(columns=[target_col]).columns.tolist(),
                experiment_dir=experiment_dir
            )
    
    # If no qualified models, use best model
    if not best_models and 'val_results' in locals() and val_results:
        print("\n⚠️ No fully qualified models found, but all models will still be used for prediction")
        # Find model with highest R² and accuracy as reference
        best_model_name = None
        best_score = -1
        for model_name, result in val_results.items():
            if result.get("status") == "success" and result.get("metrics"):
                score = result["metrics"].get("r2", 0) + result["metrics"].get("accuracy_rate", 0)
                if score > best_score:
                    best_score = score
                    best_model_name = model_name
        if best_model_name:
            best_models[best_model_name] = val_results[best_model_name]
            print(f"Reference best model: {best_model_name} (R²={val_results[best_model_name]['metrics']['r2']:.3f}, Accuracy={val_results[best_model_name]['metrics']['accuracy_rate']:.1%})")
    
    # Save final results
    if best_models:
        print(f"\nFound qualified models: {list(best_models.keys())}")
        for model_name, result in best_models.items():
            metrics = result["metrics"]
            print(f"{model_name}: R²={metrics.get('r2', 0):.3f}, Accuracy={metrics.get('accuracy_rate', 0):.1%}")
    else:
        print("\n⚠️ No qualified models found, but all models can still be used for prediction")
    
    # Save feature mask and feature names
    if 'feature_mask' in locals():
        np.save(os.path.join(experiment_dir, "feature_mask.npy"), feature_mask)
    if 'feature_names' in locals():
        joblib.dump(feature_names, os.path.join(experiment_dir, "phrr_train_features.pkl"))
    
    # Create experiment completion summary
    completion_summary_path = os.path.join(experiment_dir, "experiment_completion_summary.txt")
    with open(completion_summary_path, 'w', encoding='utf-8') as f:
        f.write("PHRR Model Evaluation Experiment Completion Summary\n")
        f.write("="*70 + "\n")
        f.write(f"Completion Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Experiment Directory: {experiment_dir}\n")
        f.write(f"Random Seed: {random_seed}\n")
        f.write(f"Iterations: {max_iterations}\n")
        f.write(f"Total Training Samples: {len(dataset_eng)}\n")
        f.write(f"Total Trained Models: {len(all_optimized_models)}\n")
        f.write(f"Found Qualified Models: {len(best_models)}\n")
        f.write(f"\nImportant Output Files:\n")
        f.write(f"1. All Models Prediction Results: {os.path.join(experiment_dir, 'all_models_predictions', 'all_models_validation_predictions.csv')}\n")
        f.write(f"2. 5-Fold CV Predictions: {os.path.join(experiment_dir, 'predictions', 'FINAL_cv_predictions.csv')}\n")
        f.write(f"3. Test Set Predictions: {os.path.join(experiment_dir, 'predictions', 'FINAL_test_predictions.csv')}\n")
        f.write(f"4. Validation Set Detailed Results: {os.path.join(experiment_dir, 'PHRR_validation_all_models_details.xlsx')}\n")
        f.write(f"5. Feature Selection Results: {os.path.join(experiment_dir, 'feature_selection', 'selected_features.csv')}\n")
        f.write(f"6. Model Files: {os.path.join(experiment_dir, 'models')}\n")
    
    # Print experiment completion information
    print("\n" + "="*70)
    print(f"===== Experiment Completion Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} =====")
    print(f"===== All Results Saved to: {experiment_dir} =====")
    print("="*70)
    
    print(f"\nImportant Output Files:")
    print(f"  1. All Models Prediction Results: {os.path.join(experiment_dir, 'all_models_predictions', 'all_models_validation_predictions.csv')}")
    print(f"  2. 5-Fold CV Predictions: {os.path.join(experiment_dir, 'predictions', 'FINAL_cv_predictions.csv')}")
    print(f"  3. Test Set Predictions: {os.path.join(experiment_dir, 'predictions', 'FINAL_test_predictions.csv')}")
    print(f"  4. Validation Set Detailed Results: {os.path.join(experiment_dir, 'PHRR_validation_all_models_details.xlsx')}")
    
    # Return core results
    return {
        "experiment_dir": experiment_dir,
        "all_optimized_models": all_optimized_models,
        "best_models": best_models,
        "feature_mask": feature_mask if 'feature_mask' in locals() else None,
        "best_features": best_feats if 'best_feats' in locals() else []
    }

if __name__ == "__main__":
    # Run main program
    results = main(random_seed=11)
    
    # Print final prompt
    print(f"\nExperiment Completed!")
    print(f"All models (regardless of quality) have been used for prediction")
    print(f"All prediction data has been completely output")
    print(f"Detailed prediction results: {os.path.join(results['experiment_dir'], 'all_models_predictions')}")
    print(f"All prediction data: {os.path.join(results['experiment_dir'], 'predictions')}")