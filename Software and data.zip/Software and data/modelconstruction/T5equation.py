# -*- coding: utf-8 -*-
"""
Created on Thu Jan 22 16:07:06 2026

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
Ridge Regression Coefficient Formula Extraction - Direct Feature File Reading Version
"""
import os
import numpy as np
import pandas as pd
import joblib
from datetime import datetime
import json

def read_selected_features(file_path):
    """Read selected feature file"""
    print(f"Reading feature file: {file_path}")
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read().strip()
    
    print("="*60)
    print("Feature file content:")
    print(content)
    print("="*60)
    
    # Parse feature file
    features = []
    lines = content.split('\n')
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        # Skip header rows
        if "selected features" in line.lower():
            continue
            
        # Handle different formats
        # Format 1: "1. PP"
        if '.' in line and line.split('.')[0].strip().isdigit():
            feature = line.split('.', 1)[1].strip()
            # Clean up possible extra information
            feature = feature.split(':')[0].strip()
            feature = feature.split('(')[0].strip()
            features.append(feature)
        # Format 2: Direct feature name
        elif line and not line.startswith('#') and not line.isdigit():
            features.append(line)
    
    print(f"Parsed {len(features)} features:")
    for i, feat in enumerate(features):
        print(f"  {i+1}. {feat}")
    
    return features

def main():
    print("="*80)
    print("Ridge Regression Coefficient Formula Extraction")
    print("="*80)
    
    # Your file paths
    MODEL_PATH = r"C:\Users\ma'wei'bin\Desktop\聚合物复合材料机器学习 加工艺参数\热稳定性数据\6月新尝试\1113\T5% -0901\Ridge.pkl"
    FEATURE_FILE = r"C:\Users\ma'wei'bin\Desktop\聚合物复合材料机器学习 加工艺参数\热稳定性数据\6月新尝试\1113\T5% -0901\selected_features.txt"
    
    print(f"Model path: {MODEL_PATH}")
    print(f"Feature file: {FEATURE_FILE}")
    
    # 1. Read feature file
    try:
        feature_names = read_selected_features(FEATURE_FILE)
    except Exception as e:
        print(f"Failed to read feature file: {e}")
        return
    
    # 2. Load model
    print("\n" + "="*60)
    print("Loading ridge regression model...")
    try:
        ridge_model = joblib.load(MODEL_PATH)
        coefficients = ridge_model.coef_.flatten()
        intercept = ridge_model.intercept_
        
        print(f"Model loaded successfully")
        print(f"Intercept: {intercept:.6f}")
        print(f"Number of coefficients: {len(coefficients)}")
        
        if hasattr(ridge_model, 'alpha'):
            print(f"Regularization parameter alpha: {ridge_model.alpha}")
        
    except Exception as e:
        print(f"Failed to load model: {e}")
        return
    
    # 3. Check if feature and coefficient counts match
    print("\n" + "="*60)
    print("Checking feature matching...")
    
    if len(feature_names) != len(coefficients):
        print(f"Feature count ({len(feature_names)}) does not match coefficient count ({len(coefficients)})")
        
        # If there's one extra feature, it might be a header
        if len(feature_names) == len(coefficients) + 1:
            print("Possible header in first row, attempting to remove it...")
            feature_names = feature_names[1:]
            print(f"Adjusted feature count: {len(feature_names)}")
        
        # If still not matching, use generic names
        if len(feature_names) != len(coefficients):
            print("Using generic feature names...")
            feature_names = [f"Feature_{i+1}" for i in range(len(coefficients))]
    
    print(f"Feature matching completed: {len(feature_names)} features")
    
    # 4. Display coefficient information
    print("\n" + "="*60)
    print("Ridge Regression Coefficient Details")
    print("="*60)
    
    # Create coefficient table
    coeff_data = []
    for i, (name, coeff) in enumerate(zip(feature_names, coefficients)):
        coeff_data.append({
            'Index': i+1,
            'Feature Name': name,
            'Coefficient Value': coeff,
            'Absolute Value': abs(coeff)
        })
    
    df_coeff = pd.DataFrame(coeff_data)
    
    # Sort by absolute value
    df_coeff_sorted = df_coeff.sort_values('Absolute Value', ascending=False)
    
    print("\nCoefficient ranking (sorted by absolute value, descending):")
    print("-"*70)
    print(f"{'Rank':<5} {'Feature Name':<20} {'Coefficient':<15} {'Abs Value':<15}")
    print("-"*70)
    
    for idx, row in df_coeff_sorted.iterrows():
        rank = idx + 1
        sign = '+' if row['Coefficient Value'] >= 0 else '-'
        print(f"{rank:<5} {row['Feature Name'][:18]:<20} {sign} {abs(row['Coefficient Value']):<14.6f} {row['Absolute Value']:<14.6f}")
    
    # 5. Generate formula
    print("\n" + "="*60)
    print("Ridge Regression Formula")
    print("="*60)
    
    # 5.1 Complete formula (step-by-step display)
    print("\nComplete formula (step-by-step display):")
    print(f"T5% = {intercept:.6f}")
    
    for name, coeff in zip(feature_names, coefficients):
        if abs(coeff) > 1e-10:  # Ignore very small coefficients
            sign = " + " if coeff > 0 else " - "
            print(f"{sign} {abs(coeff):.6f} × {name}")
    
    # 5.2 Simplified formula (|coefficient| > 0.001)
    print("\nSimplified formula (|coefficient| > 0.001):")
    simplified_parts = [f"T5% ≈ {intercept:.4f}"]
    
    significant_terms = []
    for name, coeff in zip(feature_names, coefficients):
        if abs(coeff) > 0.001:
            sign = "+" if coeff > 0 else "-"
            significant_terms.append(f"{sign} {abs(coeff):.4f}×{name}")
    
    if significant_terms:
        # Handle leading sign
        formula_line = " ".join(significant_terms)
        if formula_line.startswith("+ "):
            formula_line = formula_line[2:]
        elif formula_line.startswith("- "):
            formula_line = "-" + formula_line[2:]
        
        simplified_formula = simplified_parts[0] + " " + formula_line
        print(simplified_formula)
        print(f"(Includes {len(significant_terms)} significant coefficients)")
    
    # 5.3 One-line formula (for programming)
    print("\nOne-line formula (suitable for programming):")
    code_parts = [f"T5% = {intercept:.6f}"]
    
    for name, coeff in zip(feature_names, coefficients):
        if abs(coeff) > 1e-10:
            sign = "+" if coeff > 0 else ""
            code_parts.append(f"{sign}{coeff:.6f}*{name}")
    
    code_formula = " ".join(code_parts).replace("+ -", "- ").replace(" ", "")
    print(code_formula)
    
    # 6. Save results
    print("\n" + "="*60)
    print("Saving results...")
    
    # Create output directory
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = f"Ridge_Regression_Formula_Results_{timestamp}"
    os.makedirs(output_dir, exist_ok=True)
    
    # 6.1 Save coefficient table
    coeff_csv_path = os.path.join(output_dir, "Ridge_Regression_Coefficients.csv")
    df_coeff.to_csv(coeff_csv_path, index=False, encoding='utf-8-sig')
    print(f"Coefficient table: {coeff_csv_path}")
    
    # 6.2 Save sorted coefficient table
    sorted_csv_path = os.path.join(output_dir, "Ridge_Regression_Coefficients_Sorted.csv")
    df_coeff_sorted.to_csv(sorted_csv_path, index=False, encoding='utf-8-sig')
    print(f"Sorted coefficients: {sorted_csv_path}")
    
    # 6.3 Save formula file
    formula_txt_path = os.path.join(output_dir, "Ridge_Regression_Formula.txt")
    with open(formula_txt_path, 'w', encoding='utf-8') as f:
        f.write("="*80 + "\n")
        f.write("Ridge Regression Model Coefficients and Formula\n")
        f.write("="*80 + "\n\n")
        
        f.write("Model Information:\n")
        f.write("-"*40 + "\n")
        f.write(f"Model file: {os.path.basename(MODEL_PATH)}\n")
        f.write(f"Feature file: {os.path.basename(FEATURE_FILE)}\n")
        f.write(f"Intercept: {intercept:.6f}\n")
        f.write(f"Number of coefficients: {len(coefficients)}\n\n")
        
        f.write("Feature List:\n")
        f.write("-"*40 + "\n")
        for i, name in enumerate(feature_names):
            f.write(f"{i+1}. {name}\n")
        
        f.write("\n" + "="*80 + "\n")
        f.write("Coefficient Ranking (Sorted by Absolute Value, Descending)\n")
        f.write("="*80 + "\n")
        f.write(f"{'Rank':<5} {'Feature Name':<20} {'Coefficient':<15} {'Abs Value':<15}\n")
        f.write("-"*80 + "\n")
        
        for idx, row in df_coeff_sorted.iterrows():
            rank = idx + 1
            sign = '+' if row['Coefficient Value'] >= 0 else '-'
            f.write(f"{rank:<5} {row['Feature Name'][:18]:<20} {sign} {abs(row['Coefficient Value']):<14.6f} {row['Absolute Value']:<14.6f}\n")
        
        f.write("\n" + "="*80 + "\n")
        f.write("Complete Formula\n")
        f.write("="*80 + "\n")
        f.write(f"T5% = {intercept:.6f}\n")
        
        for name, coeff in zip(feature_names, coefficients):
            if abs(coeff) > 1e-10:
                sign = " + " if coeff > 0 else " - "
                f.write(f"{sign} {abs(coeff):.6f} × {name}\n")
        
        f.write("\n" + "="*80 + "\n")
        f.write("One-line Formula (For Programming)\n")
        f.write("="*80 + "\n")
        f.write(code_formula + "\n")
        
        if significant_terms:
            f.write("\n" + "="*80 + "\n")
            f.write("Simplified Formula (|coefficient| > 0.001)\n")
            f.write("="*80 + "\n")
            f.write(simplified_formula + "\n")
    
    print(f"Formula file: {formula_txt_path}")
    
    # 6.4 Save model information as JSON
    model_info = {
        "timestamp": timestamp,
        "model_file": os.path.basename(MODEL_PATH),
        "feature_file": os.path.basename(FEATURE_FILE),
        "intercept": float(intercept),
        "feature_count": len(coefficients),
        "coefficients": {
            name: float(coeff) for name, coeff in zip(feature_names, coefficients)
        },
        "formula": code_formula
    }
    
    json_path = os.path.join(output_dir, "Ridge_Regression_Model_Info.json")
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(model_info, f, indent=2, ensure_ascii=False)
    print(f"Model information: {json_path}")
    
    # 6.5 Generate Python predictor
    predictor_path = os.path.join(output_dir, "Ridge_Regression_Predictor.py")
    
    # Create safe feature names (for Python variables)
    safe_feature_names = []
    for name in feature_names:
        safe_name = name
        # Replace special characters
        for char in ['(', ')', '%', ' ', '-', '.', '℃', '°']:
            safe_name = safe_name.replace(char, '_')
        # Ensure it starts with a letter
        if safe_name and not safe_name[0].isalpha():
            safe_name = 'feature_' + safe_name
        safe_feature_names.append(safe_name)
    
    with open(predictor_path, 'w', encoding='utf-8') as f:
        f.write(f'''# -*- coding: utf-8 -*-
"""
Ridge Regression Model Predictor
Generated at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""

import numpy as np

class RidgePredictor:
    """Ridge Regression Predictor"""
    
    def __init__(self):
        # Intercept
        self.intercept = {intercept}
        
        # Coefficients
        self.coefficients = np.array({list(coefficients)})
        
        # Feature names
        self.feature_names = {feature_names}
        
        # Safe feature names (for variable names)
        self.safe_feature_names = {safe_feature_names}
    
    def predict(self, X):
        """
        Prediction function
        
        Parameters:
        X: Input feature array, shape (n_samples, n_features)
            or single sample, shape (n_features,)
        
        Returns:
        predictions: Predicted values
        """
        X = np.asarray(X)
        
        # If it's a 1D array (single sample), convert to 2D
        if X.ndim == 1:
            X = X.reshape(1, -1)
        
        # Check feature count
        if X.shape[1] != len(self.coefficients):
            raise ValueError(f"Input feature count ({{X.shape[1]}}) does not match model coefficient count ({{len(self.coefficients)}})")
        
        # Calculate predictions: y = intercept + Σ(coeff_i * x_i)
        predictions = self.intercept + np.dot(X, self.coefficients)
        
        # If only one sample, return scalar
        if predictions.shape[0] == 1:
            return predictions[0]
        return predictions
    
    def get_formula(self):
        """Get formula string"""
        formula_parts = [f"T5% = {{self.intercept:.6f}}"]
        
        for feature, coeff in zip(self.feature_names, self.coefficients):
            if abs(coeff) > 1e-10:
                sign = "+" if coeff > 0 else ""
                formula_parts.append(f"{{sign}}{{coeff:.6f}}*{{feature}}")
        
        formula = " ".join(formula_parts).replace("+ -", "- ").replace(" ", "")
        return formula
    
    def calculate_manual(self, **kwargs):
        """
        Manual prediction calculation (using keyword arguments)
        
        Example:
        predictor.calculate_manual(PP=1.0, AAPP=2.0, ...)
        """
        if len(kwargs) != len(self.coefficients):
            raise ValueError(f"Expected {{len(self.coefficients)}} feature values")
        
        # Ensure correct feature order
        feature_values = []
        for name in self.feature_names:
            if name not in kwargs:
                # Try using safe name
                safe_idx = self.feature_names.index(name)
                safe_name = self.safe_feature_names[safe_idx]
                if safe_name in kwargs:
                    feature_values.append(kwargs[safe_name])
                else:
                    raise ValueError(f"Missing feature value: {{name}}")
            else:
                feature_values.append(kwargs[name])
        
        X = np.array(feature_values).reshape(1, -1)
        return self.predict(X)[0]

# Usage example
if __name__ == "__main__":
    # Create predictor
    predictor = RidgePredictor()
    
    # Print formula
    print("Ridge Regression Formula:")
    print(predictor.get_formula())
    
    print("\\nFeature List:")
    for i, name in enumerate(predictor.feature_names):
        print(f"  {{i+1}}. {{name}} (variable name: {{predictor.safe_feature_names[i]}})")
    
    print("\\nExample prediction - Create a random sample:")
    np.random.seed(42)
    
    # Create random sample
    X_sample = np.random.randn(1, {len(coefficients)})
    prediction = predictor.predict(X_sample)
    print(f"Input sample: {{X_sample[0]}}")
    print(f"Prediction result: {{prediction}}")
''')
    
    print(f"Python predictor: {predictor_path}")
    
    # 7. Final output
    print("\n" + "="*80)
    print("Analysis completed!")
    print("="*80)
    print(f"All results saved to: {output_dir}")
    print("\nRidge Regression Formula:")
    print("-"*80)
    print(code_formula)
    print("-"*80)
    
    print("\nImportant features (sorted by impact):")
    print("  1. " + df_coeff_sorted.iloc[0]['Feature Name'] + f" (coefficient: {df_coeff_sorted.iloc[0]['Coefficient Value']:.4f})")
    print("  2. " + df_coeff_sorted.iloc[1]['Feature Name'] + f" (coefficient: {df_coeff_sorted.iloc[1]['Coefficient Value']:.4f})")
    print("  3. " + df_coeff_sorted.iloc[2]['Feature Name'] + f" (coefficient: {df_coeff_sorted.iloc[2]['Coefficient Value']:.4f})")

if __name__ == "__main__":
    main()