# -*- coding: utf-8 -*-
"""
SHAP Analysis - GBR Model Interpretability on Training Set
Combined plot with bar chart embedded on the left side of beeswarm plot
"""

import os
import numpy as np
import pandas as pd
import joblib
import shap
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import matplotlib.ticker as ticker
import gc
import warnings
warnings.filterwarnings('ignore')

# ========== Set Times New Roman font ==========
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.dpi'] = 100
plt.rcParams['savefig.dpi'] = 200

# ========== Configuration ==========
TARGET_COL = 'PHRR(Kw/m2)'
RAW_DATA_FILE = 'Your augmented PHRR file'
EXPERIMENT_DIR = r"Your enhanced model results"
MODEL_NAME = 'Gradient Boosting Regressor'

# Create output directory FIRST
output_dir = os.path.join(EXPERIMENT_DIR, "shap_analysis_train_set")
os.makedirs(output_dir, exist_ok=True)

# ========== Feature Engineering Function (Same as modeling code) ==========
def feature_engineering(data, target_col=None, train_features=None):
    """Feature engineering - exactly same as training"""
    df = data.copy()
    
    if 'NO' in df.columns:
        df = df.drop(columns=['NO'])
    
    additive_cols = ['PAPP', 'MPP', 'W', 'ZS', 'ADP']
    existing_additive = [col for col in additive_cols if col in df.columns]
    if existing_additive:
        df['total_ad'] = df[existing_additive].sum(axis=1)
        df['additive_ratio'] = df['total_ad'] / (df[existing_additive].max(axis=1) + 1e-6)
    else:
        df['total_ad'] = 0
        df['additive_ratio'] = 0
    
    if 'PAPP' in df.columns and 'total_ad' in df.columns:
        df['PAPP_ratio'] = df['PAPP'] / (df['total_ad'] + 1e-6)
    else:
        df['PAPP_ratio'] = 0
    
    if 'MPP' in df.columns and 'total_ad' in df.columns:
        df['MPP_ratio'] = df['MPP'] / (df['total_ad'] + 1e-6)
    else:
        df['MPP_ratio'] = 0
    
    synergist_cols = ['W', 'ZS', 'ADP']
    existing_synergist = [col for col in synergist_cols if col in df.columns]
    if existing_synergist:
        df['synergist_total'] = df[existing_synergist].sum(axis=1)
        if 'W' in df.columns:
            df['W_ratio_in_synergist'] = df['W'] / (df['synergist_total'] + 1e-6)
        else:
            df['W_ratio_in_synergist'] = 0
    else:
        df['synergist_total'] = 0
        df['W_ratio_in_synergist'] = 0
    
    if all(col in df.columns for col in ['PAPP', 'MPP', 'W']):
        df['PAPP_MPP_W_interaction'] = df['PAPP'] * df['MPP'] * df['W']
    else:
        df['PAPP_MPP_W_interaction'] = 0
    
    if 'PAPP' in df.columns:
        df['PAPP_square'] = df['PAPP'] ** 2
    else:
        df['PAPP_square'] = 0
    
    if 'MPP' in df.columns:
        df['MPP_square'] = df['MPP'] ** 2
    else:
        df['MPP_square'] = 0
    
    if all(col in df.columns for col in ['PAPP', 'MPP']):
        df['PAPP_MPP_ratio'] = df['PAPP'] / (df['MPP'] + 1e-6)
    
    if all(col in df.columns for col in ['PAPP', 'W']):
        df['PAPP_W_ratio'] = df['PAPP'] / (df['W'] + 1e-6)
    
    if 'PAPP' in df.columns:
        df['PAPP_sqrt'] = np.sqrt(df['PAPP'])
    
    if 'MPP' in df.columns:
        df['MPP_sqrt'] = np.sqrt(df['MPP'])
    
    if all(col in df.columns for col in ['ZS', 'total_ad']):
        df['ZS_ratio'] = df['ZS'] / (df['total_ad'] + 1e-6)
    
    if all(col in df.columns for col in ['W', 'total_ad']):
        df['W_ratio'] = df['W'] / (df['total_ad'] + 1e-6)
    if all(col in df.columns for col in ['ADP', 'total_ad']):
        df['ADP_ratio'] = df['ADP'] / (df['total_ad'] + 1e-6)
    
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if target_col and target_col in numeric_cols:
        numeric_cols.remove(target_col)
    
    if train_features is not None:
        train_features = [f for f in train_features if f != 'NO' and f in numeric_cols + ([target_col] if target_col else [])]
        for feat in train_features:
            if feat not in df.columns:
                df[feat] = 0
        if target_col and target_col in df.columns:
            df = df[train_features + [target_col]]
        else:
            df = df[train_features]
    
    return df

# ========== Combined plot function ==========
def create_combined_plot(shap_values, X_train, feature_names, expected_value, output_dir):
    """
    Create combined plot: feature importance bar chart embedded on left side of beeswarm plot
    """
    print("\n4. Creating combined plot...")
    
    try:
        # Calculate feature importance (mean absolute SHAP value)
        importance = np.abs(shap_values).mean(axis=0)
        
        # Sort by importance (descending)
        sorted_idx = np.argsort(importance)[::-1]
        sorted_features = [feature_names[i] for i in sorted_idx]
        sorted_importance = importance[sorted_idx]
        sorted_shap = shap_values[:, sorted_idx]
        sorted_X = X_train[:, sorted_idx]
        
        n_features = len(sorted_features)
        
        # Create DataFrame
        X_train_df = pd.DataFrame(sorted_X, columns=sorted_features)
        
        # Save original settings
        original_font_size = plt.rcParams['font.size']
        original_axes_labelsize = plt.rcParams['axes.labelsize']
        original_axes_titlesize = plt.rcParams['axes.titlesize']
        original_xtick_labelsize = plt.rcParams['xtick.labelsize']
        original_ytick_labelsize = plt.rcParams['ytick.labelsize']
        
        # Set large fonts
        plt.rcParams['font.size'] = 54
        plt.rcParams['axes.labelsize'] = 64
        plt.rcParams['axes.titlesize'] = 72
        plt.rcParams['xtick.labelsize'] = 54
        plt.rcParams['ytick.labelsize'] = 54
        
        # Create figure
        fig = plt.figure(figsize=(40, 24))
        
        # Force larger scatter points
        import matplotlib.pyplot as plt_orig
        original_scatter = plt_orig.scatter
        
        def scatter_with_forced_large_dots(*args, **kwargs):
            kwargs['s'] = 300  # dot size
            return original_scatter(*args, **kwargs)
        
        plt_orig.scatter = scatter_with_forced_large_dots
        
        # Draw beeswarm plot
        shap.summary_plot(sorted_shap, X_train_df, 
                         feature_names=sorted_features,
                         show=False, 
                         max_display=n_features,
                         plot_size=None,
                         color_bar=True)
        
        plt_orig.scatter = original_scatter
        
        # Get current axes
        ax = plt.gca()
        
        # Force modify dot sizes
        for collection in ax.collections:
            if hasattr(collection, 'set_sizes'):
                try:
                    collection.set_sizes([300])
                except:
                    pass
        
        # Find and modify colorbar font
        cbar_ax = None
        for fig_ax in fig.get_axes():
            if hasattr(fig_ax, 'get_ylabel') and fig_ax.get_ylabel() == 'Feature value':
                cbar_ax = fig_ax
                break
        
        if cbar_ax is None:
            for fig_ax in fig.get_axes():
                if fig_ax != ax and fig_ax.get_position().width < 0.1:
                    cbar_ax = fig_ax
                    break
        
        if cbar_ax is not None:
            try:
                cbar_ax.set_ylabel('Feature value', fontsize=48, fontweight='bold', 
                                 fontname='Times New Roman', labelpad=40)
                cbar_ax.tick_params(labelsize=42)
                for label in cbar_ax.get_yticklabels():
                    label.set_fontname('Times New Roman')
                    label.set_fontsize(42)
                print("   ✅ Colorbar fonts set to 48pt/42pt")
            except Exception as e:
                print(f"   ⚠️ Colorbar font adjustment failed: {e}")
        
        # Set title
        ax.set_title(r'SHAP value of PHRR (Kw/m$^{2}$)', 
                    fontsize=72, fontweight='bold', fontname='Times New Roman', pad=50)
        
        # Set x-axis label
        ax.set_xlabel('SHAP value (impact on model output)', 
                     fontsize=64, fontweight='bold', fontname='Times New Roman', labelpad=45)
        
        # Set y-axis label
        ax.set_ylabel('Features', 
                     fontsize=64, fontweight='bold', fontname='Times New Roman', labelpad=45)
        
        # Set tick fonts
        ax.tick_params(axis='both', which='major', labelsize=54, pad=20)
        for label in ax.get_xticklabels():
            label.set_fontname('Times New Roman')
            label.set_fontsize(54)
        for label in ax.get_yticklabels():
            label.set_fontname('Times New Roman')
            label.set_fontsize(54)
        
        # Set denser X-axis ticks
        x_min, x_max = ax.get_xlim()
        ax.xaxis.set_major_locator(ticker.MultipleLocator(50))
        ax.xaxis.set_minor_locator(ticker.MultipleLocator(10))
        ax.set_xlim(x_min, x_max)
        ax.grid(True, alpha=0.1, axis='x', which='minor', linestyle=':', linewidth=1.2, color='#CCCCCC')
        
        # Get axis limits for adding bar charts and value labels
        x_min, x_max = ax.get_xlim()
        x_range = x_max - x_min
        bar_x_start = x_min
        y_positions = ax.get_yticks()
        y_labels = [label.get_text() for label in ax.get_yticklabels()]
        max_importance = max(sorted_importance)
        
        # Gap between feature name and importance value
        gap_between = 0.002
        
        # Draw bar chart and add value label for each feature
        for i, (feat_name, y_pos) in enumerate(zip(y_labels, y_positions)):
            if feat_name in sorted_features:
                feat_idx = sorted_features.index(feat_name)
                importance_value = sorted_importance[feat_idx]
                importance_ratio = importance_value / max_importance
                bar_width = importance_ratio * x_range * 0.25
                
                # Draw bar chart - light red, transparency 0.35
                ax.barh(y_pos, bar_width, left=bar_x_start, 
                       color='#FFB6C1', alpha=0.35, height=0.7,
                       edgecolor='none', linewidth=0)
                
                # Add feature importance value label - brown
                label_x = bar_x_start - x_range * gap_between
                label_text = f'{importance_value:.1f}'
                
                ax.text(label_x, y_pos, label_text,
                       va='center', ha='right', fontsize=48, fontweight='bold',
                       fontname='Times New Roman', color='#8B4513', alpha=0.9)
        
        # Adjust X-axis range
        ax.set_xlim(x_min - x_range * 0.05, x_max)
        
        # Set main grid
        ax.grid(True, alpha=0.15, axis='x', which='major', linestyle='--', linewidth=1.5, color='#999999')
        
        # Set spines
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.spines['left'].set_linewidth(2.5)
        ax.spines['bottom'].set_linewidth(2.5)
        
        # Adjust layout
        plt.tight_layout()
        
        # Save image
        save_path = os.path.join(output_dir, 'shap_combined_plot_GBR.png')
        plt.savefig(save_path, dpi=300, bbox_inches='tight', format='png', pad_inches=0.8)
        plt.close()
        
        # Force garbage collection
        gc.collect()
        
        # Restore original matplotlib global parameters
        plt.rcParams['font.size'] = original_font_size
        plt.rcParams['axes.labelsize'] = original_axes_labelsize
        plt.rcParams['axes.titlesize'] = original_axes_titlesize
        plt.rcParams['xtick.labelsize'] = original_xtick_labelsize
        plt.rcParams['ytick.labelsize'] = original_ytick_labelsize
        
        print(f"   ✅ Combined plot saved to: {save_path}")
        print(f"   ✅ Title: 72pt bold")
        print(f"   ✅ Axis labels: 64pt bold")
        print(f"   ✅ Tick labels: 54pt")
        print(f"   ✅ Importance values: 48pt bold (brown #8B4513)")
        print(f"   ✅ Dot size: 300")
        print(f"   ✅ Colorbar label: 48pt bold")
        print(f"   ✅ Colorbar tick labels: 42pt")
        
        return fig
        
    except Exception as e:
        print(f"   ❌ Failed to create combined plot: {e}")
        import traceback
        traceback.print_exc()
        
        try:
            plt.rcParams['font.size'] = original_font_size
            plt.rcParams['axes.labelsize'] = original_axes_labelsize
            plt.rcParams['axes.titlesize'] = original_axes_titlesize
            plt.rcParams['xtick.labelsize'] = original_xtick_labelsize
            plt.rcParams['ytick.labelsize'] = original_ytick_labelsize
        except:
            pass
        
        return None

# ========== 1. Load raw data ==========
print("="*60)
print("SHAP Analysis - GBR Model Interpretability on Training Set")
print("="*60)
print(f"Experiment directory: {EXPERIMENT_DIR}")
print(f"Model: {MODEL_NAME}")
print(f"Output directory: {output_dir}")

print("\n1. Loading raw data...")
dataset = pd.read_excel(RAW_DATA_FILE)

# Remove NO column
if 'NO' in dataset.columns:
    initial_count = len(dataset)
    dataset = dataset.drop(columns=['NO'], errors='ignore')
    print(f"   Removed NO column (original: {initial_count}, after: {len(dataset)})")

# Target value filtering
clean_mask = (dataset[TARGET_COL] > 10) & (dataset[TARGET_COL] <= 1000)
dataset = dataset[clean_mask].copy().reset_index(drop=True)
print(f"   After target filtering: {len(dataset)} samples")

# Keep only numerical features
numeric_cols = dataset.select_dtypes(include=[np.number]).columns.tolist()
if TARGET_COL in numeric_cols:
    numeric_cols.remove(TARGET_COL)
dataset = dataset[numeric_cols + [TARGET_COL]].copy()
print(f"   Numerical features only: {len(numeric_cols)} features")

# Fill missing values
dataset[numeric_cols] = dataset[numeric_cols].fillna(dataset[numeric_cols].median())
print(f"   Missing values filled")

# ========== 2. Feature engineering ==========
print("\n2. Feature engineering...")
df_eng = feature_engineering(dataset, target_col=TARGET_COL)
print(f"   Features after engineering: {df_eng.shape[1] - 1}")

# ========== 3. Load selected features ==========
print("\n3. Loading selected features...")
selected_path = os.path.join(EXPERIMENT_DIR, "feature_selection", "selected_features.csv")
if not os.path.exists(selected_path):
    print(f"   Error: Feature selection file not found: {selected_path}")
    print("   Please ensure the experiment directory path is correct")
    exit(1)

selected_df = pd.read_csv(selected_path)
selected_features = selected_df['feature_name'].tolist()
print(f"   Selected features count: {len(selected_features)}")
print(f"   First 10 features: {selected_features[:10]}...")

# ========== 4. Prepare data ==========
print("\n4. Preparing data...")

# Check if all selected features exist
available_features = [f for f in selected_features if f in df_eng.columns]
missing_features = [f for f in selected_features if f not in df_eng.columns]
if missing_features:
    print(f"   Warning: Missing features: {missing_features}")
    selected_features = available_features

X = df_eng[selected_features].values
y = df_eng[TARGET_COL].values

print(f"   Final feature count: {X.shape[1]}")
print(f"   Total samples: {X.shape[0]}")

# ========== 5. Split training and test sets ==========
print("\n5. Splitting training and test sets...")
RANDOM_SEED = 68
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=RANDOM_SEED, shuffle=True
)
print(f"   Training set: {X_train.shape[0]} samples")
print(f"   Test set: {X_test.shape[0]} samples")

# ========== 6. Load GBR model ==========
print(f"\n6. Loading GBR model ({MODEL_NAME})...")
models_dir = os.path.join(EXPERIMENT_DIR, "models")

# Find GBR model file
model_files = []
for f in os.listdir(models_dir):
    if 'gradient_boosting' in f.lower() and f.endswith('.pkl'):
        model_files.append(f)

if not model_files:
    print(f"   Error: GBR model file not found")
    print(f"   Available models: {[f for f in os.listdir(models_dir) if f.endswith('.pkl')]}")
    exit(1)

model_files.sort(reverse=True)
model_path = os.path.join(models_dir, model_files[0])
model = joblib.load(model_path)
print(f"   Model loaded: {os.path.basename(model_path)}")
print(f"   Expected features: {model.n_features_in_ if hasattr(model, 'n_features_in_') else 'N/A'}")
print(f"   Actual features: {X_train.shape[1]}")

# Verify feature count
if hasattr(model, 'n_features_in_'):
    assert model.n_features_in_ == X_train.shape[1], f"Feature mismatch! Model: {model.n_features_in_}, Data: {X_train.shape[1]}"

# ========== 7. Calculate SHAP values ==========
print("\n7. Calculating SHAP values on training set...")
print("   Using TreeExplainer (optimized for tree-based models)")

X_train_df = pd.DataFrame(X_train, columns=selected_features)

try:
    explainer = shap.TreeExplainer(model)
    print("   TreeExplainer initialized successfully")
    
    print("   Computing SHAP values for training set...")
    shap_values_train = explainer.shap_values(X_train)
    
    if isinstance(shap_values_train, list):
        shap_values_train = shap_values_train[0]
    
    print(f"   SHAP values computed, shape: {shap_values_train.shape}")
    base_value = explainer.expected_value
    
except Exception as e:
    print(f"   TreeExplainer failed: {str(e)}")
    print("   Falling back to KernelExplainer...")
    
    background = X_train[:50]
    explainer = shap.KernelExplainer(model.predict, background, link="identity")
    
    print("   Computing SHAP values (may take a few minutes)...")
    shap_values_train = explainer.shap_values(X_train)
    
    if isinstance(shap_values_train, list):
        shap_values_train = shap_values_train[0]
    
    print(f"   SHAP values computed, shape: {shap_values_train.shape}")
    base_value = explainer.expected_value

# ========== 8. Save SHAP values and feature values to CSV ==========
print("\n8. Saving SHAP values and feature values to CSV files...")

# Save training set feature values
train_features_df = X_train_df.copy()
train_features_df['True_PHRR'] = y_train
train_features_df['Predicted_PHRR'] = model.predict(X_train)
train_features_df.to_csv(os.path.join(output_dir, "Training_Set_Feature_Values.csv"), index=True, encoding='utf-8-sig')
print(f"   Training set feature values saved: Training_Set_Feature_Values.csv")

# Save SHAP values for training set
shap_df_train = pd.DataFrame(shap_values_train, columns=[f"SHAP_{f}" for f in selected_features])
shap_df_train['True_PHRR'] = y_train
shap_df_train['Predicted_PHRR'] = model.predict(X_train)
shap_df_train.to_csv(os.path.join(output_dir, "Training_Set_SHAP_Values.csv"), index=True, encoding='utf-8-sig')
print(f"   Training set SHAP values saved: Training_Set_SHAP_Values.csv")

# ========== 9. Create combined plot ==========
fig = create_combined_plot(shap_values_train, X_train, selected_features, base_value, output_dir)

# ========== 10. Save feature importance ranking ==========
print("\n10. Calculating feature importance ranking...")

shap_mean_abs = np.abs(shap_values_train).mean(axis=0)
shap_mean = shap_values_train.mean(axis=0)

importance_df = pd.DataFrame({
    'feature': selected_features,
    'importance': shap_mean_abs,
    'mean_shap': shap_mean
}).sort_values('importance', ascending=False)

importance_df.to_csv(os.path.join(output_dir, "SHAP_Feature_Importance_Train.csv"), index=False)
print(f"   Feature importance ranking saved: {os.path.join(output_dir, 'SHAP_Feature_Importance_Train.csv')}")

# ========== 11. Output summary report ==========
print("\n" + "="*60)
print("SHAP Analysis Completed!")
print("="*60)
print(f"\nOutput directory: {output_dir}")
print(f"\nGenerated files:")
print(f"  1. Training_Set_Feature_Values.csv - Feature values for training set")
print(f"  2. Training_Set_SHAP_Values.csv - SHAP values for training set")
print(f"  3. SHAP_Feature_Importance_Train.csv - Feature importance ranking")
print(f"  4. shap_combined_plot_GBR.png - Combined SHAP plot")

print(f"\nFeature Importance Ranking (Top 10):")
for i in range(min(10, len(importance_df))):
    row = importance_df.iloc[i]
    effect = "↑ (Adverse)" if row['mean_shap'] > 0 else "↓ (Beneficial)"
    print(f"   {i+1:2d}. {row['feature']:<35} | {row['importance']:.6f} | {effect}")

print(f"\nSHAP Value Statistics:")
print(f"   SHAP value range: [{shap_values_train.min():.4f}, {shap_values_train.max():.4f}]")
print(f"   Mean |SHAP value|: {shap_mean_abs.mean():.6f}")

print("\n" + "="*60)
print("Plot Settings:")
print("  - Title: 72pt bold")
print("  - Axis labels: 64pt bold")
print("  - Tick labels: 54pt")
print("  - Importance values: 48pt bold (brown #8B4513)")
print("  - Dot size: 300")
print("  - Colorbar label: 48pt bold")
print("  - Colorbar tick labels: 42pt")
print("  - Font: Times New Roman")
print("="*60)

print("\nInterpretation Guide:")
print("  - Red/↑ : High feature values increase PHRR (adverse effect)")
print("  - Blue/↓ : High feature values decrease PHRR (beneficial effect)")
print("  - Feature importance based on mean |SHAP value|")
print("  - Background bars show importance magnitude (light red, high transparency)")
print("  - Numbers on left show exact importance values")

print("\n" + "="*60)
print("Analysis Complete!")
print("="*60)