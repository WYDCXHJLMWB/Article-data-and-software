# -*- coding: utf-8 -*-
"""
MLP Model SHAP Analysis Code - Using SHAP Library
- Use shap.KernelExplainer (MLP is not a tree model)
- Feature importance bar chart embedded directly on left side of beeswarm plot
- Bars start from leftmost X-axis, light red, high transparency
- Color bar tight to right side of main plot (zero spacing) - automatically achieved via shap.summary_plot
- Maximized fonts (Title 72pt, Axis 64pt, Ticks 54pt, Values 48pt)
- Greatly reduced distance between feature names and importance values
- Denser X-axis ticks, uniform brown color (#8B4513) for feature importance values
- Subscript format for 5% in title, add temperature unit (℃)
- Force larger dot sizes
- Force larger fonts for all elements including color bar
- Retain complete data output functionality for T5% dataset
- Fully use shap.summary_plot, no custom plotting
"""

import numpy as np
import pandas as pd
import joblib
import matplotlib.pyplot as plt
import os
import re
from datetime import datetime
from sklearn.model_selection import train_test_split
import matplotlib.ticker as ticker
import gc
import warnings
warnings.filterwarnings('ignore')

# Import SHAP
try:
    import shap
    print(f"✅ SHAP imported successfully")
    print(f"   SHAP version: {shap.__version__ if hasattr(shap, '__version__') else 'unknown'}")
except ImportError as e:
    print(f"❌ Failed to import SHAP: {e}")
    shap = None

# ============= Global font settings - Maximized fonts, avoid memory error =============
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.dpi'] = 100
plt.rcParams['savefig.dpi'] = 200

# ============= Configuration paths =============
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
print(f"\nCurrent directory: {CURRENT_DIR}")

# GA experiment directory path
GA_EXPERIMENT_DIR = r"C:\Users\ma'wei'bin\Desktop\聚合物复合材料机器学习 加工艺参数\热稳定性数据\6月新尝试\1113 - 副本\T5% -0901\ga_experiment_20260424_161900增强"

# Model path (read MLP model from GA experiment directory)
MODEL_PATH = os.path.join(GA_EXPERIMENT_DIR, "final_iteration", "models", "MLP.pkl")

# Feature file path
FEATURE_FILE = os.path.join(GA_EXPERIMENT_DIR, "final_iteration", "selected_features.txt")

# Data path
DATA_PATH = os.path.join(CURRENT_DIR, "T5%A1.xlsx")
TARGET_COLUMN = 'T5%(℃)'

# Create output directory
OUTPUT_DIR = os.path.join(CURRENT_DIR, "SHAP_Results_MLP_GA")
os.makedirs(OUTPUT_DIR, exist_ok=True)
print(f"Output directory: {OUTPUT_DIR}")

# ============= Data loading function =============
def load_data():
    """Load data"""
    if not os.path.exists(DATA_PATH):
        raise FileNotFoundError(f"Data file not found: {DATA_PATH}")
    
    df = pd.read_excel(DATA_PATH)
    target = TARGET_COLUMN
    if 'NO' in df.columns:
        df = df.drop(columns=['NO'])
    X = df.drop(columns=[target])
    y = df[target]
    return X.values, y, X.columns.tolist()

# ============= Load model and data =============
def load_model_and_data(output_dir):
    """Load MLP model and data - read from GA experiment directory"""
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"Model file not found: {MODEL_PATH}")
    
    if not os.path.exists(DATA_PATH):
        raise FileNotFoundError(f"Data file not found: {DATA_PATH}")
    
    model = joblib.load(MODEL_PATH)
    print(f"\nModel loaded: {MODEL_PATH}")
    print(f"Model type: {type(model).__name__}")
    
    X_full, y_full, all_features = load_data()
    print(f"Data loaded: {DATA_PATH}, total samples: {X_full.shape[0]}")
    
    X_train, X_test, y_train, y_test = train_test_split(
        X_full, y_full, 
        test_size=0.2, 
        random_state=709,  # Consistent with GA experiment random seed
        shuffle=True
    )
    print(f"Training set: samples={X_train.shape[0]}, features={X_train.shape[1]}")
    print(f"Test set: samples={X_test.shape[0]}, features={X_test.shape[1]}")
    
    # Save training set and test set data
    train_df = pd.DataFrame(X_train, columns=all_features)
    train_df[TARGET_COLUMN] = y_train
    train_save_path = os.path.join(output_dir, "training_set_data.csv")
    train_df.to_csv(train_save_path, index=False, encoding="utf-8-sig")
    print(f"Training set data saved: {train_save_path}")
    
    test_df = pd.DataFrame(X_test, columns=all_features)
    test_df[TARGET_COLUMN] = y_test
    test_save_path = os.path.join(output_dir, "test_set_data.csv")
    test_df.to_csv(test_save_path, index=False, encoding="utf-8-sig")
    print(f"Test set data saved: {test_save_path}")
    
    # Get selected features
    if os.path.exists(FEATURE_FILE):
        print(f"\nUsing feature file: {FEATURE_FILE}")
        with open(FEATURE_FILE, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        selected_features = []
        for line in lines:
            line = line.strip()
            if not line or "selected features" in line:
                continue
            match = re.match(r'^\d+\.\s*(.+)$', line)
            if match:
                selected_features.append(match.group(1))
        
        print(f"Features parsed from file: {selected_features}")
        
        valid_features = [f for f in selected_features if f in all_features]
        invalid_features = [f for f in selected_features if f not in all_features]
        
        if invalid_features:
            print(f"Warning: Features not found, filtered: {invalid_features}")
        
        if not valid_features:
            raise ValueError("No valid features available after filtering")
            
        selected_features = valid_features
        print(f"Selected {len(selected_features)} valid features")
    else:
        print("Feature file not found, using all features from training set")
        selected_features = all_features
    
    mask = [feature in selected_features for feature in all_features]
    print(f"Selected features count: {sum(mask)}")
    
    X_train_sel = X_train[:, mask]
    X_test_sel = X_test[:, mask]
    
    # Save training set and test set data with selected features
    selected_train_df = pd.DataFrame(X_train_sel, columns=selected_features)
    selected_train_df[TARGET_COLUMN] = y_train
    selected_train_save_path = os.path.join(output_dir, "training_set_selected_features.csv")
    selected_train_df.to_csv(selected_train_save_path, index=False, encoding="utf-8-sig")
    print(f"Selected training set data saved: {selected_train_save_path}")
    
    selected_test_df = pd.DataFrame(X_test_sel, columns=selected_features)
    selected_test_df[TARGET_COLUMN] = y_test
    selected_test_save_path = os.path.join(output_dir, "test_set_selected_features.csv")
    selected_test_df.to_csv(selected_test_save_path, index=False, encoding="utf-8-sig")
    print(f"Selected test set data saved: {selected_test_save_path}")
    
    return model, X_train_sel, X_test_sel, y_train, y_test, selected_features

# ============= SHAP analysis function - Using KernelExplainer =============
def create_combined_plot(shap_values, X_train, feature_names, expected_value, output_dir):
    """
    Create combined plot: feature importance bar chart embedded directly on left side of beeswarm plot
    Fully use shap.summary_plot, no custom plotting
    """
    print("\n4. Creating combined plot - USING SHAP.SUMMARY_PLOT with MAXIMUM FONTS...")
    
    try:
        # Calculate feature importance (mean absolute SHAP value)
        importance = np.abs(shap_values).mean(axis=0)
        
        # Sort by importance (descending)
        sorted_idx = np.argsort(importance)[::-1]
        sorted_features = [feature_names[i] for i in sorted_idx]
        sorted_importance = importance[sorted_idx]
        sorted_shap = shap_values[:, sorted_idx]
        sorted_X = X_train[:, sorted_idx]
        
        n_features = len(sorted_features)
        
        # Create DataFrame
        X_train_df = pd.DataFrame(sorted_X, columns=sorted_features)
        
        # Save original settings
        original_font_size = plt.rcParams['font.size']
        original_axes_labelsize = plt.rcParams['axes.labelsize']
        original_axes_titlesize = plt.rcParams['axes.titlesize']
        original_xtick_labelsize = plt.rcParams['xtick.labelsize']
        original_ytick_labelsize = plt.rcParams['ytick.labelsize']
        
        # Set maximum fonts
        plt.rcParams['font.size'] = 54
        plt.rcParams['axes.labelsize'] = 64
        plt.rcParams['axes.titlesize'] = 72
        plt.rcParams['xtick.labelsize'] = 54
        plt.rcParams['ytick.labelsize'] = 54
        
        # Create figure
        fig = plt.figure(figsize=(40, 24))
        
        # Force larger scatter points
        import matplotlib.pyplot as plt_orig
        original_scatter = plt_orig.scatter
        
        def scatter_with_forced_large_dots(*args, **kwargs):
            kwargs['s'] = 200
            return original_scatter(*args, **kwargs)
        
        plt_orig.scatter = scatter_with_forced_large_dots
        
        # Draw beeswarm plot
        shap.summary_plot(sorted_shap, X_train_df, 
                         feature_names=sorted_features,
                         show=False, 
                         max_display=n_features,
                         plot_size=None,
                         color_bar=True)
        
        plt_orig.scatter = original_scatter
        
        # Get current axes
        ax = plt.gca()
        
        # Force modify scatter point sizes
        for collection in ax.collections:
            if hasattr(collection, 'set_sizes'):
                try:
                    collection.set_sizes([200])
                except:
                    pass
        
        # Force find and modify colorbar font
        cbar_ax = None
        for fig_ax in fig.get_axes():
            if hasattr(fig_ax, 'get_ylabel') and fig_ax.get_ylabel() == 'Feature value':
                cbar_ax = fig_ax
                break
        
        if cbar_ax is None:
            for fig_ax in fig.get_axes():
                if fig_ax != ax and fig_ax.get_position().width < 0.1:
                    cbar_ax = fig_ax
                    break
        
        if cbar_ax is not None:
            try:
                cbar_ax.set_ylabel('Feature value', fontsize=48, fontweight='bold', 
                                 fontname='Times New Roman', labelpad=40)
                cbar_ax.tick_params(labelsize=42)
                for label in cbar_ax.get_yticklabels():
                    label.set_fontname('Times New Roman')
                    label.set_fontsize(42)
                print("   ✅ Colorbar fonts set to 48pt/42pt")
            except Exception as e:
                print(f"   ⚠️ Colorbar font adjustment failed: {e}")
        
        # Set title
        ax.set_title(r'SHAP value of T$_{5\%}$(℃)', 
                    fontsize=72, fontweight='bold', fontname='Times New Roman', pad=50)
        
        # Set x-axis label
        ax.set_xlabel('SHAP value (impact on model output)', 
                     fontsize=64, fontweight='bold', fontname='Times New Roman', labelpad=45)
        
        # Set y-axis label
        ax.set_ylabel('Features', 
                     fontsize=64, fontweight='bold', fontname='Times New Roman', labelpad=45)
        
        # Set tick fonts
        ax.tick_params(axis='both', which='major', labelsize=54, pad=20)
        for label in ax.get_xticklabels():
            label.set_fontname('Times New Roman')
            label.set_fontsize(54)
        for label in ax.get_yticklabels():
            label.set_fontname('Times New Roman')
            label.set_fontsize(54)
        
        # Set denser X-axis ticks
        x_min, x_max = ax.get_xlim()
        ax.xaxis.set_major_locator(ticker.MultipleLocator(50))
        ax.xaxis.set_minor_locator(ticker.MultipleLocator(10))
        ax.set_xlim(x_min, x_max)
        ax.grid(True, alpha=0.1, axis='x', which='minor', linestyle=':', linewidth=1.2, color='#CCCCCC')
        
        # Get axis limits for adding bar charts and value labels
        x_min, x_max = ax.get_xlim()
        x_range = x_max - x_min
        bar_x_start = x_min
        y_positions = ax.get_yticks()
        y_labels = [label.get_text() for label in ax.get_yticklabels()]
        max_importance = max(sorted_importance)
        
        # Gap between feature name and importance value
        gap_between = 0.002
        
        # Draw bar chart and add value label for each feature
        for i, (feat_name, y_pos) in enumerate(zip(y_labels, y_positions)):
            if feat_name in sorted_features:
                feat_idx = sorted_features.index(feat_name)
                importance_value = sorted_importance[feat_idx]
                importance_ratio = importance_value / max_importance
                bar_width = importance_ratio * x_range * 0.25
                
                # Draw bar chart - light red, transparency 0.35
                ax.barh(y_pos, bar_width, left=bar_x_start, 
                       color='#FFB6C1', alpha=0.35, height=0.7,
                       edgecolor='none', linewidth=0)
                
                # Add feature importance value label
                label_x = bar_x_start - x_range * gap_between
                label_text = f'{importance_value:.1f}'
                
                ax.text(label_x, y_pos, label_text,
                       va='center', ha='right', fontsize=48, fontweight='bold',
                       fontname='Times New Roman', color='#8B4513', alpha=0.9)
        
        # Adjust X-axis range
        ax.set_xlim(x_min - x_range * 0.05, x_max)
        
        # Set main grid
        ax.grid(True, alpha=0.15, axis='x', which='major', linestyle='--', linewidth=1.5, color='#999999')
        
        # Set spines
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.spines['left'].set_linewidth(2.5)
        ax.spines['bottom'].set_linewidth(2.5)
        
        # Adjust layout
        plt.tight_layout()
        
        # Save image
        save_path = os.path.join(output_dir, 'shap_combined_plot_MLP.png')
        plt.savefig(save_path, dpi=300, bbox_inches='tight', format='png', pad_inches=0.8)
        plt.close()
        
        # Force garbage collection
        gc.collect()
        
        # Restore original matplotlib global parameters
        plt.rcParams['font.size'] = original_font_size
        plt.rcParams['axes.labelsize'] = original_axes_labelsize
        plt.rcParams['axes.titlesize'] = original_axes_titlesize
        plt.rcParams['xtick.labelsize'] = original_xtick_labelsize
        plt.rcParams['ytick.labelsize'] = original_ytick_labelsize
        
        print(f"   ✅ Combined plot saved to: {save_path}")
        
        return fig
        
    except Exception as e:
        print(f"   ❌ Failed to create combined plot: {e}")
        import traceback
        traceback.print_exc()
        
        try:
            plt.rcParams['font.size'] = original_font_size
            plt.rcParams['axes.labelsize'] = original_axes_labelsize
            plt.rcParams['axes.titlesize'] = original_axes_titlesize
            plt.rcParams['xtick.labelsize'] = original_xtick_labelsize
            plt.rcParams['ytick.labelsize'] = original_ytick_labelsize
        except:
            pass
        
        return None

# ============= SHAP analysis main function =============
def run_shap_analysis(model, X_train, feature_names, output_dir):
    """Perform SHAP analysis using SHAP library - MLP uses KernelExplainer"""
    
    print("\n" + "="*60)
    print("SHAP ANALYSIS - MLP Model")
    print("="*60)
    
    if shap is None:
        print("❌ SHAP is not available")
        return None, None, None
    
    # 1. Create SHAP Explainer (MLP uses KernelExplainer)
    print("\n1. Creating SHAP Explainer...")
    print("   MLP is a neural network, using KernelExplainer...")
    
    try:
        # Use fewer background samples to speed up computation
        background = X_train[:50]
        explainer = shap.KernelExplainer(model.predict, background, link="identity")
        print("   ✅ Using shap.KernelExplainer")
    except Exception as e:
        print(f"   ❌ Failed to create explainer: {e}")
        return None, None, None
    
    # 2. Calculate SHAP values
    print("\n2. Calculating SHAP values (this may take a while for MLP)...")
    try:
        shap_values = explainer.shap_values(X_train)
        print(f"   ✅ SHAP values calculated, shape: {shap_values.shape}")
        
        expected_value = explainer.expected_value
        print(f"   ✅ Expected value: {expected_value:.4f}")
        
    except Exception as e:
        print(f"   ❌ Failed to calculate SHAP values: {e}")
        return None, None, None
    
    # 3. Save SHAP values
    print("\n3. Saving SHAP values...")
    shap_df = pd.DataFrame(shap_values, columns=feature_names)
    shap_csv_path = os.path.join(output_dir, 'shap_values.csv')
    shap_df.to_csv(shap_csv_path, index=False, encoding="utf-8-sig")
    print(f"   ✅ SHAP values saved to: {shap_csv_path}")
    
    # 4. Create combined plot
    fig = create_combined_plot(shap_values, X_train, feature_names, expected_value, output_dir)
    
    return shap_values, expected_value, explainer

# ============= Main function =============
def main():
    """Main function"""
    print("="*90)
    print("MLP MODEL SHAP ANALYSIS - FROM GA EXPERIMENT")
    print("Fonts: Title 72pt, Axis 64pt, Ticks 54pt, Values 48pt")
    print("Colorbar: Label 48pt, Ticks 42pt")
    print("Gap between feature names and values: 0.002")
    print("Canvas size: 40x24, Save DPI: 300")
    print("Light red bars, Brown importance values (#8B4513)")
    print("Title with subscript and temperature unit: T$_{5%}$(℃)")
    print("="*90)
    
    try:
        print("\nConfiguration:")
        print(f"  GA Experiment directory: {GA_EXPERIMENT_DIR}")
        print(f"  Model path: {MODEL_PATH}")
        print(f"  Feature file: {FEATURE_FILE}")
        print(f"  Data path: {DATA_PATH}")
        print(f"  Target column: {TARGET_COLUMN}")
        print(f"  Output directory: {OUTPUT_DIR}")
        print("="*90)
        
        # 1. Load model and data
        model, X_train_sel, X_test_sel, y_train, y_test, feature_names = load_model_and_data(OUTPUT_DIR)
        print(f"\n📊 Using {len(feature_names)} features for SHAP analysis")
        print(f"   Features: {feature_names}")
        
        # 2. Run SHAP analysis
        result = run_shap_analysis(model, X_train_sel, feature_names, OUTPUT_DIR)
        
        if result[0] is not None:
            shap_values, expected_value, explainer = result
            
            # 3. Calculate and save feature importance ranking
            importance = np.abs(shap_values).mean(axis=0)
            sorted_idx = np.argsort(importance)[::-1]
            
            importance_df = pd.DataFrame({
                'Feature': [feature_names[i] for i in sorted_idx],
                'Mean_Abs_SHAP': importance[sorted_idx],
                'Rank': range(1, len(feature_names)+1)
            })
            
            print("\n5. Feature Importance Ranking:")
            print("-" * 90)
            print(f"{'Rank':<6}{'Feature':<50}{'Mean |SHAP|':<15}")
            print("-" * 80)
            for i, row in importance_df.head(15).iterrows():
                print(f"   {row['Rank']:<4}{row['Feature']:<50}{row['Mean_Abs_SHAP']:.4f}")
            
            # Save feature importance ranking
            importance_csv_path = os.path.join(OUTPUT_DIR, 'feature_importance_ranking.csv')
            importance_df.to_csv(importance_csv_path, index=False, encoding="utf-8-sig")
            print(f"\n   ✅ Feature importance ranking saved to: {importance_csv_path}")
            
            # 4. Save model information
            info_txt_path = os.path.join(OUTPUT_DIR, 'model_info.txt')
            with open(info_txt_path, 'w', encoding='utf-8') as f:
                f.write(f"SHAP Analysis Results - MLP Model (from GA Experiment)\n")
                f.write(f"="*80 + "\n")
                f.write(f"Analysis Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"GA Experiment Directory: {GA_EXPERIMENT_DIR}\n")
                f.write(f"Model Path: {MODEL_PATH}\n")
                f.write(f"Data Path: {DATA_PATH}\n")
                f.write(f"Feature File: {FEATURE_FILE}\n")
                f.write(f"Target Column: {TARGET_COLUMN}\n\n")
                f.write(f"Model Type: {type(model).__name__}\n")
                f.write(f"SHAP Explainer: KernelExplainer\n")
                f.write(f"Training samples: {X_train_sel.shape[0]}\n")
                f.write(f"Test samples: {X_test_sel.shape[0]}\n")
                f.write(f"Features: {len(feature_names)}\n")
                f.write(f"Expected value: {expected_value:.4f}\n\n")
                f.write(f"Selected Features:\n")
                for i, feat in enumerate(feature_names, 1):
                    f.write(f"  {i}. {feat}\n")
                f.write(f"\nPlot Settings:\n")
                f.write(f"  - Font: Times New Roman\n")
                f.write(f"  - Canvas size: 40x24\n")
                f.write(f"  - Save DPI: 300\n")
                f.write(f"  - Title: 72pt bold\n")
                f.write(f"  - Axis labels: 64pt bold\n")
                f.write(f"  - Tick labels: 54pt\n")
                f.write(f"  - Importance values: 48pt bold\n")
                f.write(f"  - Dot size: 200\n")
                f.write(f"  - Colorbar label: 48pt bold\n")
                f.write(f"  - Colorbar tick labels: 42pt\n")
            
            print(f"\n   ✅ Model info saved to: {info_txt_path}")
            
            # 5. Output file summary
            print("\n" + "="*90)
            print("✅ SHAP ANALYSIS COMPLETED SUCCESSFULLY")
            print("="*90)
            print(f"\n📁 All files saved to: {OUTPUT_DIR}")
            print("\n📊 Generated files:")
            print(f"   1. training_set_data.csv")
            print(f"   2. test_set_data.csv")
            print(f"   3. training_set_selected_features.csv")
            print(f"   4. test_set_selected_features.csv")
            print(f"   5. shap_values.csv")
            print(f"   6. feature_importance_ranking.csv")
            print(f"   7. model_info.txt")
            print(f"   8. shap_combined_plot_MLP.png")
            
        else:
            print("\n❌ SHAP analysis failed")
        
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()