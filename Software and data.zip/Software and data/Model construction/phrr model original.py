# -*- coding: utf-8 -*-
"""
5-Fold Cross-Validation Model Evaluation Program (Pure Numerical Features Version) - No Standardization Version
Use all features, no feature selection
Cross-validation only performed on training set
"""

import numpy as np
import pandas as pd
import joblib  
import os       
from datetime import datetime  
from sklearn.model_selection import train_test_split, GridSearchCV, KFold
from sklearn.metrics import r2_score, mean_squared_error  
from scipy.stats import pearsonr  
from sklearn.linear_model import Ridge, ElasticNet
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, AdaBoostRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.neural_network import MLPRegressor
from xgboost import XGBRegressor
from catboost import CatBoostRegressor
import warnings
import time  
from sklearn.base import clone

warnings.filterwarnings('ignore')

# ==================== Please set your file paths here ====================
# Training data path
TRAIN_DATA_PATH = r"phrr.xlsx"
# ================================================================

# -------------------------- Initialize experiment directory --------------------------
def init_experiment_dir():
    experiment_time = datetime.now().strftime("%Y%m%d_%H%M%S")
    experiment_dir = f"PHRR_experiment_{experiment_time}"
    os.makedirs(experiment_dir, exist_ok=True)
    os.makedirs(os.path.join(experiment_dir, "models"), exist_ok=True)  
    os.makedirs(os.path.join(experiment_dir, "data_splits"), exist_ok=True)  
    os.makedirs(os.path.join(experiment_dir, "logs"), exist_ok=True)  
    os.makedirs(os.path.join(experiment_dir, "predictions"), exist_ok=True)
    return experiment_dir

# -------------------------- 1. Data loading --------------------------
def load_data(random_seed):
    print("\n" + "="*60)
    print("Loading training data...")
    print("="*60)
    print(f"Data path: {TRAIN_DATA_PATH}")
    
    # Check if file exists
    if not os.path.exists(TRAIN_DATA_PATH):
        raise FileNotFoundError(f"Training data file not found: {TRAIN_DATA_PATH}")
    
    dataset = pd.read_excel(TRAIN_DATA_PATH)
    print(f"Original data shape: {dataset.shape}")
    print(f"Original data rows: {len(dataset)}")
    print(f"Original column names (first 10): {dataset.columns[:10].tolist()}")
    
    # Intelligently find target column
    possible_target_names = ['PHRR（Kw/m2）', 'PHRR(Kw/m2)', 'PHRR', 'PHRR（Kw/m²）', 'PHRR(Kw/m²)']
    target_col = None
    
    for col_name in possible_target_names:
        if col_name in dataset.columns:
            target_col = col_name
            break
    
    if target_col is None:
        for col in dataset.columns:
            if 'PHRR' in str(col).upper():
                target_col = col
                print(f"Found target column via fuzzy matching: {target_col}")
                break
    
    if target_col is None:
        print(f"Available column names: {dataset.columns.tolist()}")
        raise KeyError("Target column not found, please check column names in Excel file")
    
    print(f"Found target column: {target_col}")
    
    # View basic statistics of target column
    print(f"\nTarget column '{target_col}' basic statistics:")
    print(f"  Min: {dataset[target_col].min()}")
    print(f"  Max: {dataset[target_col].max()}")
    print(f"  Mean: {dataset[target_col].mean():.2f}")
    print(f"  Median: {dataset[target_col].median():.2f}")
    print(f"  Non-null samples: {dataset[target_col].count()}")
    
    # Remove NO sequence column
    if 'NO' in dataset.columns:
        initial_count = len(dataset)
        dataset = dataset.drop(columns=['NO'], errors='ignore')
        print(f"\nDetected NO sequence column, removed (original count: {initial_count}, after removal: {len(dataset)})")
    else:
        print(f"Original data count: {len(dataset)}")
    
    # Target value range filtering (based on your data, PHRR range approximately 100-1000)
    clean_mask = (dataset[target_col] > 10) & (dataset[target_col] <= 1500)
    dataset = dataset[clean_mask].copy().reset_index(drop=True)
    print(f"After target value filtering: {len(dataset)} samples")
    
    # Keep only numerical features
    numeric_cols = dataset.select_dtypes(include=[np.number]).columns.tolist()
    if target_col in numeric_cols:
        numeric_cols.remove(target_col)
    
    print(f"\nNumerical feature count: {len(numeric_cols)}")
    
    # Check non-numerical columns
    non_numeric = dataset.select_dtypes(exclude=[np.number]).columns.tolist()
    if non_numeric:
        print(f"Non-numerical columns (will be removed): {non_numeric}")
    
    dataset = dataset[numeric_cols + [target_col]].copy()
    
    # Remove features with zero variance (constant features)
    constant_features = []
    for col in numeric_cols:
        if dataset[col].std() == 0:
            constant_features.append(col)
    
    if constant_features:
        print(f"\nRemoving constant features: {constant_features}")
        dataset = dataset.drop(columns=constant_features)
        numeric_cols = [col for col in numeric_cols if col not in constant_features]
    
    # Fill missing values
    dataset[numeric_cols] = dataset[numeric_cols].fillna(dataset[numeric_cols].median())
    
    print(f"\nFinal data shape: {dataset.shape}")
    print(f"Valid samples: {len(dataset)}")
    print(f"Valid features: {len(numeric_cols)}")
    print(f"Target column range: {dataset[target_col].min():.2f} - {dataset[target_col].max():.2f}")
    
    return dataset, target_col, numeric_cols

# -------------------------- 2. Feature engineering --------------------------
def feature_engineering(data, target_col, train_features=None):
    """Simplified feature engineering: only keep original numerical features"""
    df = data.copy()
    
    # Remove NO sequence column
    if 'NO' in df.columns:
        df = df.drop(columns=['NO'])
    
    # Get numerical feature columns
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if target_col in numeric_cols:
        numeric_cols.remove(target_col)
    
    # If training feature list is provided, filter according to the list
    if train_features is not None:
        train_features = [f for f in train_features if f != 'NO' and f in numeric_cols + [target_col]]
        for feat in train_features:
            if feat not in df.columns:
                df[feat] = 0
        df = df[train_features + [target_col]] if target_col in df.columns else df[train_features]
    
    return df

# -------------------------- 3. Model optimization --------------------------
def optimize_models(X_train, y_train, X_test, y_test, feature_names, random_seed=None, experiment_dir=None):
    """Model optimization, cross-validation only on training set"""
    feature_names = [f for f in feature_names if f != 'NO']
    
    print(f"\nTraining/Test set split complete | Training set: {X_train.shape[0]} samples, {X_train.shape[1]} features | Test set: {X_test.shape[0]} samples")
    
    if experiment_dir is not None:
        test_data = pd.DataFrame(X_test, columns=feature_names)
        test_data['PHRR_true'] = y_test.values
        test_data.to_csv(os.path.join(experiment_dir, "data_splits", "test_set_data.csv"), index=False, encoding="utf-8-sig")
        print(f"Test set data saved to: {os.path.join(experiment_dir, 'data_splits', 'test_set_data.csv')}")
    
    param_grids = {
        "Ridge Regression": {"alpha": [0.1, 0.5, 1, 5, 10], "solver": ["auto", "cholesky"], "max_iter": [2000]},
        "Elastic Net Regression": {"alpha": [0.1, 0.5, 1, 2], "l1_ratio": [0.1, 0.3, 0.5, 0.7], "max_iter": [3000], "tol": [1e-4]},
        "Gradient Boosting Regressor": {"n_estimators": [100, 150], "learning_rate": [0.03, 0.05], "max_depth": [3, 4], "subsample": [0.7, 0.8], "min_samples_split": [5, 10], "min_samples_leaf": [3, 5], "random_state": [random_seed]},
        "Random Forest Regressor": {"n_estimators": [100, 150], "max_depth": [4, 5], "min_samples_split": [5, 10], "min_samples_leaf": [3, 5], "max_features": ['sqrt', 0.7], "random_state": [random_seed]},
        "XGBoost": {"n_estimators": [100, 150], "max_depth": [3, 4], "learning_rate": [0.03, 0.05], "subsample": [0.7, 0.8], "colsample_bytree": [0.7, 0.8], "reg_alpha": [0.5, 1], "reg_lambda": [1, 1.5], "random_state": [random_seed]},
        "K-Nearest Neighbors": {"n_neighbors": [3, 4, 5, 6], "weights": ["distance"], "metric": ["manhattan", "euclidean"], "leaf_size": [20, 30]},
        "Adaboost Regressor": {"n_estimators": [50, 100], "learning_rate": [0.05, 0.1], "loss": ["linear", "square"], "random_state": [random_seed]},
        "Catboost Regressor": {"iterations": [100, 150], "depth": [3, 4], "learning_rate": [0.03, 0.05], "subsample": [0.7, 0.8], "l2_leaf_reg": [3, 5], "verbose": [0], "random_state": [random_seed]},
        "Multilayer Perceptron Regressor": {"hidden_layer_sizes": [(50,), (50, 25), (100,)], "activation": ["relu"], "alpha": [0.001, 0.01], "max_iter": [2000], "learning_rate_init": [0.001, 0.0005], "early_stopping": [True], "random_state": [random_seed]}
    }
    
    models = {
        "Ridge Regression": Ridge(),
        "Elastic Net Regression": ElasticNet(),
        "Gradient Boosting Regressor": GradientBoostingRegressor(),
        "Random Forest Regressor": RandomForestRegressor(),
        "XGBoost": XGBRegressor(),
        "K-Nearest Neighbors": KNeighborsRegressor(),
        "Adaboost Regressor": AdaBoostRegressor(),
        "Catboost Regressor": CatBoostRegressor(verbose=0),
        "Multilayer Perceptron Regressor": MLPRegressor(),
    }
    
    optimized_models = {}
    qualified_models = {}
    algo_metrics_list = []
    model_logs = []
    test_predictions = pd.DataFrame()
    test_predictions['true'] = y_test.values
    
    print("\n=== Model optimization (cross-validation on training set) ===")
    print(f"{'Model Name':<25} | {'Train R2':<8} | {'Test R2':<8} | {'CV RMSE':<10} | {'Test Accuracy Rate':<12} | {'Status':<8}")
    print("-" * 85)
    
    for model_name, base_model in models.items():
        try:
            if model_name not in param_grids:
                print(f"{model_name:<25} | No parameter grid configuration, skipping optimization")
                continue
            
            # GridSearchCV uses cross-validation on training set
            grid_search = GridSearchCV(
                estimator=base_model,
                param_grid=param_grids[model_name],
                cv=5,  # 5-fold cross-validation only on training set
                scoring="neg_mean_squared_error",
                n_jobs=-1,
                verbose=0,
                refit=True
            )
            
            start_time = time.time()
            grid_search.fit(X_train, y_train)
            train_time = round(time.time() - start_time, 2)
            
            best_model = grid_search.best_estimator_
            best_params = grid_search.best_params_
            best_cv_rmse = np.sqrt(-grid_search.best_score_)
            
            y_test_pred = best_model.predict(X_test)
            # Ensure predictions are non-negative
            y_test_pred = np.maximum(y_test_pred, 5)
            
            test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
            test_r2 = r2_score(y_test, y_test_pred)
            test_r, test_r_pvalue = pearsonr(y_test.values, y_test_pred)
            test_relative_error = np.abs(y_test_pred - y_test.values) / (y_test.values + 1e-6)
            test_avg_accuracy = 1 - np.mean(test_relative_error)
            test_accuracy_rate = (test_relative_error <= 0.15).sum() / len(y_test)
            
            y_train_pred = best_model.predict(X_train)
            y_train_pred = np.maximum(y_train_pred, 5)
            train_rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))
            train_r2 = r2_score(y_train, y_train_pred)
            train_r, train_r_pvalue = pearsonr(y_train.values, y_train_pred)
            
            def check_overfitting(train_r2, test_r2, train_rmse, test_rmse, threshold=0.15):
                r2_diff = abs(train_r2 - test_r2)
                rmse_ratio = test_rmse / train_rmse if train_rmse > 0 else 1
                if r2_diff > threshold or rmse_ratio > 1.5:
                    return True
                return False
            
            is_overfitted = check_overfitting(train_r2, test_r2, train_rmse, test_rmse)
            
            if is_overfitted:
                print(f"{model_name:<25} | Detected possible overfitting, trying simplified model...")
                
                if model_name == "Random Forest Regressor":
                    simple_model = RandomForestRegressor(
                        n_estimators=50, max_depth=3, min_samples_split=10, 
                        min_samples_leaf=5, random_state=random_seed
                    )
                elif model_name == "XGBoost":
                    simple_model = XGBRegressor(
                        n_estimators=50, max_depth=3, learning_rate=0.03, 
                        subsample=0.7, colsample_bytree=0.7, 
                        reg_alpha=1, reg_lambda=1.5, random_state=random_seed
                    )
                elif model_name == "Gradient Boosting Regressor":
                    simple_model = GradientBoostingRegressor(
                        n_estimators=50, max_depth=3, learning_rate=0.03, 
                        subsample=0.7, min_samples_split=10, 
                        min_samples_leaf=5, random_state=random_seed
                    )
                elif model_name == "Multilayer Perceptron Regressor":
                    simple_model = MLPRegressor(
                        hidden_layer_sizes=(30,), alpha=0.01, max_iter=2000, 
                        learning_rate_init=0.001, early_stopping=True, random_state=random_seed
                    )
                else:
                    simple_model = clone(base_model)
                    simple_model.set_params(**{k: v[0] for k, v in param_grids[model_name].items() if not isinstance(v, list)})
                
                simple_model.fit(X_train, y_train)
                
                y_test_pred_simple = simple_model.predict(X_test)
                y_test_pred_simple = np.maximum(y_test_pred_simple, 5)
                test_rmse_simple = np.sqrt(mean_squared_error(y_test, y_test_pred_simple))
                test_r2_simple = r2_score(y_test, y_test_pred_simple)
                test_r_simple, test_r_pvalue_simple = pearsonr(y_test.values, y_test_pred_simple)
                test_relative_error_simple = np.abs(y_test_pred_simple - y_test.values) / (y_test.values + 1e-6)
                test_avg_accuracy_simple = 1 - np.mean(test_relative_error_simple)
                test_accuracy_rate_simple = (test_relative_error_simple <= 0.15).sum() / len(y_test)
                
                y_train_pred_simple = simple_model.predict(X_train)
                y_train_pred_simple = np.maximum(y_train_pred_simple, 5)
                train_rmse_simple = np.sqrt(mean_squared_error(y_train, y_train_pred_simple))
                train_r2_simple = r2_score(y_train, y_train_pred_simple)
                is_overfitted_simple = check_overfitting(train_r2_simple, test_r2_simple, train_rmse_simple, test_rmse_simple)
                
                if not is_overfitted_simple or (test_r2_simple > test_r2 and test_accuracy_rate_simple > test_accuracy_rate):
                    print(f"{model_name:<25} | Using simplified model to address overfitting")
                    best_model = simple_model
                    best_params = simple_model.get_params()
                    test_rmse = test_rmse_simple
                    test_r2 = test_r2_simple
                    test_r = test_r_simple
                    test_r_pvalue = test_r_pvalue_simple
                    test_relative_error = test_relative_error_simple
                    test_avg_accuracy = test_avg_accuracy_simple
                    test_accuracy_rate = test_accuracy_rate_simple
                    train_rmse = train_rmse_simple
                    train_r2 = train_r2_simple
                    train_r, train_r_pvalue = pearsonr(y_train.values, y_train_pred_simple)
                    is_overfitted = is_overfitted_simple
            
            optimized_models[model_name] = {
                "model": best_model,
                "best_params": best_params,
                "cv_rmse": best_cv_rmse,
                "train_metrics": {
                    "r": train_r,
                    "r2": train_r2,
                    "rmse": train_rmse,
                    "r_pvalue": train_r_pvalue
                },
                "test_metrics": {
                    "r": test_r,
                    "r2": test_r2,
                    "rmse": test_rmse,
                    "r_pvalue": test_r_pvalue,
                    "avg_accuracy": test_avg_accuracy,
                    "accuracy_rate": test_accuracy_rate,
                    "y_pred": y_test_pred,
                    "y_true": y_test.values,
                    "relative_error": test_relative_error
                },
                "train_time": train_time,
                "is_overfitted": is_overfitted
            }
            
            algo_metrics_list.append({
                "Model Name": model_name,
                "Train R2": round(train_r2, 4),
                "Test R2": round(test_r2, 4),
                "Test RMSE": round(test_rmse, 4),
                "CV_RMSE": round(best_cv_rmse, 4),
                "Test Accuracy Rate": round(test_accuracy_rate, 4),
                "Overfitted": "Yes" if is_overfitted else "No",
                "Train Time s": train_time
            })
            
            model_logs.append({
                "Optimization Time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "Model Name": model_name,
                "Best Params": str(best_params),
                "Train R2": round(train_r2, 4),
                "Test R2": round(test_r2, 4),
                "Test RMSE": round(test_rmse, 4),
                "CV_RMSE": round(best_cv_rmse, 4),
                "Test Accuracy Rate": round(test_accuracy_rate, 4),
                "Overfitted": "Yes" if is_overfitted else "No",
                "Train Time s": train_time,
                "Status": "Success"
            })
            
            test_predictions[model_name] = y_test_pred
            
            if test_accuracy_rate >= 0.85 and test_r2 >= 0.7 and not is_overfitted:
                qualified_models[model_name] = optimized_models[model_name]
                status_tag = "Qualified"
            else:
                status_tag = "Not Qualified"
            
            print(f"{model_name:<25} | Train R2: {train_r2:.4f} | Test R2: {test_r2:.4f} | CV RMSE: {best_cv_rmse:.4f} | Test Accuracy Rate: {test_accuracy_rate:.1%} | {status_tag}")
            
            if experiment_dir is not None:
                model_filename = f"{model_name.replace(' ', '_').lower()}.pkl"
                model_save_path = os.path.join(experiment_dir, "models", model_filename)
                joblib.dump(best_model, model_save_path)
        
        except Exception as e:
            error_msg = str(e)[:50] + "..." if len(str(e)) > 50 else str(e)
            print(f"{model_name:<25} | Optimization error: {error_msg}")
            model_logs.append({
                "Optimization Time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "Model Name": model_name,
                "Status": f"Failed: {error_msg}"
            })
            optimized_models[model_name] = {
                "error": error_msg,
                "status": "failed"
            }
    
    if experiment_dir is not None and not test_predictions.empty:
        test_pred_path = os.path.join(experiment_dir, "predictions", "test_set_predictions.csv")
        test_predictions.to_csv(test_pred_path, index=False, encoding="utf-8-sig")
        print(f"\nTest set predictions saved to: {test_pred_path}")
    
    print(f"\n=== Model Optimization Summary ===")
    print(f"Total models: {len(models)} | Successfully optimized: {len([m for m in optimized_models.values() if 'error' not in m])} | Qualified models: {len(qualified_models)}")
    
    if experiment_dir is not None:
        algo_metrics_df = pd.DataFrame(algo_metrics_list)
        metrics_save_path = os.path.join(experiment_dir, "logs", "algorithm_core_metrics.csv")
        algo_metrics_df.to_csv(metrics_save_path, index=False, encoding="utf-8-sig")
        print(f"\nAlgorithm core metrics summary saved to: {metrics_save_path}")
        
        log_df = pd.DataFrame(model_logs)
        log_save_path = os.path.join(experiment_dir, "logs", "model_optimization_log.csv")
        log_df.to_csv(log_save_path, index=False, encoding="utf-8-sig")
        print(f"Model optimization log saved to: {log_save_path}")
    
    return optimized_models, qualified_models, algo_metrics_list

# -------------------------- 4. 5-fold cross-validation evaluation --------------------------
def cross_validation_evaluation(X_train, y_train, feature_names, n_splits=5, experiment_dir=None, random_seed=None):
    """5-fold cross-validation evaluation only performed on training set"""
    if X_train.shape[0] < n_splits:
        raise ValueError(f"Training set sample count is less than number of cross-validation folds")
    if X_train.shape[1] == 0:
        raise ValueError("No valid numerical features for cross-validation evaluation")
    
    print(f"\n=== 5-fold Cross-Validation Evaluation (only on training set) ===")
    print(f"Training set samples: {X_train.shape[0]} | Features: {X_train.shape[1]}")
    
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=random_seed)
    
    models = {
        "Ridge Regression": Ridge(alpha=10, max_iter=2000, random_state=random_seed),
        "Elastic Net Regression": ElasticNet(alpha=1, l1_ratio=0.5, max_iter=3000, random_state=random_seed),
        "Gradient Boosting Regressor": GradientBoostingRegressor(n_estimators=100, learning_rate=0.05, max_depth=3, subsample=0.8, min_samples_split=5, min_samples_leaf=3, random_state=random_seed),
        "Random Forest Regressor": RandomForestRegressor(n_estimators=100, max_depth=4, min_samples_split=5, min_samples_leaf=3, max_features='sqrt', random_state=random_seed),
        "XGBoost": XGBRegressor(n_estimators=100, max_depth=3, learning_rate=0.05, subsample=0.8, colsample_bytree=0.8, reg_alpha=0.5, reg_lambda=1, random_state=random_seed),
        "K-Nearest Neighbors": KNeighborsRegressor(n_neighbors=5, weights="distance", metric="manhattan"),
        "Adaboost Regressor": AdaBoostRegressor(n_estimators=100, learning_rate=0.1, loss="square", random_state=random_seed),
        "Catboost Regressor": CatBoostRegressor(iterations=100, depth=3, learning_rate=0.05, subsample=0.8, l2_leaf_reg=3, verbose=0, random_state=random_seed),
        "Multilayer Perceptron Regressor": MLPRegressor(hidden_layer_sizes=(50,), alpha=0.01, max_iter=2000, learning_rate_init=0.001, early_stopping=True, random_state=random_seed)
    }
    
    cv_results = {}
    cv_detail_logs = []
    cv_predictions = pd.DataFrame()
    cv_predictions['true'] = y_train.values
    
    print(f"\n{'Model Name':<25} | {'CV R2':<12} | {'CV RMSE':<12} | {'CV Accuracy Rate':<15}")
    print("-" * 70)
    
    for model_name, model in models.items():
        try:
            fold_r2 = []
            fold_rmse = []
            fold_accuracy_rate = []
            fold_logs = []
            y_cv_pred = np.zeros_like(y_train.values, dtype=float)
            
            for fold_idx, (train_idx, val_idx) in enumerate(kf.split(X_train), 1):
                X_train_fold, X_val_fold = X_train[train_idx], X_train[val_idx]
                y_train_fold, y_val_fold = y_train.iloc[train_idx], y_train.iloc[val_idx]
                
                if len(X_train_fold) < 5:
                    continue
                
                model.fit(X_train_fold, y_train_fold)
                y_val_pred = model.predict(X_val_fold)
                y_val_pred = np.maximum(y_val_pred, 5)
                y_cv_pred[val_idx] = y_val_pred
                
                r2 = r2_score(y_val_fold, y_val_pred)
                rmse = np.sqrt(mean_squared_error(y_val_fold, y_val_pred))
                relative_error = np.abs(y_val_pred - y_val_fold.values) / (y_val_fold.values + 1e-6)
                accuracy_rate = (relative_error <= 0.15).sum() / len(y_val_fold)
                
                fold_r2.append(r2)
                fold_rmse.append(rmse)
                fold_accuracy_rate.append(accuracy_rate)
                
                fold_logs.append({
                    "Model Name": model_name,
                    "Fold": fold_idx,
                    "R2": r2,
                    "RMSE": rmse,
                    "Accuracy Rate": accuracy_rate,
                })
            
            cv_predictions[model_name] = y_cv_pred
            
            if len(fold_r2) == 0:
                cv_results[model_name] = {"status": "failed", "error": "No valid fold results"}
                continue
            
            r2_mean = np.mean(fold_r2)
            r2_std = np.std(fold_r2)
            rmse_mean = np.mean(fold_rmse)
            rmse_std = np.std(fold_rmse)
            accuracy_mean = np.mean(fold_accuracy_rate)
            accuracy_std = np.std(fold_accuracy_rate)
            
            cv_results[model_name] = {
                "r2_mean": r2_mean,
                "r2_std": r2_std,
                "rmse_mean": rmse_mean,
                "rmse_std": rmse_std,
                "accuracy_rate_mean": accuracy_mean,
                "accuracy_rate_std": accuracy_std,
                "valid_folds": len(fold_r2),
                "status": "success"
            }
            
            cv_detail_logs.extend(fold_logs)
            
            print(f"{model_name:<25} | {r2_mean:.4f}±{r2_std:.4f} | {rmse_mean:.4f}±{rmse_std:.4f} | {accuracy_mean:.1%}±{accuracy_std:.1%}")
        
        except Exception as e:
            error_msg = str(e)[:50]
            print(f"{model_name:<25} | Cross-validation error: {error_msg}")
            cv_results[model_name] = {"status": "failed", "error": error_msg}
    
    if experiment_dir is not None and not cv_predictions.empty:
        cv_pred_path = os.path.join(experiment_dir, "predictions", "cv_predictions_train_only.csv")
        cv_predictions.to_csv(cv_pred_path, index=False, encoding="utf-8-sig")
        print(f"\n5-fold cross-validation predictions (training set) saved to: {cv_pred_path}")
    
    if cv_results:
        cv_result_list = []
        for model_name, result in cv_results.items():
            if result["status"] == "success":
                cv_result_list.append({
                    "Model Name": model_name,
                    "Valid Folds": result["valid_folds"],
                    "R2 Mean": round(result["r2_mean"], 4),
                    "R2 Std": round(result["r2_std"], 4),
                    "RMSE Mean": round(result["rmse_mean"], 4),
                    "RMSE Std": round(result["rmse_std"], 4),
                    "Accuracy Rate Mean": round(result["accuracy_rate_mean"], 4),
                    "Accuracy Rate Std": round(result["accuracy_rate_std"], 4),
                    "Status": "Success"
                })
            else:
                cv_result_list.append({
                    "Model Name": model_name,
                    "Status": f"Failed: {result['error']}"
                })
        
        cv_result_df = pd.DataFrame(cv_result_list)
        if experiment_dir is not None:
            cv_result_path = os.path.join(experiment_dir, "PHRR_cross_validation_results.csv")
            cv_result_df.to_csv(cv_result_path, index=False, encoding="utf-8-sig")
            print(f"\n5-fold cross-validation results summary saved to: {cv_result_path}")
    
    return cv_results

# -------------------------- Main function --------------------------
def main(random_seed=68):
    print("="*60)
    print(f"===== PHRR Model Evaluation Program =====")
    print(f"===== Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} =====")
    print("="*60)
    
    experiment_dir = init_experiment_dir()
    print(f"\nExperiment directory created: {experiment_dir}")
    
    # Load training data
    dataset, target_col, numeric_cols = load_data(random_seed)
    
    if len(dataset) < 10:
        print(f"Warning: Small sample size ({len(dataset)}), may affect model stability")
        return None
    
    # Feature engineering
    dataset_eng = feature_engineering(dataset, target_col)
    X = dataset_eng.drop(columns=[target_col]).values
    y = dataset_eng[target_col]
    feature_names = dataset_eng.drop(columns=[target_col]).columns.tolist()
    
    print(f"\nFeature engineering complete | Total numerical features: {X.shape[1]}")
    print(f"Feature count: {len(feature_names)}")
    
    # Split training set and test set (80% training, 20% test)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=random_seed, shuffle=True
    )
    print(f"\nDataset split complete | Training set: {X_train.shape[0]} samples | Test set: {X_test.shape[0]} samples")
    
    # Model optimization (cross-validation on training set)
    optimized_models, qualified_models, algo_metrics_df = optimize_models(
        X_train, y_train, X_test, y_test, feature_names, 
        random_seed=random_seed, experiment_dir=experiment_dir
    )
    
    # 5-fold cross-validation evaluation (only on training set)
    cv_results = cross_validation_evaluation(
        X_train, y_train, feature_names, n_splits=5, 
        experiment_dir=experiment_dir, random_seed=random_seed
    )
    
    # Save feature names
    joblib.dump(feature_names, os.path.join(experiment_dir, "phrr_train_features.pkl"))
    
    # Add model performance summary table
    if optimized_models:
        print("\n" + "="*80)
        print("Model Performance Summary (sorted by CV RMSE)")
        print("="*80)
        
        summary_data = []
        for model_name, model_info in optimized_models.items():
            if "error" not in model_info and "test_metrics" in model_info:
                cv_rmse = model_info.get("cv_rmse", None)
                summary_data.append({
                    "Model Name": model_name,
                    "Test R2": round(model_info["test_metrics"]["r2"], 4),
                    "Test RMSE": round(model_info["test_metrics"]["rmse"], 4),
                    "CV RMSE": round(cv_rmse, 4) if cv_rmse else None,
                    "Test Accuracy Rate": round(model_info["test_metrics"]["accuracy_rate"], 4),
                    "Overfitted": "Yes" if model_info.get("is_overfitted", False) else "No"
                })
        
        if summary_data:
            summary_df = pd.DataFrame(summary_data)
            summary_df = summary_df.sort_values("CV RMSE")
            print(summary_df.to_string(index=False))
            
            summary_path = os.path.join(experiment_dir, "model_performance_summary.csv")
            summary_df.to_csv(summary_path, index=False, encoding="utf-8-sig")
            print(f"\nModel performance summary saved to: {summary_path}")
    
    print("\n" + "="*60)
    print(f"===== Experiment completion time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} =====")
    print(f"===== All results saved to: {experiment_dir} =====")
    print("="*60)
    
    return {
        "experiment_dir": experiment_dir,
        "optimized_models": optimized_models,
        "cv_results": cv_results,
        "best_features": feature_names,
        "best_models": qualified_models
    }

if __name__ == "__main__":
    results = main(random_seed=224)