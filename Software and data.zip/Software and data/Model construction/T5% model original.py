# -*- coding: utf-8 -*-
"""
Created on Thu Apr 30 16:56:54 2026

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Apr 23 17:48:24 2026

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
Direct modeling using all features
Fixed: Explicit data splitting order, cross-validation only performed on training set
"""
import os
import sys
import random

# Set temporary directory to English-only path
if sys.platform.startswith('win'):
    temp_dir = "C:\\Temp_ML_Project"
    if not os.path.exists(temp_dir):
        os.makedirs(temp_dir)
    
    os.environ['TMP'] = temp_dir
    os.environ['TEMP'] = temp_dir
    os.environ['JOBLIB_TEMP_FOLDER'] = temp_dir

# Set environment variables
os.environ['PYTHONIOENCODING'] = 'utf-8'
os.environ['PYTHONUTF8'] = '1'

import numpy as np
import pandas as pd
import joblib, os, argparse, warnings, time
from datetime import datetime
from sklearn.model_selection import train_test_split, cross_val_score, cross_val_predict, GridSearchCV, KFold
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from scipy.stats import pearsonr

# Models
from sklearn.linear_model import Ridge, ElasticNet
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, AdaBoostRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.neural_network import MLPRegressor
from xgboost import XGBRegressor
from catboost import CatBoostRegressor

warnings.filterwarnings('ignore')

# =======================  Data Path Configuration  =======================
DATA_FILE_PATH = "T5%.xlsx"  # Please set your data file path here
# =========================================================================

def init_experiment_dir():
    t = datetime.now().strftime("%Y%m%d_%H%M%S")
    d = f"full_model_experiment_{t}"
    os.makedirs(d, exist_ok=True)
    return d

def load_data():
    """Load training data"""
    df = pd.read_excel(DATA_FILE_PATH)
    target = 'T5%(℃)'
    if 'NO' in df.columns:
        df = df.drop(columns=['NO'])
    X = df.drop(columns=[target])
    y = df[target]
    feature_names = X.columns.tolist()
    print(f"Data shape: {X.shape}")
    print(f"Number of features: {len(feature_names)}")
    print(f"Feature names (first 10): {feature_names[:10]}")
    return X.values, y, feature_names

def optimize_parameters(X_train, y_train, model_name, base_model, param_grid, seed=42):
    """Parameter optimization, cross-validation only on training set"""
    print(f"Optimizing {model_name} parameters...")
    start = time.time()
    grid = GridSearchCV(base_model, param_grid, cv=5, scoring='r2', n_jobs=-1, verbose=0)
    grid.fit(X_train, y_train)
    print(f"{model_name} Best R²: {grid.best_score_:.4f}, Time: {time.time()-start:.2f}s")
    return grid.best_estimator_, grid.best_params_, grid.best_score_

def evaluate_models(X_train, y_train, X_test, y_test, feature_names, exp_dir=None, seed=42):
    """
    Train and evaluate all models
    Cross-validation only performed on training set
    """
    random.seed(seed)
    np.random.seed(seed)
    
    print(f"\nTraining set samples: {X_train.shape[0]}, Features: {X_train.shape[1]}")
    print(f"Test set samples: {X_test.shape[0]}, Features: {X_test.shape[1]}")

    base_models = {
        "Ridge": Ridge(max_iter=10000, tol=1e-4, random_state=seed),
        "ElasticNet": ElasticNet(max_iter=10000, tol=1e-4, random_state=seed),
        "RF": RandomForestRegressor(random_state=seed, n_jobs=-1),
        "GBR": GradientBoostingRegressor(random_state=seed),
        "XGB": XGBRegressor(random_state=seed, verbosity=0, n_jobs=-1),
        "KNN": KNeighborsRegressor(n_jobs=-1),
        "Ada": AdaBoostRegressor(random_state=seed),
        "Cat": CatBoostRegressor(silent=True, random_state=seed, thread_count=-1),
        "MLP": MLPRegressor(max_iter=2000, random_state=seed)
    }

    param_grids = {
        "Ridge": {'alpha': [0.1, 0.5, 1.0, 5.0, 10.0]},
        "ElasticNet": {'alpha': [0.1, 0.5, 1.0], 'l1_ratio': [0.1, 0.5, 0.9]},
        "RF": {'n_estimators': [50, 100, 200], 'max_depth': [None, 10, 20], 'min_samples_split': [2, 5]},
        "GBR": {'n_estimators': [50, 100, 200], 'learning_rate': [0.01, 0.05, 0.1], 'max_depth': [3, 5]},
        "XGB": {'n_estimators': [50, 100, 200], 'learning_rate': [0.01, 0.05, 0.1], 'max_depth': [3, 5]},
        "KNN": {'n_neighbors': [3, 5, 7], 'weights': ['uniform', 'distance'], 'p': [1, 2]},
        "Ada": {'n_estimators': [50, 100, 200], 'learning_rate': [0.01, 0.1, 1.0]},
        "Cat": {'iterations': [100, 200], 'learning_rate': [0.01, 0.05], 'depth': [4, 6]},
        "MLP": {'hidden_layer_sizes': [(50,), (100,)], 'activation': ['relu'], 'alpha': [0.0001, 0.001]}
    }

    cv_res, test_res = [], []
    model_dir = os.path.join(exp_dir, "models")
    os.makedirs(model_dir, exist_ok=True)
    
    predictions_dir = os.path.join(exp_dir, "predictions")
    os.makedirs(predictions_dir, exist_ok=True)

    # Store cross-validation predictions (only on training set)
    cv_predictions = pd.DataFrame({"Actual_train": y_train})
    # Store test set predictions
    test_predictions = pd.DataFrame({"Actual_test": y_test})
    
    trained_models = {}

    print("\n" + "="*80)
    print("Starting model training and evaluation")
    print("="*80)
    print(f"{'Model Name':<12} | {'CV R²':<8} | {'Test R²':<8} | {'Test Acc':<10} | {'Status'}")
    print("-"*60)

    for name, base_model in base_models.items():
        try:
            # Parameter optimization (cross-validation on training set)
            best_model, best_params, best_score = optimize_parameters(
                X_train, y_train, name, base_model, param_grids[name], seed
            )
            
            # Save model
            trained_models[name] = best_model
            joblib.dump(best_model, os.path.join(model_dir, f"{name}.pkl"))
            
            # 5-fold cross-validation (only on training set)
            kf = KFold(n_splits=5, shuffle=True, random_state=seed)
            cv_preds = cross_val_predict(best_model, X_train, y_train, cv=kf)
            cv_r2 = cross_val_score(best_model, X_train, y_train, cv=5, scoring='r2').mean()
            cv_rmse = np.sqrt(mean_squared_error(y_train, cv_preds))
            cv_mae = mean_absolute_error(y_train, cv_preds)
            cv_acc = (np.abs(cv_preds - y_train) / (y_train + 1e-6) <= 0.15).mean()
            cv_corr, _ = pearsonr(y_train, cv_preds)

            # Evaluate on test set (final evaluation)
            best_model.fit(X_train, y_train)
            test_preds = best_model.predict(X_test)
            # Ensure predictions are non-negative
            test_preds = np.maximum(test_preds, 0)
            
            r2_te = r2_score(y_test, test_preds)
            rmse_te = np.sqrt(mean_squared_error(y_test, test_preds))
            mae_te = mean_absolute_error(y_test, test_preds)
            acc_te = (np.abs(test_preds - y_test) / (y_test + 1e-6) <= 0.15).mean()
            test_corr, _ = pearsonr(y_test, test_preds)

            cv_res.append({
                "Model": name, 
                "CV_R2": cv_r2, 
                "CV_RMSE": cv_rmse, 
                "CV_MAE": cv_mae, 
                "CV_Acc": cv_acc, 
                "CV_Corr": cv_corr
            })
            test_res.append({
                "Model": name, 
                "Test_R2": r2_te, 
                "Test_RMSE": rmse_te, 
                "Test_MAE": mae_te, 
                "Test_Acc": acc_te, 
                "Test_Corr": test_corr, 
                "Best_Params": str(best_params)
            })
            
            # Save predictions
            cv_predictions[f"{name}_Pred"] = cv_preds
            test_predictions[f"{name}_Pred"] = test_preds
            
            # Check if qualified
            status = "✅Qualified" if (r2_te >= 0.70 and acc_te >= 0.85) else "❌Not Qualified"
            print(f"{name:<12} | {cv_r2:.4f}   | {r2_te:.4f}   | {acc_te:.1%}     | {status}")
        except Exception as e:
            print(f"{name:<12} | Error: {str(e)[:30]}")
            cv_res.append({"Model": name, "Error": str(e)})
            test_res.append({"Model": name, "Error": str(e)})

    # Save predictions
    cv_predictions.to_csv(os.path.join(predictions_dir, "all_models_cv_predictions.csv"), index=False)
    test_predictions.to_csv(os.path.join(predictions_dir, "all_models_test_predictions.csv"), index=False)
    
    # Save results summary
    pd.DataFrame(cv_res).to_csv(os.path.join(exp_dir, "cross_validation_results.csv"), index=False)
    pd.DataFrame(test_res).to_csv(os.path.join(exp_dir, "test_results.csv"), index=False)
    
    # Save qualified model information
    qualified_models = [t for t in test_res if isinstance(t, dict) and t.get("Test_R2", 0) >= 0.70 and t.get("Test_Acc", 0) >= 0.85]
    if qualified_models:
        pd.DataFrame(qualified_models).to_csv(os.path.join(exp_dir, "qualified_models.csv"), index=False)
        print(f"\n✅ Number of qualified models: {len(qualified_models)}")
    
    return cv_res, test_res, trained_models

def main(random_seed=56):
    print("="*80)
    print("Direct modeling using all features")
    print("Fixed: Explicit data splitting order, cross-validation only on training set")
    print(f"Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Random seed: {random_seed}")
    print("="*80)
    
    # Create experiment directory
    exp_dir = init_experiment_dir()
    print(f"\nExperiment directory: {exp_dir}")
    
    # Load data
    X, y, feature_names = load_data()
    print(f"\nUsing all {len(feature_names)} features for modeling")
    
    # Key fix: Split training and test sets first
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=random_seed, shuffle=True
    )
    print(f"\nDataset split complete:")
    print(f"  Training set: {X_train.shape[0]} samples, {X_train.shape[1]} features")
    print(f"  Test set: {X_test.shape[0]} samples, {X_test.shape[1]} features")
    
    # Train and evaluate models (cross-validation only on training set)
    cv_results, test_results, trained_models = evaluate_models(
        X_train, y_train, X_test, y_test, feature_names, exp_dir, random_seed
    )
    
    # Save best model information
    test_df = pd.DataFrame(test_results)
    if 'Test_R2' in test_df.columns and len(test_df) > 0:
        # Find best model
        best_idx = test_df['Test_R2'].idxmax()
        best_model_info = test_df.loc[best_idx]
        
        print("\n" + "="*80)
        print("Best Model Information")
        print("="*80)
        print(f"Best Model: {best_model_info['Model']}")
        print(f"Test R²: {best_model_info['Test_R2']:.4f}")
        print(f"Test RMSE: {best_model_info['Test_RMSE']:.2f}")
        print(f"Test Accuracy Rate: {best_model_info['Test_Acc']:.1%}")
        
        # Save best model
        if best_model_info['Model'] in trained_models:
            best_model = trained_models[best_model_info['Model']]
            joblib.dump(best_model, os.path.join(exp_dir, "best_model.pkl"))
            print(f"Best model saved to: {os.path.join(exp_dir, 'best_model.pkl')}")
    
    print("\n" + "="*80)
    print(f"Experiment completion time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"All results saved in: {exp_dir}")
    print("="*80)
    
    return {
        "experiment_dir": exp_dir,
        "trained_models": trained_models,
        "cv_results": cv_results,
        "test_results": test_results
    }

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int, default=886, help='Random seed')
    args = parser.parse_args()
    results = main(args.seed)