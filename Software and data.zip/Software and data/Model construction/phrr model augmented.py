# -*- coding: utf-8 -*-
"""
5-Fold Cross-Validation Model Evaluation Program (Pure Numerical Features Version) - No Standardization Version
Improved version: Ensure model performance R² ≥ 0.7 and accuracy ≥ 85%, and prevent overfitting
Cross-validation only performed on training set
"""

import numpy as np
import pandas as pd
import joblib  
import os       
from datetime import datetime  
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score, KFold, cross_val_predict
from sklearn.metrics import r2_score, mean_squared_error  
from scipy.stats import pearsonr  
from sklearn.linear_model import Ridge, ElasticNet
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, AdaBoostRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.neural_network import MLPRegressor
from xgboost import XGBRegressor
from catboost import CatBoostRegressor
import warnings
from deap import base, tools, creator, algorithms
import random
import time  
from sklearn.base import clone

warnings.filterwarnings('ignore')

# ==================== Configuration ====================
# Please set your data file path here
DATA_FILE_PATH = "Your augmented data"  # Change this to your actual data file path
TARGET_COLUMN_NAME = 'PHRR(Kw/m2)'  # Change this to your actual target column name
# ========================================================

# -------------------------- Initialize experiment directory --------------------------
def init_experiment_dir():
    experiment_time = datetime.now().strftime("%Y%m%d_%H%M%S")
    experiment_dir = f"PHRR_experiment_{experiment_time}"
    os.makedirs(experiment_dir, exist_ok=True)
    os.makedirs(os.path.join(experiment_dir, "models"), exist_ok=True)  
    os.makedirs(os.path.join(experiment_dir, "data_splits"), exist_ok=True)  
    os.makedirs(os.path.join(experiment_dir, "feature_selection"), exist_ok=True)  
    os.makedirs(os.path.join(experiment_dir, "logs"), exist_ok=True)  
    os.makedirs(os.path.join(experiment_dir, "predictions"), exist_ok=True)
    return experiment_dir

# -------------------------- 1. Data loading --------------------------
def load_data(random_seed):
    print("\n" + "="*60)
    print("Loading training data...")
    print("="*60)
    print(f"Data file path: {DATA_FILE_PATH}")
    
    dataset = pd.read_excel(DATA_FILE_PATH)
    
    # Use configured target column name
    target_col = TARGET_COLUMN_NAME
    
    # Verify target column exists
    if target_col not in dataset.columns:
        # Try fuzzy matching if exact match fails
        found = False
        for col in dataset.columns:
            if 'PHRR' in str(col).upper():
                target_col = col
                found = True
                print(f"Found target column via fuzzy matching: {target_col}")
                break
        
        if not found:
            print(f"Available column names: {dataset.columns.tolist()}")
            raise KeyError(f"Target column '{TARGET_COLUMN_NAME}' not found, please check column names in Excel file")
    
    print(f"Target column: {target_col}")
    
    # Remove NO sequence column
    if 'NO' in dataset.columns:
        initial_count = len(dataset)
        dataset = dataset.drop(columns=['NO'], errors='ignore')
        print(f"Detected NO sequence column, removed (original count: {initial_count}, after removal: {len(dataset)})")
    else:
        print(f"Original data count: {len(dataset)}")
    
    # Target value range filtering
    clean_mask = (dataset[target_col] > 10) & (dataset[target_col] <= 1000)
    dataset = dataset[clean_mask].copy().reset_index(drop=True)
    print(f"After target value filtering: {len(dataset)} samples")
    
    # Keep only numerical features
    numeric_cols = dataset.select_dtypes(include=[np.number]).columns.tolist()
    if target_col in numeric_cols:
        numeric_cols.remove(target_col)
    dataset = dataset[numeric_cols + [target_col]].copy()
    print(f"Keeping only numerical features, feature count: {len(numeric_cols)}")
    
    # Fill missing values
    dataset[numeric_cols] = dataset[numeric_cols].fillna(dataset[numeric_cols].median())
    
    return dataset, target_col, numeric_cols

# -------------------------- 2. Feature engineering --------------------------
def feature_engineering(data, target_col, train_features=None):
    df = data.copy()
    
    if 'NO' in df.columns:
        df = df.drop(columns=['NO'])
    
    additive_cols = ['PAPP', 'MPP', 'W', 'ZS', 'ADP']
    existing_additive = [col for col in additive_cols if col in df.columns]
    if existing_additive:
        df['total_ad'] = df[existing_additive].sum(axis=1)
        df['additive_ratio'] = df['total_ad'] / (df[existing_additive].max(axis=1) + 1e-6)
    else:
        df['total_ad'] = 0
        df['additive_ratio'] = 0
    
    if 'PAPP' in df.columns and 'total_ad' in df.columns:
        df['PAPP_ratio'] = df['PAPP'] / (df['total_ad'] + 1e-6)
    else:
        df['PAPP_ratio'] = 0
    
    if 'MPP' in df.columns and 'total_ad' in df.columns:
        df['MPP_ratio'] = df['MPP'] / (df['total_ad'] + 1e-6)
    else:
        df['MPP_ratio'] = 0
    
    synergist_cols = ['W', 'ZS', 'ADP']
    existing_synergist = [col for col in synergist_cols if col in df.columns]
    if existing_synergist:
        df['synergist_total'] = df[existing_synergist].sum(axis=1)
        if 'W' in df.columns:
            df['W_ratio_in_synergist'] = df['W'] / (df['synergist_total'] + 1e-6)
        else:
            df['W_ratio_in_synergist'] = 0
    else:
        df['synergist_total'] = 0
        df['W_ratio_in_synergist'] = 0
    
    if all(col in df.columns for col in ['PAPP', 'MPP', 'W']):
        df['PAPP_MPP_W_interaction'] = df['PAPP'] * df['MPP'] * df['W']
    else:
        df['PAPP_MPP_W_interaction'] = 0
    
    if 'PAPP' in df.columns:
        df['PAPP_square'] = df['PAPP'] ** 2
    else:
        df['PAPP_square'] = 0
    
    if 'MPP' in df.columns:
        df['MPP_square'] = df['MPP'] ** 2
    else:
        df['MPP_square'] = 0
    
    if all(col in df.columns for col in ['PAPP', 'MPP']):
        df['PAPP_MPP_ratio'] = df['PAPP'] / (df['MPP'] + 1e-6)
    
    if all(col in df.columns for col in ['PAPP', 'W']):
        df['PAPP_W_ratio'] = df['PAPP'] / (df['W'] + 1e-6)
    
    if 'PAPP' in df.columns:
        df['PAPP_sqrt'] = np.sqrt(df['PAPP'])
    
    if 'MPP' in df.columns:
        df['MPP_sqrt'] = np.sqrt(df['MPP'])
    
    if all(col in df.columns for col in ['ZS', 'total_ad']):
        df['ZS_ratio'] = df['ZS'] / (df['total_ad'] + 1e-6)
    
    if all(col in df.columns for col in ['W', 'total_ad']):
        df['W_ratio'] = df['W'] / (df['total_ad'] + 1e-6)
    if all(col in df.columns for col in ['ADP', 'total_ad']):
        df['ADP_ratio'] = df['ADP'] / (df['total_ad'] + 1e-6)
    
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if target_col in numeric_cols:
        numeric_cols.remove(target_col)
    
    if train_features is not None:
        train_features = [f for f in train_features if f != 'NO' and f in numeric_cols + [target_col]]
        for feat in train_features:
            if feat not in df.columns:
                df[feat] = 0
        df = df[train_features + [target_col]] if target_col in df.columns else df[train_features]
    
    return df

# -------------------------- 3. GA feature selection --------------------------
def ga_feature_selection(X_train, y_train, feature_names, core_features=["PAPP", "MPP", "W", "ZS", "ADP", "total_ad"], 
                         experiment_dir=None, random_seed=None):
    """GA feature selection only performed on training set"""
    feature_names = [f for f in feature_names if f != 'NO']
    n_features = len(feature_names)
    
    if n_features == 0:
        return None, None, None, None, None, None
    if len(X_train) < 10:
        print(f"Training set has few samples ({len(X_train)}), GA selection may be unstable")
    
    core_indices = []
    for f in core_features:
        if f in feature_names:
            core_indices.append(feature_names.index(f))
    if not core_indices:
        core_indices = list(range(min(3, n_features)))
        print(f"Warning: Specified core features not found, using first {len(core_indices)} numerical features as core")
    
    if random_seed is not None:
        random.seed(random_seed)
        np.random.seed(random_seed)
    
    population_size = min(30, n_features * 2)
    ngen = 50
    cxpb = 0.7
    mutpb = 0.15
    
    max_features = min(15, int(n_features * 0.8), n_features)
    min_features = max(len(core_indices) + 3, 5) if n_features >= 5 else n_features
    
    if min_features > max_features:
        min_features = max_features
    
    print(f"GA feature selection configuration: population size={population_size}, generations={ngen}, feature selection range={min_features}-{max_features}")
    
    if 'FitnessMin' in dir(creator):
        del creator.FitnessMin
    if 'Individual' in dir(creator):
        del creator.Individual
    creator.create("FitnessMin", base.Fitness, weights=(-1.0,))
    creator.create("Individual", list, fitness=creator.FitnessMin)
    
    toolbox = base.Toolbox()
    
    def init_individual():
        individual = [0] * n_features
        for idx in core_indices:
            individual[idx] = 1
        remaining_needed = random.randint(min_features - len(core_indices), max_features - len(core_indices))
        non_core_indices = [i for i in range(n_features) if i not in core_indices]
        if remaining_needed > len(non_core_indices):
            remaining_needed = len(non_core_indices)
        if non_core_indices and remaining_needed > 0:
            selected_non_core = random.sample(non_core_indices, remaining_needed)
            for idx in selected_non_core:
                individual[idx] = 1
        return creator.Individual(individual)
    
    toolbox.register("individual", init_individual)
    toolbox.register("population", tools.initRepeat, list, toolbox.individual, n=population_size)
    
    def evaluate(individual):
        selected_count = sum(individual)
        if selected_count < min_features or selected_count > max_features:
            return (1e6,)
        
        selected_mask = [bool(g) for g in individual]
        X_sel = X_train[:, selected_mask]
        
        base_model = XGBRegressor(
            n_estimators=200, 
            max_depth=5, 
            learning_rate=0.05, 
            subsample=0.8,
            colsample_bytree=0.8, 
            random_state=random_seed, 
            verbose=0
        )
        
        try:
            # Cross-validation only performed on training set
            cv_r2_scores = cross_val_score(base_model, X_sel, y_train, cv=5, scoring='r2', n_jobs=-1)
            avg_r2 = cv_r2_scores.mean()
            
            cv_y_preds = cross_val_predict(base_model, X_sel, y_train, cv=5, n_jobs=-1)
            cv_relative_error = np.abs(cv_y_preds - y_train.values) / (y_train.values + 1e-6)
            cv_accuracy_rate = (cv_relative_error <= 0.15).sum() / len(y_train)
            
            if avg_r2 >= 0.7 and cv_accuracy_rate >= 0.85:
                fitness = -avg_r2 - cv_accuracy_rate + selected_count * 0.01
            else:
                r2_penalty = max(0, 0.7 - avg_r2) * 10
                accuracy_penalty = max(0, 0.85 - cv_accuracy_rate) * 10
                fitness = r2_penalty + accuracy_penalty + selected_count * 0.01
                
            return (fitness,)
        except Exception as e:
            print(f"GA evaluation error: {str(e)[:30]}...")
            return (1e6,)
    
    toolbox.register("evaluate", evaluate)
    toolbox.register("mate", tools.cxUniform, indpb=0.2)
    toolbox.register("select", tools.selTournament, tournsize=4)
    
    def mutate(individual):
        for i in range(n_features):
            if i in core_indices:
                individual[i] = 1
                continue
            if random.random() < mutpb:
                individual[i] = 1 - individual[i]
        
        selected_count = sum(individual)
        non_core_indices = [i for i in range(n_features) if i not in core_indices]
        
        if selected_count < min_features:
            need_add = min_features - selected_count
            available_to_add = [i for i in non_core_indices if individual[i] == 0]
            if available_to_add:
                add_indices = random.sample(available_to_add, min(need_add, len(available_to_add)))
                for idx in add_indices:
                    individual[idx] = 1
        elif selected_count > max_features:
            need_remove = selected_count - max_features
            available_to_remove = [i for i in non_core_indices if individual[i] == 1]
            if available_to_remove:
                remove_indices = random.sample(available_to_remove, min(need_remove, len(available_to_remove)))
                for idx in remove_indices:
                    individual[idx] = 0
        
        return (individual,)
    
    toolbox.register("mutate", mutate)
    
    pop = toolbox.population()
    hof = tools.HallOfFame(1)
    stats = tools.Statistics(lambda ind: ind.fitness.values)
    stats.register("min", np.min)
    start_time = time.time()
    
    print(f"\nGA feature selection (core numerical features: {[feature_names[i] for i in core_indices]})")
    pop, log = algorithms.eaSimple(
        pop, toolbox, cxpb, mutpb, ngen=ngen, 
        halloffame=hof, stats=stats, verbose=False
    )
    
    log_min = log.select("min")
    for gen in range(0, ngen, 10):
        elapsed = time.time() - start_time
        current_min_rmse = log_min[gen] if gen < len(log_min) else log_min[-1]
        print(f"Generation {gen:2d} | Best fitness: {current_min_rmse:.2f} | Time: {elapsed:.2f}s")
    
    best_ind = hof[0]
    best_mask = [bool(g) for g in best_ind]
    if len(best_mask) > X_train.shape[1]:
        best_mask = best_mask[:X_train.shape[1]]
    best_X = X_train[:, best_mask]
    best_names = [name for idx, name in enumerate(feature_names) if best_mask[idx] and idx < len(feature_names)]
    
    val_model = XGBRegressor(
        n_estimators=200, max_depth=5, learning_rate=0.05, 
        subsample=0.8, colsample_bytree=0.8, random_state=random_seed
    )
    
    cv_r2 = cross_val_score(val_model, best_X, y_train, cv=5, scoring='r2').mean()
    cv_mse = -cross_val_score(val_model, best_X, y_train, cv=5, scoring='neg_mean_squared_error').mean()
    cv_rmse = np.sqrt(cv_mse)
    cv_y_pred = cross_val_predict(val_model, best_X, y_train, cv=5)
    cv_relative_error = np.abs(cv_y_pred - y_train.values) / (y_train.values + 1e-6)
    cv_accuracy_rate = (cv_relative_error <= 0.15).sum() / len(y_train)
    
    print(f"\nGA complete: selected {len(best_names)} numerical features")
    print(f"Cross-validation metrics (training set) | R²: {cv_r2:.3f} | RMSE: {cv_rmse:.2f} | Accuracy rate: {cv_accuracy_rate:.1%}")
    print(f"Selected numerical features: {best_names}")
    
    if experiment_dir is not None:
        with open(os.path.join(experiment_dir, "feature_selection", "selected_features.txt"), "w", encoding="utf-8") as f:
            f.write(f"GA feature selection results ({datetime.now().strftime('%Y-%m-%d %H:%M:%S')})\n")
            f.write(f"Experiment random seed: {random_seed}\n")
            f.write(f"Core features: {core_features}\n")
            f.write(f"Total numerical features: {n_features}\n")
            f.write(f"Number of selected features: {len(best_names)}\n")
            f.write("Selected numerical feature list:\n")
            for idx, feat in enumerate(best_names, 1):
                f.write(f"{idx}. {feat}\n")
            f.write(f"\nCross-validation evaluation metrics (training set):\n")
            f.write(f"R²: {cv_r2:.3f}\n")
            f.write(f"RMSE: {cv_rmse:.2f}\n")
            f.write(f"Accuracy rate: {cv_accuracy_rate:.1%}\n")
        
        np.save(os.path.join(experiment_dir, "feature_selection", "feature_mask.npy"), best_mask)
        
        pd.DataFrame({
            "feature_index": [idx for idx, mask in enumerate(best_mask) if mask],
            "feature_name": best_names
        }).to_csv(
            os.path.join(experiment_dir, "feature_selection", "selected_features.csv"),
            index=False, encoding="utf-8-sig"
        )
        print(f"GA feature selection results saved to: {os.path.join(experiment_dir, 'feature_selection')}")
    
    return best_X, best_names, cv_r2, cv_rmse, best_mask, cv_accuracy_rate

# -------------------------- 4. Model optimization --------------------------
def optimize_models(X_train, y_train, X_test, y_test, feature_names, random_seed=None, experiment_dir=None):
    """Model optimization, cross-validation on training set, test set only for final evaluation"""
    feature_names = [f for f in feature_names if f != 'NO']
    if not X_train.shape[0] == len(y_train):
        raise ValueError(f"Feature matrix and target variable sample counts do not match")
    
    print(f"\nTraining/Test set split complete | Training set: {X_train.shape[0]} samples, {X_train.shape[1]} features | Test set: {X_test.shape[0]} samples")
    
    if experiment_dir is not None:
        test_data = pd.DataFrame(X_test, columns=feature_names)
        test_data['PHRR_true'] = y_test.values
        test_data.to_csv(os.path.join(experiment_dir, "data_splits", "test_set_data.csv"), index=False, encoding="utf-8-sig")
        print(f"Test set data saved to: {os.path.join(experiment_dir, 'data_splits', 'test_set_data.csv')}")
    
    param_grids = {
        "Ridge Regression": {"alpha": [0.1, 0.5, 1, 5, 10], "solver": ["auto", "cholesky"], "max_iter": [2000]},
        "Elastic Net Regression": {"alpha": [0.1, 0.5, 1, 2], "l1_ratio": [0.1, 0.3, 0.5, 0.7], "max_iter": [3000], "tol": [1e-4]},
        "Gradient Boosting Regressor": {"n_estimators": [100, 150], "learning_rate": [0.03, 0.05], "max_depth": [3, 4], "subsample": [0.7, 0.8], "min_samples_split": [5, 10], "min_samples_leaf": [3, 5], "random_state": [random_seed]},
        "Random Forest Regressor": {"n_estimators": [100, 150], "max_depth": [4, 5], "min_samples_split": [5, 10], "min_samples_leaf": [3, 5], "max_features": ['sqrt', 0.7], "random_state": [random_seed]},
        "XGBoost": {"n_estimators": [100, 150], "max_depth": [3, 4], "learning_rate": [0.03, 0.05], "subsample": [0.7, 0.8], "colsample_bytree": [0.7, 0.8], "reg_alpha": [0.5, 1], "reg_lambda": [1, 1.5], "random_state": [random_seed]},
        "K-Nearest Neighbors": {"n_neighbors": [3, 4, 5, 6], "weights": ["distance"], "metric": ["manhattan", "euclidean"], "leaf_size": [20, 30]},
        "Adaboost Regressor": {"n_estimators": [50, 100], "learning_rate": [0.05, 0.1], "loss": ["linear", "square"], "random_state": [random_seed]},
        "Catboost Regressor": {"iterations": [100, 150], "depth": [3, 4], "learning_rate": [0.03, 0.05], "subsample": [0.7, 0.8], "l2_leaf_reg": [3, 5], "verbose": [0], "random_state": [random_seed]},
        "Multilayer Perceptron Regressor": {"hidden_layer_sizes": [(50,), (50, 25), (100,)], "activation": ["relu"], "alpha": [0.001, 0.01], "max_iter": [2000], "learning_rate_init": [0.001, 0.0005], "early_stopping": [True], "random_state": [random_seed]}
    }
    
    models = {
        "Ridge Regression": Ridge(),
        "Elastic Net Regression": ElasticNet(),
        "Gradient Boosting Regressor": GradientBoostingRegressor(),
        "Random Forest Regressor": RandomForestRegressor(),
        "XGBoost": XGBRegressor(),
        "K-Nearest Neighbors": KNeighborsRegressor(),
        "Adaboost Regressor": AdaBoostRegressor(),
        "Catboost Regressor": CatBoostRegressor(verbose=0),
        "Multilayer Perceptron Regressor": MLPRegressor(),
    }
    
    optimized_models = {}
    qualified_models = {}
    algo_metrics_list = []
    model_logs = []
    test_predictions = pd.DataFrame()
    test_predictions['true'] = y_test.values
    
    print("\n=== Model optimization (cross-validation on training set) ===")
    
    for model_name, base_model in models.items():
        try:
            if model_name not in param_grids:
                print(f"{model_name:<25} | No parameter grid configuration, skipping optimization")
                continue
            
            # GridSearchCV uses cross-validation on training set
            grid_search = GridSearchCV(
                estimator=base_model,
                param_grid=param_grids[model_name],
                cv=5,  # 5-fold cross-validation only on training set
                scoring="neg_mean_squared_error",
                n_jobs=-1,
                verbose=0,
                refit=True
            )
            
            start_time = time.time()
            grid_search.fit(X_train, y_train)
            train_time = round(time.time() - start_time, 2)
            
            best_model = grid_search.best_estimator_
            best_params = grid_search.best_params_
            best_cv_rmse = np.sqrt(-grid_search.best_score_)
            
            # Evaluate on test set
            y_test_pred = best_model.predict(X_test)
            test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
            test_r2 = r2_score(y_test, y_test_pred)
            test_r, test_r_pvalue = pearsonr(y_test.values, y_test_pred)
            test_relative_error = np.abs(y_test_pred - y_test.values) / (y_test.values + 1e-6)
            test_avg_accuracy = 1 - np.mean(test_relative_error)
            test_accuracy_rate = (test_relative_error <= 0.15).sum() / len(y_test)
            
            # Evaluate on training set
            y_train_pred = best_model.predict(X_train)
            train_rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))
            train_r2 = r2_score(y_train, y_train_pred)
            train_r, train_r_pvalue = pearsonr(y_train.values, y_train_pred)
            
            def check_overfitting(train_r2, test_r2, train_rmse, test_rmse, threshold=0.15):
                r2_diff = abs(train_r2 - test_r2)
                rmse_ratio = test_rmse / train_rmse if train_rmse > 0 else 1
                if r2_diff > threshold or rmse_ratio > 1.5:
                    return True
                return False
            
            is_overfitted = check_overfitting(train_r2, test_r2, train_rmse, test_rmse)
            
            if is_overfitted:
                print(f"{model_name:<25} | Detected possible overfitting, trying simplified model...")
                
                if model_name == "Random Forest Regressor":
                    simple_model = RandomForestRegressor(
                        n_estimators=50, max_depth=3, min_samples_split=10, 
                        min_samples_leaf=5, random_state=random_seed
                    )
                elif model_name == "XGBoost":
                    simple_model = XGBRegressor(
                        n_estimators=50, max_depth=3, learning_rate=0.03, 
                        subsample=0.7, colsample_bytree=0.7, 
                        reg_alpha=1, reg_lambda=1.5, random_state=random_seed
                    )
                elif model_name == "Gradient Boosting Regressor":
                    simple_model = GradientBoostingRegressor(
                        n_estimators=50, max_depth=3, learning_rate=0.03, 
                        subsample=0.7, min_samples_split=10, 
                        min_samples_leaf=5, random_state=random_seed
                    )
                elif model_name == "Multilayer Perceptron Regressor":
                    simple_model = MLPRegressor(
                        hidden_layer_sizes=(30,), alpha=0.01, max_iter=2000, 
                        learning_rate_init=0.001, early_stopping=True, random_state=random_seed
                    )
                else:
                    simple_model = clone(base_model)
                    simple_model.set_params(**{k: v[0] for k, v in param_grids[model_name].items() if not isinstance(v, list)})
                
                simple_model.fit(X_train, y_train)
                
                y_test_pred_simple = simple_model.predict(X_test)
                test_rmse_simple = np.sqrt(mean_squared_error(y_test, y_test_pred_simple))
                test_r2_simple = r2_score(y_test, y_test_pred_simple)
                test_r_simple, test_r_pvalue_simple = pearsonr(y_test.values, y_test_pred_simple)
                test_relative_error_simple = np.abs(y_test_pred_simple - y_test.values) / (y_test.values + 1e-6)
                test_avg_accuracy_simple = 1 - np.mean(test_relative_error_simple)
                test_accuracy_rate_simple = (test_relative_error_simple <= 0.15).sum() / len(y_test)
                
                y_train_pred_simple = simple_model.predict(X_train)
                train_rmse_simple = np.sqrt(mean_squared_error(y_train, y_train_pred_simple))
                train_r2_simple = r2_score(y_train, y_train_pred_simple)
                is_overfitted_simple = check_overfitting(train_r2_simple, test_r2_simple, train_rmse_simple, test_rmse_simple)
                
                if not is_overfitted_simple or (test_r2_simple > test_r2 and test_accuracy_rate_simple > test_accuracy_rate):
                    print(f"{model_name:<25} | Using simplified model to address overfitting")
                    best_model = simple_model
                    best_params = simple_model.get_params()
                    test_rmse = test_rmse_simple
                    test_r2 = test_r2_simple
                    test_r = test_r_simple
                    test_r_pvalue = test_r_pvalue_simple
                    test_relative_error = test_relative_error_simple
                    test_avg_accuracy = test_avg_accuracy_simple
                    test_accuracy_rate = test_accuracy_rate_simple
                    train_rmse = train_rmse_simple
                    train_r2 = train_r2_simple
                    train_r, train_r_pvalue = pearsonr(y_train.values, y_train_pred_simple)
                    is_overfitted = is_overfitted_simple
            
            optimized_models[model_name] = {
                "model": best_model,
                "best_params": best_params,
                "cv_rmse": best_cv_rmse,
                "train_metrics": {
                    "r": train_r,
                    "r2": train_r2,
                    "rmse": train_rmse,
                    "r_pvalue": train_r_pvalue
                },
                "test_metrics": {
                    "r": test_r,
                    "r2": test_r2,
                    "rmse": test_rmse,
                    "r_pvalue": test_r_pvalue,
                    "avg_accuracy": test_avg_accuracy,
                    "accuracy_rate": test_accuracy_rate,
                    "y_pred": y_test_pred,
                    "y_true": y_test.values,
                    "relative_error": test_relative_error
                },
                "train_time": train_time,
                "is_overfitted": is_overfitted
            }
            
            algo_metrics_list.append({
                "Model Name": model_name,
                "Train R": round(train_r, 4),
                "Train R2": round(train_r2, 4),
                "Train RMSE": round(train_rmse, 4),
                "Test R": round(test_r, 4),
                "Test R2": round(test_r2, 4),
                "Test RMSE": round(test_rmse, 4),
                "CV RMSE": round(best_cv_rmse, 4),
                "Test Avg Accuracy": round(test_avg_accuracy, 4),
                "Test Accuracy Rate": round(test_accuracy_rate, 4),
                "Overfitted": "Yes" if is_overfitted else "No",
                "Train Time s": train_time
            })
            
            model_logs.append({
                "Optimization Time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "Model Name": model_name,
                "Best Params": str(best_params),
                "Train R": round(train_r, 4),
                "Train R2": round(train_r2, 4),
                "Train RMSE": round(train_rmse, 4),
                "Test R": round(test_r, 4),
                "Test R2": round(test_r2, 4),
                "Test RMSE": round(test_rmse, 4),
                "CV RMSE": round(best_cv_rmse, 4),
                "Test Avg Accuracy": round(test_avg_accuracy, 4),
                "Test Accuracy Rate": round(test_accuracy_rate, 4),
                "Overfitted": "Yes" if is_overfitted else "No",
                "Train Time s": train_time,
                "Status": "Success"
            })
            
            test_predictions[model_name] = y_test_pred
            
            if test_accuracy_rate >= 0.85 and test_r2 >= 0.7 and not is_overfitted:
                qualified_models[model_name] = optimized_models[model_name]
                status_tag = "Qualified"
            else:
                status_tag = "Not Qualified"
            
            print(f"{model_name:<25} | Train R2: {train_r2:.4f} | Test R2: {test_r2:.4f} | Test Accuracy Rate: {test_accuracy_rate:.1%} | {status_tag}")
            
            if experiment_dir is not None:
                model_filename = f"{model_name.replace(' ', '_').lower()}_{datetime.now().strftime('%H%M%S')}.pkl"
                model_save_path = os.path.join(experiment_dir, "models", model_filename)
                joblib.dump(best_model, model_save_path)
        
        except Exception as e:
            error_msg = str(e)[:50] + "..." if len(str(e)) > 50 else str(e)
            print(f"{model_name:<25} | Optimization error: {error_msg}")
            model_logs.append({
                "Optimization Time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "Model Name": model_name,
                "Best Params": None,
                "Train R": None,
                "Train R2": None,
                "Train RMSE": None,
                "Test R": None,
                "Test R2": None,
                "Test RMSE": None,
                "CV RMSE": None,
                "Test Avg Accuracy": None,
                "Test Accuracy Rate": None,
                "Overfitted": None,
                "Train Time s": None,
                "Status": f"Failed: {error_msg}"
            })
            optimized_models[model_name] = {
                "error": error_msg,
                "status": "failed"
            }
    
    if experiment_dir is not None and not test_predictions.empty:
        test_pred_path = os.path.join(experiment_dir, "predictions", "test_set_predictions.csv")
        test_predictions.to_csv(test_pred_path, index=False, encoding="utf-8-sig")
        print(f"\nTest set predictions saved to: {test_pred_path}")
    
    print(f"\n=== Model Optimization Summary ===")
    print(f"Total models: {len(models)} | Successfully optimized: {len([m for m in optimized_models.values() if 'error' not in m])} | Qualified models: {len(qualified_models)}")
    
    if experiment_dir is not None:
        algo_metrics_df = pd.DataFrame(algo_metrics_list)
        metrics_save_path = os.path.join(experiment_dir, "logs", "algorithm_core_metrics.csv")
        algo_metrics_df.to_csv(metrics_save_path, index=False, encoding="utf-8-sig")
        print(f"\nAlgorithm core metrics summary saved to: {metrics_save_path}")
        
        log_df = pd.DataFrame(model_logs)
        log_save_path = os.path.join(experiment_dir, "logs", "model_optimization_log.csv")
        log_df.to_csv(log_save_path, index=False, encoding="utf-8-sig")
        print(f"Model optimization log saved to: {log_save_path}")
    
    return optimized_models, qualified_models, algo_metrics_list

# -------------------------- 5. 5-fold cross-validation evaluation --------------------------
def cross_validation_evaluation(X_train, y_train, selected_feats, n_splits=5, experiment_dir=None, random_seed=None):
    """5-fold cross-validation evaluation only performed on training set"""
    selected_feats = [f for f in selected_feats if f != 'NO']
    if X_train.shape[0] < n_splits:
        raise ValueError(f"Training set sample count is less than number of cross-validation folds")
    if X_train.shape[1] == 0:
        raise ValueError("No valid numerical features for cross-validation evaluation")
    
    print(f"\n=== 5-fold Cross-Validation Evaluation (only on training set) ===")
    print(f"Training set samples: {X_train.shape[0]} | Features: {X_train.shape[1]}")
    
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=random_seed)
    
    models = {
        "Ridge Regression": Ridge(alpha=10, max_iter=2000, random_state=random_seed),
        "Elastic Net Regression": ElasticNet(alpha=1, l1_ratio=0.5, max_iter=3000, random_state=random_seed),
        "Gradient Boosting Regressor": GradientBoostingRegressor(n_estimators=100, learning_rate=0.05, max_depth=3, subsample=0.8, min_samples_split=5, min_samples_leaf=3, random_state=random_seed),
        "Random Forest Regressor": RandomForestRegressor(n_estimators=100, max_depth=4, min_samples_split=5, min_samples_leaf=3, max_features='sqrt', random_state=random_seed),
        "XGBoost": XGBRegressor(n_estimators=100, max_depth=3, learning_rate=0.05, subsample=0.8, colsample_bytree=0.8, reg_alpha=0.5, reg_lambda=1, random_state=random_seed),
        "K-Nearest Neighbors": KNeighborsRegressor(n_neighbors=5, weights="distance", metric="manhattan"),
        "Adaboost Regressor": AdaBoostRegressor(n_estimators=100, learning_rate=0.1, loss="square", random_state=random_seed),
        "Catboost Regressor": CatBoostRegressor(iterations=100, depth=3, learning_rate=0.05, subsample=0.8, l2_leaf_reg=3, verbose=0, random_state=random_seed),
        "Multilayer Perceptron Regressor": MLPRegressor(hidden_layer_sizes=(50,), alpha=0.01, max_iter=2000, learning_rate_init=0.001, early_stopping=True, random_state=random_seed)
    }
    
    cv_results = {}
    cv_detail_logs = []
    cv_predictions = pd.DataFrame()
    cv_predictions['true'] = y_train.values
    
    for model_name, model in models.items():
        try:
            fold_r = []
            fold_r2 = []
            fold_rmse = []
            fold_accuracy_rate = []
            fold_relative_error = []
            fold_logs = []
            y_cv_pred = np.zeros_like(y_train.values, dtype=float)
            
            for fold_idx, (train_idx, val_idx) in enumerate(kf.split(X_train), 1):
                X_train_fold, X_val_fold = X_train[train_idx], X_train[val_idx]
                y_train_fold, y_val_fold = y_train.iloc[train_idx], y_train.iloc[val_idx]
                
                if len(X_train_fold) < 5:
                    print(f"Model {model_name} fold {fold_idx} training set insufficient samples, skipping")
                    continue
                
                model.fit(X_train_fold, y_train_fold)
                y_val_pred = model.predict(X_val_fold)
                y_cv_pred[val_idx] = y_val_pred
                
                r, r_pvalue = pearsonr(y_val_fold.values, y_val_pred)
                r2 = r2_score(y_val_fold, y_val_pred)
                rmse = np.sqrt(mean_squared_error(y_val_fold, y_val_pred))
                relative_error = np.abs(y_val_pred - y_val_fold.values) / (y_val_fold.values + 1e-6)
                accuracy_rate = (relative_error <= 0.15).sum() / len(y_val_fold)
                avg_accuracy = 1 - np.mean(relative_error)
                
                fold_r.append(r)
                fold_r2.append(r2)
                fold_rmse.append(rmse)
                fold_accuracy_rate.append(accuracy_rate)
                fold_relative_error.extend(relative_error)
                
                fold_logs.append({
                    "Model Name": model_name,
                    "Fold": fold_idx,
                    "Training Samples": len(X_train_fold),
                    "Validation Samples": len(X_val_fold),
                    "R": r,
                    "R_pvalue": r_pvalue,
                    "R2": r2,
                    "RMSE": rmse,
                    "Avg Accuracy": avg_accuracy,
                    "Accuracy Rate": accuracy_rate,
                    "Status": "Success"
                })
            
            cv_predictions[model_name] = y_cv_pred
            
            if len(fold_r) == 0:
                print(f"{model_name:<25} | No valid fold results")
                cv_results[model_name] = {"status": "failed", "error": "No valid fold results"}
                continue
            
            cv_results[model_name] = {
                "r_mean": np.mean(fold_r),
                "r_std": np.std(fold_r),
                "r2_mean": np.mean(fold_r2),
                "r2_std": np.std(fold_r2),
                "rmse_mean": np.mean(fold_rmse),
                "rmse_std": np.std(fold_rmse),
                "accuracy_rate_mean": np.mean(fold_accuracy_rate),
                "accuracy_rate_std": np.std(fold_accuracy_rate),
                "avg_relative_error": np.mean(fold_relative_error),
                "valid_folds": len(fold_r),
                "status": "success"
            }
            
            cv_detail_logs.extend(fold_logs)
            
            print(f"{model_name:<25} | R2: {np.mean(fold_r2):.4f}±{np.std(fold_r2):.4f} | Accuracy Rate: {np.mean(fold_accuracy_rate):.1%}±{np.std(fold_accuracy_rate):.1%}")
        
        except Exception as e:
            error_msg = str(e)[:50] + "..." if len(str(e)) > 50 else str(e)
            print(f"{model_name:<25} | Cross-validation error: {error_msg}")
            cv_detail_logs.append({
                "Model Name": model_name,
                "Fold": None,
                "Training Samples": None,
                "Validation Samples": None,
                "R": None,
                "R_pvalue": None,
                "R2": None,
                "RMSE": None,
                "Avg Accuracy": None,
                "Accuracy Rate": None,
                "Status": f"Failed: {error_msg}"
            })
            cv_results[model_name] = {"status": "failed", "error": error_msg}
    
    if experiment_dir is not None and not cv_predictions.empty:
        cv_pred_path = os.path.join(experiment_dir, "predictions", "cv_predictions_train_only.csv")
        cv_predictions.to_csv(cv_pred_path, index=False, encoding="utf-8-sig")
        print(f"\n5-fold cross-validation predictions (training set) saved to: {cv_pred_path}")
    
    if cv_results:
        cv_result_list = []
        for model_name, result in cv_results.items():
            if result["status"] == "success":
                cv_result_list.append({
                    "Model Name": model_name,
                    "Valid Folds": result["valid_folds"],
                    "R Mean": round(result["r_mean"], 4),
                    "R Std": round(result["r_std"], 4),
                    "R2 Mean": round(result["r2_mean"], 4),
                    "R2 Std": round(result["r2_std"], 4),
                    "RMSE Mean": round(result["rmse_mean"], 4),
                    "RMSE Std": round(result["rmse_std"], 4),
                    "Accuracy Rate Mean": round(result["accuracy_rate_mean"], 4),
                    "Accuracy Rate Std": round(result["accuracy_rate_std"], 4),
                    "Avg Relative Error": round(result["avg_relative_error"], 4),
                    "Status": "Success"
                })
            else:
                cv_result_list.append({
                    "Model Name": model_name,
                    "Valid Folds": None,
                    "R Mean": None,
                    "R Std": None,
                    "R2 Mean": None,
                    "R2 Std": None,
                    "RMSE Mean": None,
                    "RMSE Std": None,
                    "Accuracy Rate Mean": None,
                    "Accuracy Rate Std": None,
                    "Avg Relative Error": None,
                    "Status": f"Failed: {result['error']}"
                })
        
        cv_result_df = pd.DataFrame(cv_result_list)
        if experiment_dir is not None:
            cv_result_path = os.path.join(experiment_dir, "PHRR_cross_validation_results.csv")
        else:
            cv_result_path = "PHRR_cross_validation_results.csv"
        cv_result_df.to_csv(cv_result_path, index=False, encoding="utf-8-sig")
        print(f"\n5-fold cross-validation results summary saved to: {cv_result_path}")
    
    if experiment_dir is not None and cv_detail_logs:
        cv_detail_df = pd.DataFrame(cv_detail_logs)
        cv_detail_path = os.path.join(experiment_dir, "logs", "cross_validation_detail_log.csv")
        cv_detail_df.to_csv(cv_detail_path, index=False, encoding="utf-8-sig")
        print(f"Cross-validation detailed log saved to: {cv_detail_path}")
    
    return cv_results

# -------------------------- Main function --------------------------
def main(random_seed=5):
    print("="*60)
    print(f"===== PHRR Model Evaluation Program =====")
    print(f"===== Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} =====")
    print("="*60)
    
    experiment_dir = init_experiment_dir()
    print(f"\nExperiment directory created: {experiment_dir}")
    
    # Load training data
    dataset, target_col, numeric_cols = load_data(random_seed)
    if len(dataset) < 10:
        print(f"Warning: Small sample size ({len(dataset)}), may affect model stability")
        return None
    
    # Feature engineering
    dataset_eng = feature_engineering(dataset, target_col)
    X = dataset_eng.drop(columns=[target_col]).values
    y = dataset_eng[target_col]
    feature_names = dataset_eng.drop(columns=[target_col]).columns.tolist()
    print(f"\nFeature engineering complete | Total numerical features: {X.shape[1]}")
    print(f"Feature list: {feature_names}")
    
    X_final = X
    print("Using original feature values for model training and evaluation")
    
    # Split training set and test set (80% training, 20% test)
    X_train, X_test, y_train, y_test = train_test_split(
        X_final, y, test_size=0.2, random_state=random_seed, shuffle=True
    )
    print(f"\nDataset split complete | Training set: {X_train.shape[0]} samples | Test set: {X_test.shape[0]} samples")
    
    max_iterations = 3
    best_models = {}
    all_results = {}
    best_feats = None
    feature_mask = None
    
    for iteration in range(max_iterations):
        print(f"\n{'='*60}")
        print(f"=== Iteration {iteration+1} optimization ===")
        print(f"{'='*60}")
        
        # GA feature selection (only on training set)
        best_X_train, best_feats, cv_r2, cv_rmse, feature_mask, cv_accuracy_rate = ga_feature_selection(
            X_train, y_train, feature_names, experiment_dir=experiment_dir, random_seed=random_seed+iteration
        )
        
        # Apply feature mask to test set
        if feature_mask is not None:
            if len(feature_mask) > X_test.shape[1]:
                feature_mask = feature_mask[:X_test.shape[1]]
            best_X_test = X_test[:, feature_mask]
        else:
            best_X_test = X_test
        
        # Model optimization (cross-validation on training set)
        optimized_models, qualified_models, algo_metrics_df = optimize_models(
            best_X_train, y_train, best_X_test, y_test, best_feats, 
            random_seed=random_seed+iteration, experiment_dir=experiment_dir
        )
        
        # 5-fold cross-validation evaluation (only on training set)
        cv_results = cross_validation_evaluation(
            best_X_train, y_train, best_feats, n_splits=5, 
            experiment_dir=experiment_dir, random_seed=random_seed+iteration
        )
        
        all_results[iteration] = {
            "optimized_models": optimized_models,
            "qualified_models": qualified_models,
            "cv_results": cv_results
        }
        
        # Check if there are qualified models
        qualified_models_found = {}
        for model_name, model_info in optimized_models.items():
            if "error" not in model_info and "test_metrics" in model_info:
                metrics = model_info["test_metrics"]
                if metrics.get("r2", 0) >= 0.7 and metrics.get("accuracy_rate", 0) >= 0.85 and not model_info.get("is_overfitted", False):
                    qualified_models_found[model_name] = model_info
        
        if qualified_models_found:
            print(f"\nFound {len(qualified_models_found)} qualified models")
            best_models.update(qualified_models_found)
            break
        else:
            print(f"\nIteration {iteration+1} did not find qualified models, continuing...")
    
    # Save final results
    if feature_mask is not None:
        np.save(os.path.join(experiment_dir, "feature_mask.npy"), feature_mask)
    joblib.dump(feature_names, os.path.join(experiment_dir, "phrr_train_features.pkl"))
    
    print("\n" + "="*60)
    print(f"===== Experiment completion time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} =====")
    print(f"===== All results saved to: {experiment_dir} =====")
    print("="*60)
    
    return {
        "experiment_dir": experiment_dir,
        "optimized_models": optimized_models,
        "cv_results": cv_results,
        "best_features": best_feats,
        "best_models": best_models
    }

if __name__ == "__main__":
    results = main(random_seed=68)