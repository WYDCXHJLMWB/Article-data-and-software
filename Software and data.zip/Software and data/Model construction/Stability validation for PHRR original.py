# -*- coding: utf-8 -*-
"""
Created on Thu Apr 23 14:12:04 2026

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
CatBoost Model Stability Test Program (Based on Complete Training Pipeline)
Function: Perform 150 repeated stability validations on optimal CatBoost model
Read optimal parameters from specified experiment directory
"""

import numpy as np
import pandas as pd
import os
import sys
from datetime import datetime
from sklearn.model_selection import train_test_split, KFold, GridSearchCV
from catboost import CatBoostRegressor
from sklearn.metrics import r2_score, mean_squared_error
from scipy.stats import pearsonr
import warnings
import time
import joblib
import ast

warnings.filterwarnings('ignore')

# ==================== Please set your file paths here ====================
# Training data path (consistent with main program)
TRAIN_DATA_PATH = r"phrr.xlsx"
# Experiment directory path (contains optimal model parameters)
EXPERIMENT_DIR = r"Your logs of model based on original data"
# ========================================================================

# =======================  Data loading and cleaning functions  =======================
def load_data():
    """Load training data (consistent with main program)"""
    print("\n" + "="*60)
    print("Loading training data...")
    print("="*60)
    
    if not os.path.exists(TRAIN_DATA_PATH):
        raise FileNotFoundError(f"Training data file not found: {TRAIN_DATA_PATH}")
    
    dataset = pd.read_excel(TRAIN_DATA_PATH)
    print(f"Original data shape: {dataset.shape}")
    
    # Intelligently find target column
    possible_target_names = ['PHRR（Kw/m2）', 'PHRR(Kw/m2)', 'PHRR', 'PHRR（Kw/m²）', 'PHRR(Kw/m²)']
    target_col = None
    
    for col_name in possible_target_names:
        if col_name in dataset.columns:
            target_col = col_name
            break
    
    if target_col is None:
        for col in dataset.columns:
            if 'PHRR' in str(col).upper():
                target_col = col
                print(f"Found target column via fuzzy matching: {target_col}")
                break
    
    if target_col is None:
        raise KeyError("Target column not found, please check column names in Excel file")
    
    print(f"Target column: {target_col}")
    
    # Remove NO sequence column
    if 'NO' in dataset.columns:
        initial_count = len(dataset)
        dataset = dataset.drop(columns=['NO'], errors='ignore')
        print(f"Removed NO column (original: {initial_count}, after: {len(dataset)})")
    
    # Target value range filtering
    clean_mask = (dataset[target_col] > 10) & (dataset[target_col] <= 1500)
    dataset = dataset[clean_mask].copy().reset_index(drop=True)
    print(f"After target filtering: {len(dataset)} samples")
    
    # Keep only numerical features
    numeric_cols = dataset.select_dtypes(include=[np.number]).columns.tolist()
    if target_col in numeric_cols:
        numeric_cols.remove(target_col)
    
    # Remove constant features
    constant_features = []
    for col in numeric_cols:
        if dataset[col].std() == 0:
            constant_features.append(col)
    
    if constant_features:
        print(f"Removing constant features: {constant_features}")
        dataset = dataset.drop(columns=constant_features)
        numeric_cols = [col for col in numeric_cols if col not in constant_features]
    
    # Fill missing values
    dataset[numeric_cols] = dataset[numeric_cols].fillna(dataset[numeric_cols].median())
    
    print(f"Final data shape: {dataset.shape}")
    print(f"Valid feature count: {len(numeric_cols)}")
    
    return dataset, target_col, numeric_cols

# =======================  Feature engineering function  =======================
def feature_engineering(data, target_col, selected_features=None):
    """Feature engineering (consistent with main program)"""
    df = data.copy()
    
    if 'NO' in df.columns:
        df = df.drop(columns=['NO'])
    
    # Numerical feature enhancement (consistent with main program)
    additive_cols = ['PAPP', 'MPP', 'W', 'ZS', 'ADP']
    existing_additive = [col for col in additive_cols if col in df.columns]
    if existing_additive:
        df['total_ad'] = df[existing_additive].sum(axis=1)
        df['additive_ratio'] = df['total_ad'] / (df[existing_additive].max(axis=1) + 1e-6)
    else:
        df['total_ad'] = 0
        df['additive_ratio'] = 0
    
    if 'PAPP' in df.columns and 'total_ad' in df.columns:
        df['PAPP_ratio'] = df['PAPP'] / (df['total_ad'] + 1e-6)
    else:
        df['PAPP_ratio'] = 0
    
    if 'MPP' in df.columns and 'total_ad' in df.columns:
        df['MPP_ratio'] = df['MPP'] / (df['total_ad'] + 1e-6)
    else:
        df['MPP_ratio'] = 0
    
    synergist_cols = ['W', 'ZS', 'ADP']
    existing_synergist = [col for col in synergist_cols if col in df.columns]
    if existing_synergist:
        df['synergist_total'] = df[existing_synergist].sum(axis=1)
        if 'W' in df.columns:
            df['W_ratio_in_synergist'] = df['W'] / (df['synergist_total'] + 1e-6)
        else:
            df['W_ratio_in_synergist'] = 0
    else:
        df['synergist_total'] = 0
        df['W_ratio_in_synergist'] = 0
    
    if all(col in df.columns for col in ['PAPP', 'MPP', 'W']):
        df['PAPP_MPP_W_interaction'] = df['PAPP'] * df['MPP'] * df['W']
    else:
        df['PAPP_MPP_W_interaction'] = 0
    
    if 'PAPP' in df.columns:
        df['PAPP_square'] = df['PAPP'] ** 2
    else:
        df['PAPP_square'] = 0
    
    if 'MPP' in df.columns:
        df['MPP_square'] = df['MPP'] ** 2
    else:
        df['MPP_square'] = 0
    
    if all(col in df.columns for col in ['PAPP', 'MPP']):
        df['PAPP_MPP_ratio'] = df['PAPP'] / (df['MPP'] + 1e-6)
    
    if all(col in df.columns for col in ['PAPP', 'W']):
        df['PAPP_W_ratio'] = df['PAPP'] / (df['W'] + 1e-6)
    
    if 'PAPP' in df.columns:
        df['PAPP_sqrt'] = np.sqrt(df['PAPP'])
    
    if 'MPP' in df.columns:
        df['MPP_sqrt'] = np.sqrt(df['MPP'])
    
    if all(col in df.columns for col in ['ZS', 'total_ad']):
        df['ZS_ratio'] = df['ZS'] / (df['total_ad'] + 1e-6)
    
    if all(col in df.columns for col in ['W', 'total_ad']):
        df['W_ratio'] = df['W'] / (df['total_ad'] + 1e-6)
    if all(col in df.columns for col in ['ADP', 'total_ad']):
        df['ADP_ratio'] = df['ADP'] / (df['total_ad'] + 1e-6)
    
    # If selected features are provided, keep only those features
    if selected_features is not None:
        available_features = [f for f in selected_features if f in df.columns]
        missing_features = [f for f in selected_features if f not in df.columns]
        if missing_features:
            print(f"Warning: Features not found: {missing_features}")
        if target_col in df.columns:
            df = df[available_features + [target_col]]
        else:
            df = df[available_features]
    
    return df

# =======================  Get CatBoost optimal parameters  =======================
def get_optimal_catboost_params(experiment_dir):
    """
    Read optimal CatBoost parameters from experiment directory
    """
    print("\n" + "="*60)
    print("Reading CatBoost optimal parameters...")
    print("="*60)
    print(f"Experiment directory: {experiment_dir}")
    
    # Default parameters
    catboost_params = {
        'iterations': 100,
        'depth': 3,
        'learning_rate': 0.05,
        'subsample': 0.8,
        'l2_leaf_reg': 3,
        'random_seed': None
    }
    
    # Try to read from log file
    log_file = os.path.join(experiment_dir, "logs", "model_optimization_log.csv")
    if os.path.exists(log_file):
        try:
            log_df = pd.read_csv(log_file)
            catboost_log = log_df[log_df['Model Name'] == 'Catboost Regressor']
            if not catboost_log.empty and 'Best Params' in catboost_log.columns:
                params_str = catboost_log.iloc[0]['Best Params']
                # Parse parameter string
                if isinstance(params_str, str):
                    params_dict = ast.literal_eval(params_str)
                    
                    # Update parameters
                    for key in ['iterations', 'depth', 'learning_rate', 'subsample', 'l2_leaf_reg']:
                        if key in params_dict:
                            catboost_params[key] = params_dict[key]
                    
                    print(f"Read CatBoost optimal parameters from log file: {catboost_params}")
        except Exception as e:
            print(f"Failed to read log file: {str(e)}")
    
    # Try to read from model file
    models_dir = os.path.join(experiment_dir, "models")
    if os.path.exists(models_dir):
        model_files = [f for f in os.listdir(models_dir) if 'catboost' in f.lower() and f.endswith('.pkl')]
        if model_files:
            try:
                model_file = os.path.join(models_dir, model_files[0])
                model = joblib.load(model_file)
                if hasattr(model, 'get_params'):
                    params = model.get_params()
                    catboost_params['iterations'] = params.get('iterations', 100)
                    catboost_params['depth'] = params.get('depth', 3)
                    catboost_params['learning_rate'] = params.get('learning_rate', 0.05)
                    catboost_params['subsample'] = params.get('subsample', 0.8)
                    catboost_params['l2_leaf_reg'] = params.get('l2_leaf_reg', 3)
                    print(f"Read CatBoost parameters from model file: {catboost_params}")
            except Exception as e:
                print(f"Failed to read model file: {str(e)}")
    
    print(f"Final CatBoost parameters:")
    for key, value in catboost_params.items():
        print(f"  {key}: {value}")
    
    return catboost_params

# =======================  Get selected features  =======================
def get_selected_features(experiment_dir):
    """Read selected feature list from experiment directory"""
    print("\n" + "="*60)
    print("Reading selected features...")
    print("="*60)
    
    selected_features = []
    
    # Try to read from selected_features.csv
    feat_file = os.path.join(experiment_dir, "feature_selection", "selected_features.csv")
    if os.path.exists(feat_file):
        try:
            feat_df = pd.read_csv(feat_file)
            if 'feature_name' in feat_df.columns:
                selected_features = feat_df['feature_name'].tolist()
                print(f"Read {len(selected_features)} features from {feat_file}")
            elif 'Selected numerical feature list' in feat_df.columns:
                selected_features = feat_df['Selected numerical feature list'].tolist()
                print(f"Read {len(selected_features)} features from {feat_file}")
        except Exception as e:
            print(f"Failed to read feature file: {str(e)}")
    
    # Try to read from text file
    if not selected_features:
        txt_file = os.path.join(experiment_dir, "feature_selection", "selected_features.txt")
        if os.path.exists(txt_file):
            try:
                with open(txt_file, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                for line in lines:
                    if '. ' in line:
                        feat = line.split('. ')[1].strip()
                        if feat and feat != 'NO':
                            selected_features.append(feat)
                print(f"Read {len(selected_features)} features from {txt_file}")
            except Exception as e:
                print(f"Failed to read feature file: {str(e)}")
    
    if not selected_features:
        print("Feature selection result not found, using all numerical features")
    
    return selected_features

# =======================  CatBoost model stability test  =======================
def catboost_stability_test(X, y, catboost_params, n_runs=150):
    """
    CatBoost model stability test
    Parameters:
        X: Feature matrix
        y: Target variable
        catboost_params: CatBoost optimal parameters
        n_runs: Number of repeated runs (default 150)
    """
    
    print("\n" + "="*80)
    print(f"CatBoost Model Stability Test ({n_runs} repeated validations)")
    print("="*80)
    print(f"Model parameters: iterations={catboost_params.get('iterations', 100)}, "
          f"depth={catboost_params.get('depth', 3)}, "
          f"learning_rate={catboost_params.get('learning_rate', 0.05)}, "
          f"subsample={catboost_params.get('subsample', 0.8)}, "
          f"l2_leaf_reg={catboost_params.get('l2_leaf_reg', 3)}")
    print(f"Feature count: {X.shape[1]}")
    print(f"Sample count: {X.shape[0]}")
    print("="*80)
    
    # Store results for each run
    records = []
    base_seed = 42  # Base seed
    
    start_time = time.time()
    
    for run in range(1, n_runs + 1):
        # Use different random seed for each run
        current_seed = base_seed + run * 7
        
        # 8:2 data split (training set:test set)
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=current_seed, shuffle=True
        )
        
        # 5-fold cross-validation (on training set)
        kf = KFold(n_splits=5, shuffle=True, random_state=current_seed)
        cv_r2_scores = []
        cv_rmse_scores = []
        cv_accuracy_rates = []
        
        for train_idx, val_idx in kf.split(X_train):
            # Handle indices
            if isinstance(X_train, pd.DataFrame):
                X_tr = X_train.iloc[train_idx]
                X_val = X_train.iloc[val_idx]
            else:
                X_tr = X_train[train_idx]
                X_val = X_train[val_idx]
            
            y_tr = y_train[train_idx]
            y_val = y_train[val_idx]
            
            # Train CatBoost model
            model = CatBoostRegressor(
                iterations=catboost_params.get('iterations', 100),
                depth=catboost_params.get('depth', 3),
                learning_rate=catboost_params.get('learning_rate', 0.05),
                subsample=catboost_params.get('subsample', 0.8),
                l2_leaf_reg=catboost_params.get('l2_leaf_reg', 3),
                random_seed=current_seed,
                verbose=False
            )
            model.fit(X_tr, y_tr)
            
            # Validation set prediction
            y_val_pred = model.predict(X_val)
            y_val_pred = np.maximum(y_val_pred, 5)  # Limit minimum value
            
            # Calculate metrics
            cv_r2 = r2_score(y_val, y_val_pred)
            cv_rmse = np.sqrt(mean_squared_error(y_val, y_val_pred))
            
            # Accuracy rate (relative error ≤ 15%)
            relative_error = np.abs(y_val_pred - y_val) / (y_val + 1e-6)
            accuracy_rate = (relative_error <= 0.15).sum() / len(y_val)
            
            cv_r2_scores.append(cv_r2)
            cv_rmse_scores.append(cv_rmse)
            cv_accuracy_rates.append(accuracy_rate)
        
        # Train on full training set for test set evaluation
        final_model = CatBoostRegressor(
            iterations=catboost_params.get('iterations', 100),
            depth=catboost_params.get('depth', 3),
            learning_rate=catboost_params.get('learning_rate', 0.05),
            subsample=catboost_params.get('subsample', 0.8),
            l2_leaf_reg=catboost_params.get('l2_leaf_reg', 3),
            random_seed=current_seed,
            verbose=False
        )
        final_model.fit(X_train, y_train)
        
        # Test set prediction
        y_test_pred = final_model.predict(X_test)
        y_test_pred = np.maximum(y_test_pred, 5)
        
        # Test set metrics
        test_r2 = r2_score(y_test, y_test_pred)
        test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
        test_r, test_r_pvalue = pearsonr(y_test, y_test_pred)
        
        # Test set accuracy rate
        test_relative_error = np.abs(y_test_pred - y_test) / (y_test + 1e-6)
        test_accuracy_rate = (test_relative_error <= 0.15).sum() / len(y_test)
        test_avg_accuracy = 1 - np.mean(test_relative_error)
        
        # Training set metrics (for detecting overfitting)
        y_train_pred = final_model.predict(X_train)
        y_train_pred = np.maximum(y_train_pred, 5)
        train_r2 = r2_score(y_train, y_train_pred)
        train_rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))
        
        # Check for overfitting
        r2_diff = abs(train_r2 - test_r2)
        rmse_ratio = test_rmse / train_rmse if train_rmse > 0 else 1
        is_overfitted = r2_diff > 0.15 or rmse_ratio > 1.5
        
        # Record results
        records.append({
            'Run': run,
            'Seed': current_seed,
            'Train_Size': len(X_train),
            'Test_Size': len(X_test),
            'Train_R2': train_r2,
            'Train_RMSE': train_rmse,
            'CV_R2_Mean': np.mean(cv_r2_scores),
            'CV_R2_Std': np.std(cv_r2_scores),
            'CV_RMSE_Mean': np.mean(cv_rmse_scores),
            'CV_RMSE_Std': np.std(cv_rmse_scores),
            'CV_Accuracy_Mean': np.mean(cv_accuracy_rates),
            'CV_Accuracy_Std': np.std(cv_accuracy_rates),
            'Test_R': test_r,
            'Test_R2': test_r2,
            'Test_RMSE': test_rmse,
            'Test_Avg_Accuracy': test_avg_accuracy,
            'Test_Accuracy_Rate': test_accuracy_rate,
            'Is_Overfitted': is_overfitted
        })
        
        # Print progress
        if run % 10 == 0:
            elapsed = time.time() - start_time
            print(f"✓ Completed {run}/{n_runs} stability tests (time: {elapsed:.1f}s)")
    
    # Convert to DataFrame
    results_df = pd.DataFrame(records)
    
    return results_df

# =======================  Statistical analysis  =======================
def analyze_stability(results_df):
    """Analyze stability results"""
    
    print("\n" + "="*80)
    print("Statistical Summary Results")
    print("="*80)
    
    summary_stats = []
    
    # Test R² statistics
    r2_mean = results_df['Test_R2'].mean()
    r2_std = results_df['Test_R2'].std()
    r2_cv = (r2_std / abs(r2_mean)) * 100
    
    summary_stats.append({
        'Metric': 'Test_R2',
        'Mean': r2_mean,
        'Std': r2_std,
        'CV(%)': r2_cv,
        'Min': results_df['Test_R2'].min(),
        'Max': results_df['Test_R2'].max(),
        'Median': results_df['Test_R2'].median(),
        'Qualified Rate(≥0.7)': (results_df['Test_R2'] >= 0.7).sum() / len(results_df) * 100
    })
    
    # Test RMSE statistics
    rmse_mean = results_df['Test_RMSE'].mean()
    rmse_std = results_df['Test_RMSE'].std()
    rmse_cv = (rmse_std / rmse_mean) * 100 if rmse_mean > 0 else 0
    
    summary_stats.append({
        'Metric': 'Test_RMSE',
        'Mean': rmse_mean,
        'Std': rmse_std,
        'CV(%)': rmse_cv,
        'Min': results_df['Test_RMSE'].min(),
        'Max': results_df['Test_RMSE'].max(),
        'Median': results_df['Test_RMSE'].median(),
        'Qualified Rate(≤50)': (results_df['Test_RMSE'] <= 50).sum() / len(results_df) * 100
    })
    
    # Test accuracy rate statistics
    acc_mean = results_df['Test_Accuracy_Rate'].mean()
    acc_std = results_df['Test_Accuracy_Rate'].std()
    acc_cv = (acc_std / acc_mean) * 100 if acc_mean > 0 else 0
    
    summary_stats.append({
        'Metric': 'Test_Accuracy_Rate',
        'Mean': acc_mean,
        'Std': acc_std,
        'CV(%)': acc_cv,
        'Min': results_df['Test_Accuracy_Rate'].min(),
        'Max': results_df['Test_Accuracy_Rate'].max(),
        'Median': results_df['Test_Accuracy_Rate'].median(),
        'Qualified Rate(≥85%)': (results_df['Test_Accuracy_Rate'] >= 0.85).sum() / len(results_df) * 100
    })
    
    # Cross-validation R² statistics
    cv_r2_mean = results_df['CV_R2_Mean'].mean()
    cv_r2_std = results_df['CV_R2_Mean'].std()
    cv_r2_cv = (cv_r2_std / abs(cv_r2_mean)) * 100
    
    summary_stats.append({
        'Metric': 'CV_R2',
        'Mean': cv_r2_mean,
        'Std': cv_r2_std,
        'CV(%)': cv_r2_cv,
        'Min': results_df['CV_R2_Mean'].min(),
        'Max': results_df['CV_R2_Mean'].max(),
        'Median': results_df['CV_R2_Mean'].median(),
        'Qualified Rate(≥0.7)': (results_df['CV_R2_Mean'] >= 0.7).sum() / len(results_df) * 100
    })
    
    summary_df = pd.DataFrame(summary_stats)
    
    # Print summary results
    print("\nStability Test Core Metrics:")
    print(summary_df.to_string(index=False))
    
    # Calculate 95% confidence intervals
    print("\n" + "="*80)
    print("95% Confidence Intervals")
    print("="*80)
    
    confidence_intervals = []
    for metric in ['Test_R2', 'Test_RMSE', 'Test_Accuracy_Rate']:
        mean_val = results_df[metric].mean()
        std_val = results_df[metric].std()
        ci_lower = mean_val - 1.96 * std_val
        ci_upper = mean_val + 1.96 * std_val
        
        confidence_intervals.append({
            'Metric': metric,
            'Mean': mean_val,
            'Std': std_val,
            '95% CI Lower': ci_lower,
            '95% CI Upper': ci_upper
        })
        
        print(f"{metric}: {mean_val:.4f} ± 1.96*{std_val:.4f} = [{ci_lower:.4f}, {ci_upper:.4f}]")
    
    ci_df = pd.DataFrame(confidence_intervals)
    
    # Overfitting statistics
    overfit_count = results_df['Is_Overfitted'].sum()
    overfit_rate = overfit_count / len(results_df) * 100
    
    print("\n" + "="*80)
    print("Overfitting Detection")
    print("="*80)
    print(f"Overfitting detected count: {overfit_count}/{len(results_df)} ({overfit_rate:.1f}%)")
    
    if overfit_rate < 10:
        print("Conclusion: Model has good generalization ability, low overfitting risk")
    elif overfit_rate < 30:
        print("Conclusion: Model has some overfitting risk, need attention")
    else:
        print("Conclusion: Model has high overfitting risk, need further regularization or more data")
    
    return summary_df, ci_df

# =======================  Save results  =======================
def save_results(results_df, summary_df, ci_df, catboost_params, selected_features):
    """Save all results to Excel file"""
    
    output_file = f"CatBoost_Stability_Results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    
    try:
        with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
            results_df.to_excel(writer, sheet_name='All_Runs_Results', index=False)
            summary_df.to_excel(writer, sheet_name='Summary_Statistics', index=False)
            ci_df.to_excel(writer, sheet_name='Confidence_Intervals', index=False)
            
            # Add model configuration information
            config_data = [
                ['Model_Name', 'CatBoostRegressor'],
                ['iterations', catboost_params.get('iterations', 100)],
                ['depth', catboost_params.get('depth', 3)],
                ['learning_rate', catboost_params.get('learning_rate', 0.05)],
                ['subsample', catboost_params.get('subsample', 0.8)],
                ['l2_leaf_reg', catboost_params.get('l2_leaf_reg', 3)],
                ['Number_of_Runs', 150],
                ['Test_Set_Ratio', '20%'],
                ['Cross_Validation_Folds', 5],
                ['Feature_Count', len(selected_features)]
            ]
            config_df = pd.DataFrame(config_data, columns=['Config_Item', 'Value'])
            config_df.to_excel(writer, sheet_name='Model_Config', index=False)
            
            # Add feature list
            if selected_features:
                features_df = pd.DataFrame({'Feature_Name': selected_features})
                features_df.to_excel(writer, sheet_name='Selected_Features', index=False)
        
        print(f"\n✓ Results saved to: {output_file}")
        return output_file
    except Exception as e:
        print(f"Failed to save Excel: {str(e)}, saving as CSV format instead")
        results_df.to_csv("CatBoost_All_Runs.csv", index=False, encoding='utf-8-sig')
        summary_df.to_csv("CatBoost_Summary.csv", index=False, encoding='utf-8-sig')
        ci_df.to_csv("CatBoost_CI.csv", index=False, encoding='utf-8-sig')
        return "CSV files saved"

# =======================  Main function  =======================
def main():
    print("="*80)
    print("CatBoost Model Stability Evaluation Program")
    print(f"Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*80)
    
    # Check if experiment directory exists
    if not os.path.exists(EXPERIMENT_DIR):
        print(f"\nError: Experiment directory does not exist: {EXPERIMENT_DIR}")
        print("Please check the path")
        return None, None, None
    
    # 1. Data loading and cleaning
    print("\n[Step 1] Data loading and cleaning...")
    dataset, target_col, numeric_cols = load_data()
    
    # 2. Read selected features
    print("\n[Step 2] Reading selected features...")
    selected_features = get_selected_features(EXPERIMENT_DIR)
    
    # 3. Feature engineering (using selected features)
    print("\n[Step 3] Feature engineering...")
    if selected_features:
        df_eng = feature_engineering(dataset, target_col, selected_features)
        # Ensure features exist
        available_features = [f for f in selected_features if f in df_eng.columns]
        print(f"Available feature count: {len(available_features)}/{len(selected_features)}")
        if len(available_features) < len(selected_features):
            missing = set(selected_features) - set(available_features)
            print(f"Warning: Features not found: {missing}")
        selected_features = available_features
    else:
        df_eng = feature_engineering(dataset, target_col)
        selected_features = [col for col in df_eng.columns if col != target_col]
    
    # Prepare feature matrix and target variable
    X = df_eng[selected_features].copy()
    y = df_eng[target_col].values
    
    print(f"Feature count: {X.shape[1]}")
    print(f"Sample count: {X.shape[0]}")
    
    # 4. Read CatBoost optimal parameters
    print("\n[Step 4] Reading CatBoost optimal parameters...")
    catboost_params = get_optimal_catboost_params(EXPERIMENT_DIR)
    
    # 5. CatBoost stability test
    print("\n[Step 5] Starting stability test...")
    results_df = catboost_stability_test(X, y, catboost_params, n_runs=150)
    
    # 6. Statistical analysis
    print("\n[Step 6] Statistical analysis...")
    summary_df, ci_df = analyze_stability(results_df)
    
    # 7. Save results
    print("\n[Step 7] Saving results...")
    output_file = save_results(results_df, summary_df, ci_df, catboost_params, selected_features)
    
    # 8. Final report
    print("\n" + "="*80)
    print("Final Stability Evaluation Report")
    print("="*80)
    print(f"\nCatBoost model performance based on 150 repeated validations:")
    print(f"  - Test R²: {results_df['Test_R2'].mean():.4f} ± {results_df['Test_R2'].std():.4f}")
    print(f"  - Test RMSE: {results_df['Test_RMSE'].mean():.2f} ± {results_df['Test_RMSE'].std():.2f}")
    print(f"  - Test Accuracy Rate: {results_df['Test_Accuracy_Rate'].mean():.1%} ± {results_df['Test_Accuracy_Rate'].std():.1%}")
    
    print(f"\nModel qualification status:")
    print(f"  - Proportion with R² ≥ 0.7: {results_df['Test_R2'].ge(0.7).mean():.1%}")
    print(f"  - Proportion with Accuracy Rate ≥ 85%: {results_df['Test_Accuracy_Rate'].ge(0.85).mean():.1%}")
    
    print("\n" + "="*80)
    print(f"Evaluation complete time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Result file: {output_file}")
    print("="*80)
    
    return results_df, summary_df, ci_df

if __name__ == "__main__":
    results_df, summary_df, ci_df = main()