# -*- coding: utf-8 -*-
"""
Created on Thu Apr 30 17:27:46 2026

@author: ma'wei'bin
"""# -*- coding: utf-8 -*-
"""
MLP Model Stability Test Program (Based on GA-T5 Main Code Pipeline)
Function: Perform repeated stability validation on features selected by GA-T5 and MLP model
Read optimal parameters from specified experiment directory
"""

import numpy as np
import pandas as pd
import os
import sys
import warnings
from datetime import datetime
from sklearn.model_selection import train_test_split, KFold
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from scipy.stats import pearsonr
import time
import matplotlib.pyplot as plt
import seaborn as sns
import ast
import joblib

warnings.filterwarnings('ignore')

# ==================== Set font for plots ====================
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# ==================== Please set your file paths here ====================
# Training data path
TRAIN_DATA_PATH = r"Your augmented data"
# GA experiment directory path (contains optimal model parameters and selected features)
GA_EXPERIMENT_DIR = r"Your logs of model based on augmented data"
# ========================================================================

# ======================= Data loading function (consistent with GA-T5 main code) =======================
def load_data():
    if not os.path.exists(TRAIN_DATA_PATH):
        raise FileNotFoundError(f"Training data file not found: {TRAIN_DATA_PATH}")
    
    df = pd.read_excel(TRAIN_DATA_PATH)
    target = 'T5%(℃)'
    if 'NO' in df.columns:
        df = df.drop(columns=['NO'])
    X = df.drop(columns=[target])
    y = df[target]
    feature_names = X.columns.tolist()
    return X.values, y.values, feature_names

# ======================= Load GA-selected features and MLP optimal parameters =======================
def load_ga_results(exp_dir):
    # Find final iteration directory
    final_iter_dir = os.path.join(exp_dir, "final_iteration")
    if not os.path.exists(final_iter_dir):
        iter_3_dir = os.path.join(exp_dir, "iter_3")
        if os.path.exists(iter_3_dir):
            final_iter_dir = iter_3_dir
        else:
            return None, None
    
    # 1. Load selected features
    selected_features = []
    
    selected_file_csv = os.path.join(final_iter_dir, "selected_features.csv")
    if os.path.exists(selected_file_csv):
        try:
            feat_df = pd.read_csv(selected_file_csv, encoding='utf-8-sig')
            if 'feature_name' in feat_df.columns:
                selected_features = feat_df['feature_name'].tolist()
            elif 'Selected numerical feature list' in feat_df.columns:
                selected_features = feat_df['Selected numerical feature list'].tolist()
        except:
            pass
    
    if not selected_features:
        selected_file_txt = os.path.join(final_iter_dir, "selected_features.txt")
        if os.path.exists(selected_file_txt):
            try:
                with open(selected_file_txt, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                for line in lines:
                    if line.strip() and not line.startswith("Selected features") and not line.startswith("GA feature selection"):
                        if '. ' in line:
                            parts = line.split('.')
                            if len(parts) >= 2:
                                feature = parts[1].strip()
                                if feature and feature != 'NO':
                                    selected_features.append(feature)
            except:
                pass
    
    if not selected_features:
        feat_pkl = os.path.join(exp_dir, "phrr_train_features.pkl")
        if os.path.exists(feat_pkl):
            try:
                selected_features = joblib.load(feat_pkl)
            except:
                pass
    
    # 2. Load MLP optimal parameters
    mlp_params = None
    
    test_results_file = os.path.join(final_iter_dir, "test_results.csv")
    if os.path.exists(test_results_file):
        try:
            test_results = pd.read_csv(test_results_file, encoding='utf-8-sig')
            mlp_row = test_results[test_results['Model'] == 'MLP']
            if not mlp_row.empty:
                best_params_str = mlp_row.iloc[0]['Best_Params']
                try:
                    mlp_params = ast.literal_eval(best_params_str)
                except:
                    import re
                    hidden_match = re.search(r"'hidden_layer_sizes':\s*\((\d+),?\)?", best_params_str)
                    activation_match = re.search(r"'activation':\s*'(\w+)'", best_params_str)
                    alpha_match = re.search(r"'alpha':\s*([\d.e-]+)", best_params_str)
                    hidden_sizes = (int(hidden_match.group(1)),) if hidden_match else (100,)
                    activation = activation_match.group(1) if activation_match else 'relu'
                    alpha = float(alpha_match.group(1)) if alpha_match else 0.001
                    mlp_params = {'hidden_layer_sizes': hidden_sizes, 'activation': activation, 'alpha': alpha}
        except:
            pass
    
    if mlp_params is None:
        log_file = os.path.join(final_iter_dir, "model_optimization_log.csv")
        if os.path.exists(log_file):
            try:
                log_df = pd.read_csv(log_file, encoding='utf-8-sig')
                mlp_log = log_df[log_df['Model Name'] == 'MLP']
                if not mlp_log.empty and 'Best Params' in mlp_log.columns:
                    params_str = mlp_log.iloc[0]['Best Params']
                    mlp_params = ast.literal_eval(params_str)
            except:
                pass
    
    if mlp_params is None:
        mlp_params = {'hidden_layer_sizes': (100,), 'activation': 'relu', 'alpha': 0.001}
    
    return selected_features, mlp_params

# ======================= MLP model stability test =======================
def mlp_stability_test(X, y, mlp_params, n_runs=50, random_seed=56):
    records = []
    base_seed = random_seed
    start_time = time.time()
    failed_runs = 0
    
    for run in range(1, n_runs + 1):
        current_seed = base_seed + run * 7
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=current_seed, shuffle=True)
        
        kf = KFold(n_splits=5, shuffle=True, random_state=current_seed)
        cv_r2_scores = []
        cv_rmse_scores = []
        cv_mae_scores = []
        cv_accuracy_rates = []
        cv_failed = False
        
        for train_idx, val_idx in kf.split(X_train):
            X_tr = X_train[train_idx]
            X_val = X_train[val_idx]
            y_tr = y_train[train_idx]
            y_val = y_train[val_idx]
            
            try:
                model = MLPRegressor(
                    hidden_layer_sizes=mlp_params.get('hidden_layer_sizes', (100,)),
                    activation=mlp_params.get('activation', 'relu'),
                    alpha=mlp_params.get('alpha', 0.001),
                    max_iter=2000,
                    random_state=current_seed,
                    verbose=False
                )
                model.fit(X_tr, y_tr)
                y_val_pred = model.predict(X_val)
                y_val_pred = np.maximum(y_val_pred, 0)
                
                cv_r2 = r2_score(y_val, y_val_pred)
                cv_rmse = np.sqrt(mean_squared_error(y_val, y_val_pred))
                cv_mae = mean_absolute_error(y_val, y_val_pred)
                relative_error = np.abs(y_val_pred - y_val) / (y_val + 1e-6)
                accuracy_rate = (relative_error <= 0.15).sum() / len(y_val)
                
                cv_r2_scores.append(cv_r2)
                cv_rmse_scores.append(cv_rmse)
                cv_mae_scores.append(cv_mae)
                cv_accuracy_rates.append(accuracy_rate)
            except:
                cv_failed = True
                break
        
        if cv_failed or len(cv_r2_scores) == 0:
            failed_runs += 1
            continue
        
        try:
            final_model = MLPRegressor(
                hidden_layer_sizes=mlp_params.get('hidden_layer_sizes', (100,)),
                activation=mlp_params.get('activation', 'relu'),
                alpha=mlp_params.get('alpha', 0.001),
                max_iter=2000,
                random_state=current_seed,
                verbose=False
            )
            final_model.fit(X_train, y_train)
            y_test_pred = final_model.predict(X_test)
            y_test_pred = np.maximum(y_test_pred, 0)
            
            test_r2 = r2_score(y_test, y_test_pred)
            test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
            test_mae = mean_absolute_error(y_test, y_test_pred)
            test_r, _ = pearsonr(y_test, y_test_pred)
            test_relative_error = np.abs(y_test_pred - y_test) / (y_test + 1e-6)
            test_accuracy_rate = (test_relative_error <= 0.15).sum() / len(y_test)
            test_avg_accuracy = 1 - np.mean(test_relative_error)
            
            y_train_pred = final_model.predict(X_train)
            y_train_pred = np.maximum(y_train_pred, 0)
            train_r2 = r2_score(y_train, y_train_pred)
            train_rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))
            r2_diff = abs(train_r2 - test_r2)
            rmse_ratio = test_rmse / train_rmse if train_rmse > 0 else 1
            is_overfitted = r2_diff > 0.15 or rmse_ratio > 1.5
            
            records.append({
                'Run': run,
                'Seed': current_seed,
                'Train_Size': len(X_train),
                'Test_Size': len(X_test),
                'Train_R2': train_r2,
                'Train_RMSE': train_rmse,
                'CV_R2_Mean': np.mean(cv_r2_scores) if cv_r2_scores else 0,
                'CV_R2_Std': np.std(cv_r2_scores) if cv_r2_scores else 0,
                'CV_RMSE_Mean': np.mean(cv_rmse_scores) if cv_rmse_scores else 0,
                'CV_RMSE_Std': np.std(cv_rmse_scores) if cv_rmse_scores else 0,
                'CV_MAE_Mean': np.mean(cv_mae_scores) if cv_mae_scores else 0,
                'CV_MAE_Std': np.std(cv_mae_scores) if cv_mae_scores else 0,
                'CV_Accuracy_Mean': np.mean(cv_accuracy_rates) if cv_accuracy_rates else 0,
                'CV_Accuracy_Std': np.std(cv_accuracy_rates) if cv_accuracy_rates else 0,
                'Test_R': test_r,
                'Test_R2': test_r2,
                'Test_RMSE': test_rmse,
                'Test_MAE': test_mae,
                'Test_Avg_Accuracy': test_avg_accuracy,
                'Test_Accuracy_Rate': test_accuracy_rate,
                'Is_Overfitted': is_overfitted
            })
        except:
            failed_runs += 1
            continue
    
    results_df = pd.DataFrame(records)
    results_df.to_csv(f"MLP_Stability_{n_runs}runs.csv", index=False, encoding='utf-8-sig')
    return results_df

# ======================= Statistical analysis =======================
def analyze_stability(results_df):
    if len(results_df) == 0:
        return None, None
    
    r2_mean = results_df['Test_R2'].mean()
    r2_std = results_df['Test_R2'].std()
    r2_cv = (r2_std / abs(r2_mean)) * 100 if abs(r2_mean) > 0 else 0
    
    rmse_mean = results_df['Test_RMSE'].mean()
    rmse_std = results_df['Test_RMSE'].std()
    rmse_cv = (rmse_std / rmse_mean) * 100 if rmse_mean > 0 else 0
    
    mae_mean = results_df['Test_MAE'].mean()
    mae_std = results_df['Test_MAE'].std()
    mae_cv = (mae_std / mae_mean) * 100 if mae_mean > 0 else 0
    
    acc_mean = results_df['Test_Accuracy_Rate'].mean()
    acc_std = results_df['Test_Accuracy_Rate'].std()
    acc_cv = (acc_std / acc_mean) * 100 if acc_mean > 0 else 0
    
    cv_r2_mean = results_df['CV_R2_Mean'].mean()
    cv_r2_std = results_df['CV_R2_Mean'].std()
    cv_r2_cv = (cv_r2_std / abs(cv_r2_mean)) * 100 if abs(cv_r2_mean) > 0 else 0
    
    summary_stats = [
        {'Metric': 'Test_R2', 'Mean': f"{r2_mean:.4f}", 'Std': f"{r2_std:.4f}", 'CV(%)': f"{r2_cv:.2f}",
         'Min': f"{results_df['Test_R2'].min():.4f}", 'Max': f"{results_df['Test_R2'].max():.4f}",
         'Median': f"{results_df['Test_R2'].median():.4f}",
         'Qualified Rate(≥0.7)': f"{(results_df['Test_R2'] >= 0.7).sum() / len(results_df) * 100:.1f}%"},
        {'Metric': 'Test_RMSE', 'Mean': f"{rmse_mean:.2f}", 'Std': f"{rmse_std:.2f}", 'CV(%)': f"{rmse_cv:.2f}",
         'Min': f"{results_df['Test_RMSE'].min():.2f}", 'Max': f"{results_df['Test_RMSE'].max():.2f}",
         'Median': f"{results_df['Test_RMSE'].median():.2f}",
         'Qualified Rate(≤50)': f"{(results_df['Test_RMSE'] <= 50).sum() / len(results_df) * 100:.1f}%"},
        {'Metric': 'Test_MAE', 'Mean': f"{mae_mean:.2f}", 'Std': f"{mae_std:.2f}", 'CV(%)': f"{mae_cv:.2f}",
         'Min': f"{results_df['Test_MAE'].min():.2f}", 'Max': f"{results_df['Test_MAE'].max():.2f}",
         'Median': f"{results_df['Test_MAE'].median():.2f}",
         'Qualified Rate(≤30)': f"{(results_df['Test_MAE'] <= 30).sum() / len(results_df) * 100:.1f}%"},
        {'Metric': 'Test_Accuracy_Rate', 'Mean': f"{acc_mean:.3f}", 'Std': f"{acc_std:.3f}", 'CV(%)': f"{acc_cv:.2f}",
         'Min': f"{results_df['Test_Accuracy_Rate'].min():.3f}", 'Max': f"{results_df['Test_Accuracy_Rate'].max():.3f}",
         'Median': f"{results_df['Test_Accuracy_Rate'].median():.3f}",
         'Qualified Rate(≥85%)': f"{(results_df['Test_Accuracy_Rate'] >= 0.85).sum() / len(results_df) * 100:.1f}%"},
        {'Metric': 'CV_R2', 'Mean': f"{cv_r2_mean:.4f}", 'Std': f"{cv_r2_std:.4f}", 'CV(%)': f"{cv_r2_cv:.2f}",
         'Min': f"{results_df['CV_R2_Mean'].min():.4f}", 'Max': f"{results_df['CV_R2_Mean'].max():.4f}",
         'Median': f"{results_df['CV_R2_Mean'].median():.4f}",
         'Qualified Rate(≥0.7)': f"{(results_df['CV_R2_Mean'] >= 0.7).sum() / len(results_df) * 100:.1f}%"}
    ]
    summary_df = pd.DataFrame(summary_stats)
    
    confidence_intervals = []
    for metric in ['Test_R2', 'Test_RMSE', 'Test_MAE', 'Test_Accuracy_Rate']:
        mean_val = results_df[metric].mean()
        std_val = results_df[metric].std()
        ci_lower = mean_val - 1.96 * std_val
        ci_upper = mean_val + 1.96 * std_val
        confidence_intervals.append({
            'Metric': metric, 'Mean': f"{mean_val:.4f}", 'Std': f"{std_val:.4f}",
            '95% CI Lower': f"{ci_lower:.4f}", '95% CI Upper': f"{ci_upper:.4f}"
        })
    ci_df = pd.DataFrame(confidence_intervals)
    
    overfit_rate = (results_df['Is_Overfitted'].sum() / len(results_df)) * 100
    
    return summary_df, ci_df

# ======================= Visualization analysis =======================
def plot_stability_analysis(results_df, output_dir="MLP_Stability_Results"):
    if len(results_df) == 0:
        return
    
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    
    axes[0, 0].hist(results_df['Test_R2'], bins=30, edgecolor='black', alpha=0.7, color='steelblue')
    axes[0, 0].axvline(results_df['Test_R2'].mean(), color='red', linestyle='--')
    axes[0, 0].set_xlabel('Test R²')
    axes[0, 0].set_ylabel('Frequency')
    axes[0, 0].set_title('MLP Test R² Distribution')
    axes[0, 0].grid(True, alpha=0.3)
    
    axes[0, 1].plot(results_df['Run'], results_df['Test_R2'], 'o-', alpha=0.5, markersize=3)
    axes[0, 1].axhline(results_df['Test_R2'].mean(), color='red', linestyle='--')
    axes[0, 1].fill_between(results_df['Run'], 
                           results_df['Test_R2'].mean() - results_df['Test_R2'].std(),
                           results_df['Test_R2'].mean() + results_df['Test_R2'].std(),
                           alpha=0.2, color='gray')
    axes[0, 1].set_xlabel('Run Number')
    axes[0, 1].set_ylabel('Test R²')
    axes[0, 1].set_title('MLP Test R² Stability Trend')
    axes[0, 1].grid(True, alpha=0.3)
    
    axes[0, 2].hist(results_df['Test_RMSE'], bins=30, edgecolor='black', alpha=0.7, color='green')
    axes[0, 2].axvline(results_df['Test_RMSE'].mean(), color='red', linestyle='--')
    axes[0, 2].set_xlabel('Test RMSE')
    axes[0, 2].set_ylabel('Frequency')
    axes[0, 2].set_title('MLP Test RMSE Distribution')
    axes[0, 2].grid(True, alpha=0.3)
    
    axes[1, 0].hist(results_df['Test_Accuracy_Rate'], bins=30, edgecolor='black', alpha=0.7, color='orange')
    axes[1, 0].axvline(results_df['Test_Accuracy_Rate'].mean(), color='red', linestyle='--')
    axes[1, 0].set_xlabel('Accuracy Rate')
    axes[1, 0].set_ylabel('Frequency')
    axes[1, 0].set_title('MLP Accuracy Rate Distribution')
    axes[1, 0].grid(True, alpha=0.3)
    
    bp_data = [results_df['Test_R2'], results_df['CV_R2_Mean']]
    axes[1, 1].boxplot(bp_data, labels=['Test R²', 'CV R²'])
    axes[1, 1].set_ylabel('R² Value')
    axes[1, 1].set_title('MLP Test vs Cross-Validation R² Comparison')
    axes[1, 1].grid(True, alpha=0.3)
    
    overfit_counts = results_df['Is_Overfitted'].value_counts()
    axes[1, 2].pie([overfit_counts.get(False, 0), overfit_counts.get(True, 0)], 
                   labels=['Normal', 'Overfitted'], autopct='%1.1f%%',
                   colors=['lightgreen', 'salmon'])
    axes[1, 2].set_title('MLP Overfitting Detection Results')
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'mlp_stability_analysis_plots.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    plt.figure(figsize=(10, 8))
    corr_metrics = ['Test_R2', 'Test_RMSE', 'Test_MAE', 'Test_Accuracy_Rate', 'CV_R2_Mean']
    corr_matrix = results_df[corr_metrics].corr()
    sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', center=0, fmt='.3f', square=True)
    plt.title('MLP Evaluation Metrics Correlation Heatmap')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'mlp_metrics_correlation.png'), dpi=300, bbox_inches='tight')
    plt.close()

# ======================= Save results =======================
def save_results(results_df, summary_df, ci_df, mlp_params, feature_names, n_runs=50):
    if len(results_df) == 0:
        return None
    
    output_file = f"MLP_Stability_Results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    
    try:
        with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
            results_df.to_excel(writer, sheet_name='All_Runs_Results', index=False)
            summary_df.to_excel(writer, sheet_name='Summary_Statistics', index=False)
            ci_df.to_excel(writer, sheet_name='Confidence_Intervals', index=False)
            
            config_df = pd.DataFrame({
                'Config_Item': ['Model_Name', 'hidden_layer_sizes', 'activation', 'alpha', 
                               'max_iter', 'Number_of_Runs', 'Test_Set_Ratio', 'Cross_Validation_Folds'],
                'Value': ['MLPRegressor', 
                         str(mlp_params.get('hidden_layer_sizes', (100,))),
                         mlp_params.get('activation', 'relu'),
                         mlp_params.get('alpha', 0.001),
                         2000, len(results_df), '20%', 5]
            })
            config_df.to_excel(writer, sheet_name='Model_Config', index=False)
            
            if feature_names:
                feature_df = pd.DataFrame({
                    'Feature_Index': range(1, len(feature_names) + 1),
                    'Feature_Name': feature_names
                })
                feature_df.to_excel(writer, sheet_name='Used_Features', index=False)
            
            extra_stats = pd.DataFrame({
                'Statistic': ['Mean Test R²', 'Test R² Std', 'Mean Test RMSE', 'Test RMSE Std',
                             'Mean Test MAE', 'Test MAE Std', 'Mean Accuracy Rate', 'Accuracy Rate Std',
                             'Overfitting Rate(%)', 'Successful Runs', 'Success Rate(%)'],
                'Value': [
                    f"{results_df['Test_R2'].mean():.4f}", f"{results_df['Test_R2'].std():.4f}",
                    f"{results_df['Test_RMSE'].mean():.2f}", f"{results_df['Test_RMSE'].std():.2f}",
                    f"{results_df['Test_MAE'].mean():.2f}", f"{results_df['Test_MAE'].std():.2f}",
                    f"{results_df['Test_Accuracy_Rate'].mean():.2%}", f"{results_df['Test_Accuracy_Rate'].std():.2%}",
                    f"{(results_df['Is_Overfitted'].sum() / len(results_df) * 100):.1f}%",
                    len(results_df), f"{len(results_df)/n_runs*100:.1f}%"
                ]
            })
            extra_stats.to_excel(writer, sheet_name='Extra_Statistics', index=False)
        
        return output_file
    except:
        results_df.to_csv("MLP_All_Runs.csv", index=False, encoding='utf-8-sig')
        summary_df.to_csv("MLP_Summary.csv", index=False, encoding='utf-8-sig')
        ci_df.to_csv("MLP_CI.csv", index=False, encoding='utf-8-sig')
        return "CSV files saved"

# ======================= Main function =======================
def main(n_runs=50, random_seed=56):
    if not os.path.exists(GA_EXPERIMENT_DIR):
        return None, None, None
    
    X, y, all_feature_names = load_data()
    selected_features, mlp_params = load_ga_results(GA_EXPERIMENT_DIR)
    
    if selected_features is None or len(selected_features) == 0 or mlp_params is None:
        return None, None, None
    
    feature_indices = [all_feature_names.index(f) for f in selected_features if f in all_feature_names]
    X_selected = X[:, feature_indices]
    
    results_df = mlp_stability_test(X_selected, y, mlp_params, n_runs=n_runs, random_seed=random_seed)
    
    if len(results_df) == 0:
        return None, None, None
    
    summary_df, ci_df = analyze_stability(results_df)
    
    if summary_df is None:
        return None, None, None
    
    plot_stability_analysis(results_df)
    output_file = save_results(results_df, summary_df, ci_df, mlp_params, selected_features, n_runs)
    
    return results_df, summary_df, ci_df

if __name__ == "__main__":
    results_df, summary_df, ci_df = main(n_runs=50, random_seed=56)

