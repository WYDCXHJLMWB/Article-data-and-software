# -*- coding: utf-8 -*-
"""
GBR Model Stability Evaluation Program
Function: Evaluate the stability of the optimal GBR model (50 repeated training tests)
Read optimal model parameters from specified experiment directory
"""

import pandas as pd
import numpy as np
import os
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import KFold, train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import warnings
warnings.filterwarnings('ignore')

# =======================  Data loading and cleaning functions  =======================
def load_data():
    dataset = pd.read_excel("Your augmented data")
    target_col = 'PHRR(Kw/m2)'
    
    # Remove NO sequence column
    if 'NO' in dataset.columns:
        dataset = dataset.drop(columns=['NO'], errors='ignore')
    
    # Target value range filtering
    clean_mask = (dataset[target_col] > 10) & (dataset[target_col] <= 1000)
    dataset = dataset[clean_mask].copy().reset_index(drop=True)
    
    # Keep only numerical features
    numeric_cols = dataset.select_dtypes(include=[np.number]).columns.tolist()
    if target_col in numeric_cols:
        numeric_cols.remove(target_col)
    dataset = dataset[numeric_cols + [target_col]].copy()
    
    # IQR outlier filtering
    for col in numeric_cols:
        Q1 = dataset[col].quantile(0.25)
        Q3 = dataset[col].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        dataset = dataset[(dataset[col] >= lower_bound) & (dataset[col] <= upper_bound)].copy().reset_index(drop=True)
    
    # Fill missing values (median)
    dataset[numeric_cols] = dataset[numeric_cols].fillna(dataset[numeric_cols].median())
    
    return dataset, target_col, numeric_cols

# =======================  Feature engineering function  =======================
def feature_engineering(data, target_col=None, train_features=None):
    df = data.copy()
    
    # Feature enhancement based on numerical features
    additive_cols = ['PAPP', 'MPP', 'W', 'ZS', 'ADP']
    existing_additive = [col for col in additive_cols if col in df.columns]
    if existing_additive:
        df['total_ad'] = df[existing_additive].sum(axis=1)
        df['additive_ratio'] = df['total_ad'] / (df[existing_additive].max(axis=1) + 1e-6)
    else:
        df['total_ad'] = 0
        df['additive_ratio'] = 0
    
    # Numerical feature ratio calculation
    if 'PAPP' in df.columns and 'total_ad' in df.columns:
        df['PAPP_ratio'] = df['PAPP'] / (df['total_ad'] + 1e-6)
    else:
        df['PAPP_ratio'] = 0
    
    if 'MPP' in df.columns and 'total_ad' in df.columns:
        df['MPP_ratio'] = df['MPP'] / (df['total_ad'] + 1e-6)
    else:
        df['MPP_ratio'] = 0
    
    # Synergist numerical feature processing
    synergist_cols = ['W', 'ZS', 'ADP']
    existing_synergist = [col for col in synergist_cols if col in df.columns]
    if existing_synergist:
        df['synergist_total'] = df[existing_synergist].sum(axis=1)
        if 'W' in df.columns:
            df['W_ratio_in_synergist'] = df['W'] / (df['synergist_total'] + 1e-6)
        else:
            df['W_ratio_in_synergist'] = 0
    else:
        df['synergist_total'] = 0
        df['W_ratio_in_synergist'] = 0
    
    # Numerical feature interaction terms
    if all(col in df.columns for col in ['PAPP', 'MPP', 'W']):
        df['PAPP_MPP_W_interaction'] = df['PAPP'] * df['MPP'] * df['W']
    else:
        df['PAPP_MPP_W_interaction'] = 0
    
    # Numerical feature square terms
    if 'PAPP' in df.columns:
        df['PAPP_square'] = df['PAPP'] ** 2
    else:
        df['PAPP_square'] = 0
    
    if 'MPP' in df.columns:
        df['MPP_square'] = df['MPP'] ** 2
    else:
        df['MPP_square'] = 0
    
    # Add more feature interactions and transformations
    if all(col in df.columns for col in ['PAPP', 'MPP']):
        df['PAPP_MPP_ratio'] = df['PAPP'] / (df['MPP'] + 1e-6)
    
    if all(col in df.columns for col in ['PAPP', 'W']):
        df['PAPP_W_ratio'] = df['PAPP'] / (df['W'] + 1e-6)
    
    # Add polynomial features
    if 'PAPP' in df.columns:
        df['PAPP_sqrt'] = np.sqrt(df['PAPP'])
    
    if 'MPP' in df.columns:
        df['MPP_sqrt'] = np.sqrt(df['MPP'])
    
    if all(col in df.columns for col in ['ZS', 'total_ad']):
        df['ZS_ratio'] = df['ZS'] / (df['total_ad'] + 1e-6)
    
    if all(col in df.columns for col in ['W', 'total_ad']):
        df['W_ratio'] = df['W'] / (df['total_ad'] + 1e-6)
    if all(col in df.columns for col in ['ADP', 'total_ad']):
        df['ADP_ratio'] = df['ADP'] / (df['total_ad'] + 1e-6)
    
    # Keep only numerical features
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if target_col and target_col in numeric_cols:
        numeric_cols.remove(target_col)
    
    # Align with training set features
    if train_features is not None:
        train_features = [f for f in train_features if f != 'NO' and f in numeric_cols + ([target_col] if target_col else [])]
        for feat in train_features:
            if feat not in df.columns:
                df[feat] = 0
        if target_col and target_col in df.columns:
            df = df[train_features + [target_col]]
        else:
            df = df[train_features]
    
    return df

# =======================  Read GBR optimal parameters  =======================
def load_gbr_best_params(experiment_dir):
    """
    Read optimal parameters of GBR model from experiment directory
    Priority: read from optimization_log, then extract from saved model file
    """
    gbr_params = {
        'n_estimators': 100,
        'learning_rate': 0.05,
        'max_depth': 3,
        'subsample': 0.8,
        'min_samples_split': 5,
        'min_samples_leaf': 3,
        'random_state': None  # Will be set separately for each run
    }
    
    # Try to read from log file
    log_file = os.path.join(experiment_dir, "logs", "model_optimization_log.csv")
    if os.path.exists(log_file):
        try:
            log_df = pd.read_csv(log_file)
            gbr_log = log_df[log_df['Model Name'] == 'Gradient Boosting Regressor']
            if not gbr_log.empty and 'Best Params' in gbr_log.columns:
                params_str = gbr_log.iloc[0]['Best Params']
                import ast
                params_dict = ast.literal_eval(params_str)
                
                for key in gbr_params.keys():
                    if key in params_dict:
                        gbr_params[key] = params_dict[key]
        except:
            pass
    
    # Try to directly read model file to extract parameters (if exists)
    model_file = os.path.join(experiment_dir, "models", "gradient_boosting_regressor.pkl")
    if os.path.exists(model_file):
        try:
            import joblib
            model = joblib.load(model_file)
            gbr_params['n_estimators'] = model.n_estimators
            gbr_params['learning_rate'] = model.learning_rate
            gbr_params['max_depth'] = model.max_depth
            gbr_params['subsample'] = model.subsample
            gbr_params['min_samples_split'] = model.min_samples_split
            gbr_params['min_samples_leaf'] = model.min_samples_leaf
        except:
            pass
    
    return gbr_params

# =======================  Read selected features  =======================
def load_selected_features(experiment_dir):
    """Read selected feature list from experiment directory"""
    selected_features = []
    
    # Try to read from feature_selection directory
    feat_file = os.path.join(experiment_dir, "feature_selection", "selected_features.csv")
    if os.path.exists(feat_file):
        try:
            feat_df = pd.read_csv(feat_file)
            if 'feature_name' in feat_df.columns:
                selected_features = feat_df['feature_name'].tolist()
        except:
            pass
    
    # Try to read from text file
    if not selected_features:
        txt_file = os.path.join(experiment_dir, "feature_selection", "selected_features.txt")
        if os.path.exists(txt_file):
            try:
                with open(txt_file, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                for line in lines:
                    if '. ' in line:
                        feat = line.split('. ')[1].strip()
                        if feat and feat != 'NO':
                            selected_features.append(feat)
            except:
                pass
    
    return selected_features

# =======================  GBR model stability test  =======================
def gbr_stability_test(X, y, selected_features, gbr_params, n_runs=50):
    """
    GBR model stability test
    Parameters:
        X: Feature matrix
        y: Target variable
        selected_features: List of selected feature names
        gbr_params: GBR model parameters
        n_runs: Number of repeated runs (default 50)
    """
    
    # Store results for each run
    records = []
    base_seed = 42  # Base seed
    
    for run in range(1, n_runs + 1):
        # Use different random seed for each run
        current_seed = base_seed + run * 7
        
        # 8:2 data split (training set:test set)
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=current_seed, shuffle=True
        )
        
        # 5-fold cross-validation (on training set)
        kf = KFold(n_splits=5, shuffle=True, random_state=current_seed)
        cv_r2_scores = []
        cv_rmse_scores = []
        cv_accuracy_rates = []  # Accuracy rate (relative error ≤ 15%)
        
        for train_idx, val_idx in kf.split(X_train):
            # Handle indices (if X_train is DataFrame)
            if isinstance(X_train, pd.DataFrame):
                X_tr = X_train.iloc[train_idx]
                X_val = X_train.iloc[val_idx]
            else:
                X_tr = X_train[train_idx]
                X_val = X_train[val_idx]
            
            y_tr = y_train[train_idx]
            y_val = y_train[val_idx]
            
            # Train GBR model
            model = GradientBoostingRegressor(
                n_estimators=gbr_params.get('n_estimators', 100),
                learning_rate=gbr_params.get('learning_rate', 0.05),
                max_depth=gbr_params.get('max_depth', 3),
                subsample=gbr_params.get('subsample', 0.8),
                min_samples_split=gbr_params.get('min_samples_split', 5),
                min_samples_leaf=gbr_params.get('min_samples_leaf', 3),
                random_state=current_seed
            )
            model.fit(X_tr, y_tr)
            
            # Validation set prediction
            y_val_pred = model.predict(X_val)
            
            # Calculate metrics
            cv_r2 = r2_score(y_val, y_val_pred)
            cv_rmse = np.sqrt(mean_squared_error(y_val, y_val_pred))
            
            # Accuracy rate (relative error ≤ 15%)
            relative_error = np.abs(y_val_pred - y_val) / (y_val + 1e-6)
            accuracy_rate = (relative_error <= 0.15).sum() / len(y_val)
            
            cv_r2_scores.append(cv_r2)
            cv_rmse_scores.append(cv_rmse)
            cv_accuracy_rates.append(accuracy_rate)
        
        # Train on full training set for test set evaluation
        final_model = GradientBoostingRegressor(
            n_estimators=gbr_params.get('n_estimators', 100),
            learning_rate=gbr_params.get('learning_rate', 0.05),
            max_depth=gbr_params.get('max_depth', 3),
            subsample=gbr_params.get('subsample', 0.8),
            min_samples_split=gbr_params.get('min_samples_split', 5),
            min_samples_leaf=gbr_params.get('min_samples_leaf', 3),
            random_state=current_seed
        )
        final_model.fit(X_train, y_train)
        
        # Test set prediction
        y_test_pred = final_model.predict(X_test)
        
        # Test set metrics
        test_r2 = r2_score(y_test, y_test_pred)
        test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
        test_r = np.corrcoef(y_test, y_test_pred)[0, 1]
        
        # Test set accuracy rate
        test_relative_error = np.abs(y_test_pred - y_test) / (y_test + 1e-6)
        test_accuracy_rate = (test_relative_error <= 0.15).sum() / len(y_test)
        test_avg_accuracy = 1 - np.mean(test_relative_error)
        
        # Training set metrics (for detecting overfitting)
        y_train_pred = final_model.predict(X_train)
        train_r2 = r2_score(y_train, y_train_pred)
        train_rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))
        
        # Record results
        records.append({
            'Run': run,
            'Seed': current_seed,
            'Train_Size': len(X_train),
            'Test_Size': len(X_test),
            'Train_R2': train_r2,
            'Train_RMSE': train_rmse,
            'CV_R2_Mean': np.mean(cv_r2_scores),
            'CV_R2_Std': np.std(cv_r2_scores),
            'CV_RMSE_Mean': np.mean(cv_rmse_scores),
            'CV_RMSE_Std': np.std(cv_rmse_scores),
            'CV_Accuracy_Mean': np.mean(cv_accuracy_rates),
            'CV_Accuracy_Std': np.std(cv_accuracy_rates),
            'Test_R': test_r,
            'Test_R2': test_r2,
            'Test_RMSE': test_rmse,
            'Test_Avg_Accuracy': test_avg_accuracy,
            'Test_Accuracy_Rate': test_accuracy_rate
        })
    
    # Convert to DataFrame
    results_df = pd.DataFrame(records)
    
    # Calculate statistical summary
    summary_stats = []
    
    # Test R² statistics
    summary_stats.append({
        'Metric': 'Test_R2',
        'Mean': results_df['Test_R2'].mean(),
        'Std': results_df['Test_R2'].std(),
        'CV(%)': (results_df['Test_R2'].std() / abs(results_df['Test_R2'].mean())) * 100,
        'Min': results_df['Test_R2'].min(),
        'Max': results_df['Test_R2'].max(),
        'Median': results_df['Test_R2'].median(),
        'Qualified Rate(≥0.7)': (results_df['Test_R2'] >= 0.7).sum() / len(results_df) * 100
    })
    
    # Test RMSE statistics
    summary_stats.append({
        'Metric': 'Test_RMSE',
        'Mean': results_df['Test_RMSE'].mean(),
        'Std': results_df['Test_RMSE'].std(),
        'CV(%)': (results_df['Test_RMSE'].std() / results_df['Test_RMSE'].mean()) * 100,
        'Min': results_df['Test_RMSE'].min(),
        'Max': results_df['Test_RMSE'].max(),
        'Median': results_df['Test_RMSE'].median(),
        'Qualified Rate(≤50)': (results_df['Test_RMSE'] <= 50).sum() / len(results_df) * 100
    })
    
    # Test accuracy rate statistics
    summary_stats.append({
        'Metric': 'Test_Accuracy_Rate',
        'Mean': results_df['Test_Accuracy_Rate'].mean(),
        'Std': results_df['Test_Accuracy_Rate'].std(),
        'CV(%)': (results_df['Test_Accuracy_Rate'].std() / results_df['Test_Accuracy_Rate'].mean()) * 100,
        'Min': results_df['Test_Accuracy_Rate'].min(),
        'Max': results_df['Test_Accuracy_Rate'].max(),
        'Median': results_df['Test_Accuracy_Rate'].median(),
        'Qualified Rate(≥85%)': (results_df['Test_Accuracy_Rate'] >= 0.85).sum() / len(results_df) * 100
    })
    
    # Cross-validation R² statistics
    summary_stats.append({
        'Metric': 'CV_R2',
        'Mean': results_df['CV_R2_Mean'].mean(),
        'Std': results_df['CV_R2_Mean'].std(),
        'CV(%)': (results_df['CV_R2_Mean'].std() / abs(results_df['CV_R2_Mean'].mean())) * 100,
        'Min': results_df['CV_R2_Mean'].min(),
        'Max': results_df['CV_R2_Mean'].max(),
        'Median': results_df['CV_R2_Mean'].median(),
        'Qualified Rate(≥0.7)': (results_df['CV_R2_Mean'] >= 0.7).sum() / len(results_df) * 100
    })
    
    summary_df = pd.DataFrame(summary_stats)
    
    # Calculate 95% confidence intervals
    confidence_intervals = []
    for metric in ['Test_R2', 'Test_RMSE', 'Test_Accuracy_Rate']:
        mean_val = results_df[metric].mean()
        std_val = results_df[metric].std()
        ci_lower = mean_val - 1.96 * std_val
        ci_upper = mean_val + 1.96 * std_val
        
        confidence_intervals.append({
            'Metric': metric,
            'Mean': mean_val,
            'Std': std_val,
            '95% CI Lower': ci_lower,
            '95% CI Upper': ci_upper
        })
    
    ci_df = pd.DataFrame(confidence_intervals)
    
    return results_df, summary_df, ci_df

# =========================  Main function  =========================
def main():
    # Specify experiment directory
    experiment_dir = r"C:\Users\ma'wei'bin\Desktop\聚合物复合材料机器学习 加工艺参数\热稳定性数据\6月新尝试\1113 - 副本\phrr - 0822\PHRR_experiment_20260424_144158增强"
    
    # Check if directory exists
    if not os.path.exists(experiment_dir):
        return
    
    # 1. Data loading and cleaning
    dataset, target_col, numeric_cols = load_data()
    
    # 2. Feature engineering
    df_eng = feature_engineering(dataset, target_col=target_col)
    
    # 3. Read selected features
    selected_features = load_selected_features(experiment_dir)
    
    if not selected_features:
        selected_features = [col for col in df_eng.columns if col != target_col]
    
    # 4. Filter valid features
    available_features = [feat for feat in selected_features if feat in df_eng.columns]
    
    # Filter constant features
    var_threshold = 1e-6
    valid_features = []
    for feat in available_features:
        if df_eng[feat].var() > var_threshold:
            valid_features.append(feat)
    
    if not valid_features:
        return
    
    # 5. Read GBR optimal parameters
    gbr_params = load_gbr_best_params(experiment_dir)
    
    # 6. Prepare feature matrix and target variable
    X = df_eng[valid_features].copy()
    y = df_eng[target_col].values
    
    # 7. GBR stability test (50 runs)
    results_df, summary_df, ci_df = gbr_stability_test(X, y, valid_features, gbr_params, n_runs=50)
    
    # 8. Save results
    output_file = "GBR_Stability_Results.xlsx"
    try:
        with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
            results_df.to_excel(writer, sheet_name='All_Runs_Results', index=False)
            summary_df.to_excel(writer, sheet_name='Summary_Statistics', index=False)
            ci_df.to_excel(writer, sheet_name='Confidence_Intervals', index=False)
            
            # Add model configuration information
            config_data = []
            for key, value in gbr_params.items():
                config_data.append({'Config_Item': key, 'Value': value})
            config_data.append({'Config_Item': 'Number_of_Runs', 'Value': 50})
            config_data.append({'Config_Item': 'Test_Set_Ratio', 'Value': '20%'})
            config_data.append({'Config_Item': 'Cross_Validation_Folds', 'Value': 5})
            config_data.append({'Config_Item': 'Feature_Count', 'Value': len(valid_features)})
            config_data.append({'Config_Item': 'Sample_Count', 'Value': X.shape[0]})
            config_data.append({'Config_Item': 'Experiment_Directory', 'Value': experiment_dir})
            
            config_df = pd.DataFrame(config_data)
            config_df.to_excel(writer, sheet_name='Model_Config', index=False)
            
            # Add feature list
            features_df = pd.DataFrame({'Feature_Name': valid_features})
            features_df.to_excel(writer, sheet_name='Selected_Features', index=False)
    except:
        results_df.to_csv("GBR_All_Runs.csv", index=False, encoding='utf-8-sig')
        summary_df.to_csv("GBR_Summary.csv", index=False, encoding='utf-8-sig')
        ci_df.to_csv("GBR_CI.csv", index=False, encoding='utf-8-sig')
        
        config_df = pd.DataFrame(gbr_params.items(), columns=['Parameter', 'Value'])
        config_df.to_csv("GBR_Config.csv", index=False, encoding='utf-8-sig')

if __name__ == "__main__":
    main()