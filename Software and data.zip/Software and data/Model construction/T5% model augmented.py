# -*- coding: utf-8 -*-
"""
GA-T5 Stop-on-Qualification (Default Seed 12345) - Parameter Optimized · Stable No-Error Version
Fixed: GA feature selection only performed on training set
"""
import os
import sys

# Set temporary directory to English-only path
if sys.platform.startswith('win'):
    temp_dir = "C:\\Temp_ML_Project"
    if not os.path.exists(temp_dir):
        os.makedirs(temp_dir)
    
    os.environ['TMP'] = temp_dir
    os.environ['TEMP'] = temp_dir
    os.environ['JOBLIB_TEMP_FOLDER'] = temp_dir

# Set environment variables
os.environ['PYTHONIOENCODING'] = 'utf-8'
os.environ['PYTHONUTF8'] = '1'

import numpy as np
import pandas as pd
import joblib, os, argparse, warnings, random, time, shutil
from datetime import datetime
from sklearn.model_selection import train_test_split, cross_val_score, cross_val_predict, GridSearchCV, KFold
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from scipy.stats import pearsonr

# Models
from sklearn.linear_model import Ridge, ElasticNet
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, AdaBoostRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.neural_network import MLPRegressor
from xgboost import XGBRegressor
from catboost import CatBoostRegressor

# Genetic algorithm
from deap import base, tools, creator, algorithms

warnings.filterwarnings('ignore')

# =======================  Data Path Configuration  =======================
# Please set your data file path here
DATA_FILE_PATH = "Your augmented data"  # Change this to your actual data file path
# =========================================================================

# ---------- Utilities ----------
def init_experiment_dir():
    t = datetime.now().strftime("%Y%m%d_%H%M%S")
    d = f"ga_experiment_{t}"
    os.makedirs(d, exist_ok=True)
    return d

def load_data():
    df = pd.read_excel(DATA_FILE_PATH)
    target = 'T5%(℃)'
    if 'NO' in df.columns:
        df = df.drop(columns=['NO'])
    X = df.drop(columns=[target])
    y = df[target]
    print(f"Training data feature columns: {X.columns.tolist()}")
    return X.values, y, X.columns.tolist()

# ---------- Genetic Algorithm Feature Selection (Fixed: Only on training set) ----------
def ga_feature_selection(X_train, y_train, feature_names, exp_dir=None, seed=42):
    """GA feature selection only performed on training set"""
    random.seed(seed); np.random.seed(seed)
    ngen, cxpb, mutpb, pop_size = 12, 0.5, 0.7, 10
    out_num = random.randint(5, 16)
    model_params = {'iterations': 500, 'learning_rate': 0.05, 'depth': 6, 'silent': True, 'random_state': seed}

    def eval_fn(ind, X_train, y_train):
        if sum(ind) <= 2:
            return (9999,)
        X_sel = X_train[:, ind]
        model = CatBoostRegressor(**model_params)
        try:
            # Cross-validation only performed on training set
            scores = cross_val_score(model, X_sel, y_train, cv=5, scoring='neg_root_mean_squared_error', n_jobs=-1)
            return (np.mean(-scores),)
        except:
            return (9999,)

    if 'FitnessMin' in dir(creator):
        del creator.FitnessMin, creator.Individual
    creator.create("FitnessMin", base.Fitness, weights=(-1.0,))
    creator.create("Individual", list, fitness=creator.FitnessMin)
    toolbox = base.Toolbox()
    toolbox.register("evaluate", eval_fn, X_train=X_train, y_train=y_train)
    toolbox.register("mate", tools.cxTwoPoint)

    def mutate(ind, indpb, n_feat):
        mutable = list(range(len(ind)))
        if len(ind) > 1 and mutable and random.random() < indpb:
            ind.pop(random.choice(mutable))
        avail = list(set(range(n_feat)) - set(ind))
        if avail and random.random() < indpb:
            ind.append(random.choice(avail))
        min_s, max_s = 2, n_feat
        if len(ind) < min_s:
            ind.extend(random.sample(list(set(range(n_feat))-set(ind)), min_s-len(ind)))
        elif len(ind) > max_s:
            for v in random.sample(ind, len(ind)-max_s):
                ind.remove(v)
        return ind,

    toolbox.register("mutate", mutate, indpb=0.05, n_feat=X_train.shape[1])
    toolbox.register("select", tools.selTournament, tournsize=10)

    def init_ind(n_feat, out):
        ind = set(random.sample(range(n_feat), min(out, n_feat)))
        return creator.Individual(list(ind))

    toolbox.register("individual", init_ind, n_feat=X_train.shape[1], out=out_num)
    toolbox.register("population", tools.initRepeat, list, toolbox.individual, n=pop_size)
    pop = toolbox.population()
    hall = tools.HallOfFame(1)
    algorithms.eaSimple(pop, toolbox, cxpb, mutpb, ngen=ngen, halloffame=hall, verbose=False)
    best = hall[0]
    mask = [i in best for i in range(len(feature_names))]
    X_sel = X_train[:, mask]
    feats = [feature_names[i] for i, m in enumerate(mask) if m]
    if exp_dir:
        with open(os.path.join(exp_dir, "selected_features.txt"), "w", encoding='utf-8') as f:
            f.write("Selected features:\n" + "\n".join(f"{i+1}. {feat}" for i, feat in enumerate(feats)))
    return X_sel, feats, mask

# ---------- Parameter Optimization ----------
def optimize_parameters(X_train, y_train, model_name, base_model, param_grid, seed=42):
    print(f"Optimizing {model_name} parameters...")
    start = time.time()
    grid = GridSearchCV(base_model, param_grid, cv=5, scoring='r2', n_jobs=-1, verbose=0)
    grid.fit(X_train, y_train)
    print(f"{model_name} Best R²: {grid.best_score_:.4f}, Time: {time.time()-start:.2f}s")
    return grid.best_estimator_, grid.best_params_, grid.best_score_, time.time()-start

# ---------- Model Evaluation (Fixed: Split train and test first) ----------
def evaluate_models(X, y, feature_names, exp_dir=None, seed=42):
    """Evaluate models: Split train and test first, cross-validation only on training set"""
    random.seed(seed); np.random.seed(seed)
    
    # Split training and test sets first
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=seed)
    print(f"\nDataset split complete | Training set: {X_train.shape[0]} samples | Test set: {X_test.shape[0]} samples")

    # Base models
    base_models = {
        "Ridge": Ridge(max_iter=10000, tol=1e-4, random_state=seed),
        "ElasticNet": ElasticNet(max_iter=10000, tol=1e-4, random_state=seed),
        "RF": RandomForestRegressor(random_state=seed, n_jobs=-1),
        "GBR": GradientBoostingRegressor(random_state=seed),
        "XGB": XGBRegressor(random_state=seed, verbosity=0, n_jobs=-1),
        "KNN": KNeighborsRegressor(n_jobs=-1),
        "Ada": AdaBoostRegressor(random_state=seed),
        "Cat": CatBoostRegressor(silent=True, random_state=seed, thread_count=-1),
        "MLP": MLPRegressor(max_iter=2000, random_state=seed)
    }

    param_grids = {
        "Ridge": {'alpha': [0.1, 0.5, 1.0, 5.0, 10.0]},
        "ElasticNet": {'alpha': [0.1, 0.5, 1.0], 'l1_ratio': [0.1, 0.5, 0.9]},
        "RF": {'n_estimators': [50, 100, 200], 'max_depth': [None, 10, 20], 'min_samples_split': [2, 5]},
        "GBR": {'n_estimators': [50, 100, 200], 'learning_rate': [0.01, 0.05, 0.1], 'max_depth': [3, 5]},
        "XGB": {'n_estimators': [50, 100, 200], 'learning_rate': [0.01, 0.05, 0.1], 'max_depth': [3, 5]},
        "KNN": {'n_neighbors': [3, 5, 7], 'weights': ['uniform', 'distance'], 'p': [1, 2]},
        "Ada": {'n_estimators': [50, 100, 200], 'learning_rate': [0.01, 0.1, 1.0]},
        "Cat": {'iterations': [100, 200], 'learning_rate': [0.01, 0.05], 'depth': [4, 6]},
        "MLP": {'hidden_layer_sizes': [(50,), (100,)], 'activation': ['relu'], 'alpha': [0.0001, 0.001]}
    }

    cv_res, test_res = [], []
    model_dir = os.path.join(exp_dir, "models")
    os.makedirs(model_dir, exist_ok=True)
    
    # Create folder for prediction results
    predictions_dir = os.path.join(exp_dir, "predictions")
    os.makedirs(predictions_dir, exist_ok=True)

    # Store CV predictions and test set predictions for all models
    cv_predictions = pd.DataFrame({"Actual_train": y_train})
    test_predictions = pd.DataFrame({"Actual_test": y_test})
    
    # Store trained models
    trained_models = {}

    for name, base_model in base_models.items():
        try:
            best_model, best_params, best_score, opt_time = optimize_parameters(
                X_train, y_train, name, base_model, param_grids[name], seed
            )
            
            # Save model
            trained_models[name] = best_model
            joblib.dump(best_model, os.path.join(model_dir, f"{name}.pkl"))
            
            # 5-fold cross-validation predictions (only on training set)
            kf = KFold(n_splits=5, shuffle=True, random_state=seed)
            cv_preds = cross_val_predict(best_model, X_train, y_train, cv=kf)
            cv_r2 = cross_val_score(best_model, X_train, y_train, cv=5, scoring='r2').mean()
            cv_rmse = np.sqrt(mean_squared_error(y_train, cv_preds))
            cv_mae = mean_absolute_error(y_train, cv_preds)
            cv_acc = (np.abs(cv_preds - y_train) / (y_train + 1e-6) <= 0.15).mean()
            cv_corr, _ = pearsonr(y_train, cv_preds)

            # Test set predictions (final evaluation)
            best_model.fit(X_train, y_train)
            test_preds = best_model.predict(X_test)
            r2_te = r2_score(y_test, test_preds)
            rmse_te = np.sqrt(mean_squared_error(y_test, test_preds))
            mae_te = mean_absolute_error(y_test, test_preds)
            acc_te = (np.abs(test_preds - y_test) / (y_test + 1e-6) <= 0.15).mean()
            test_corr, _ = pearsonr(y_test, test_preds)

            cv_res.append({
                "Model": name, 
                "CV_R2": cv_r2, 
                "CV_RMSE": cv_rmse, 
                "CV_MAE": cv_mae, 
                "CV_Acc": cv_acc, 
                "CV_Corr": cv_corr
            })
            test_res.append({
                "Model": name, 
                "Test_R2": r2_te, 
                "Test_RMSE": rmse_te, 
                "Test_MAE": mae_te, 
                "Test_Acc": acc_te, 
                "Test_Corr": test_corr, 
                "Best_Params": str(best_params)
            })
            
            # Save predictions
            cv_predictions[f"{name}_Pred"] = cv_preds
            test_predictions[f"{name}_Pred"] = test_preds
            
            print(f"{name:<12} | CV R²={cv_r2:.4f}  Test R²={r2_te:.4f}  Test Acc={acc_te:.1%}")
        except Exception as e:
            print(f"{name:<12} | Error: {e}")
            cv_res.append({"Model": name, "Error": str(e)})
            test_res.append({"Model": name, "Error": str(e)})

    # Save CV and test set predictions for all models
    cv_predictions.to_csv(os.path.join(predictions_dir, "all_models_cv_predictions.csv"), index=False)
    test_predictions.to_csv(os.path.join(predictions_dir, "all_models_test_predictions.csv"), index=False)
    
    # Save results CSV
    pd.DataFrame(cv_res).to_csv(os.path.join(exp_dir, "cross_validation_results.csv"), index=False)
    pd.DataFrame(test_res).to_csv(os.path.join(exp_dir, "test_results.csv"), index=False)
    
    return cv_res, test_res, trained_models

# ---------- Main function (Fixed: Split train and test first) ----------
def main(random_seed=1008):
    print("="*80)
    print("GA-T5 Stop-on-Qualification · Stable Version")
    print(f"Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Random seed: {random_seed}")
    print("="*80)
    exp_dir = init_experiment_dir()
    X, y, feat_names = load_data()
    print(f"\nData loaded: {X.shape[0]} samples, {X.shape[1]} features")
    R2_TH, ACC_TH = 0.70, 0.85

    trained_models_all = None
    selected_features_all = None

    for it in range(1, 4):
        seed = random_seed + (it-1)
        print(f"\n>>> Iteration {it}/3 (seed={seed})")
        iter_dir = os.path.join(exp_dir, f"iter_{it}")
        os.makedirs(iter_dir, exist_ok=True)
        
        # Key fix: Split training and test sets first
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=seed)
        print(f"Training set samples: {X_train.shape[0]}, Test set samples: {X_test.shape[0]}")
        
        # GA feature selection only on training set
        X_train_sel, sel_feats, mask = ga_feature_selection(X_train, y_train, feat_names, iter_dir, seed)
        print(f"Feature selection complete: selected {len(sel_feats)} features")
        print(f"Selected features: {sel_feats}")
        
        # Apply feature mask to test set
        if mask is not None:
            mask_bool = [i in mask for i in range(len(feat_names))]
            X_test_sel = X_test[:, mask_bool]
        else:
            X_test_sel = X_test
        
        # Evaluate models (using selected features)
        cv, test, trained_models = evaluate_models(X_train_sel, y_train, sel_feats, iter_dir, seed)

        # Check qualification on test set
        qualified = [t for t in test if isinstance(t, dict) and t.get("Test_R2", 0) >= R2_TH and t.get("Test_Acc", 0) >= ACC_TH]
        if qualified:
            print(f"\n✅ Iteration {it} qualified: {len(qualified)} models")
            pd.DataFrame(qualified).to_csv(os.path.join(exp_dir, "qualified_models.csv"), index=False)
            
            # Save qualified iteration models and features
            trained_models_all = trained_models
            selected_features_all = sel_feats
            
            # Keep only qualified iteration results
            if it > 1:
                for i in range(1, it):
                    other_iter_dir = os.path.join(exp_dir, f"iter_{i}")
                    if os.path.exists(other_iter_dir):
                        shutil.rmtree(other_iter_dir)
            # Rename current iteration folder
            final_iter_dir = os.path.join(exp_dir, "final_iteration")
            if os.path.exists(final_iter_dir):
                shutil.rmtree(final_iter_dir)
            shutil.move(iter_dir, final_iter_dir)
            break
        else:
            print(f"❌ Iteration {it} did not qualify")
            # If this is the last iteration, keep the results
            if it == 3:
                trained_models_all = trained_models
                selected_features_all = sel_feats
                # Rename last iteration folder
                final_iter_dir = os.path.join(exp_dir, "final_iteration")
                if os.path.exists(final_iter_dir):
                    shutil.rmtree(final_iter_dir)
                shutil.move(iter_dir, final_iter_dir)
    
    print("\n" + "="*80)
    print(f"Experiment completion time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"All results saved in: {exp_dir}")
    print("="*80)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int, default=709, help='Random seed')
    args = parser.parse_args()
    main(args.seed)