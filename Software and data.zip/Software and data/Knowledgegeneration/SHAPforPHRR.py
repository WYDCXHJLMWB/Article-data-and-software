# -*- coding: utf-8 -*-
"""
Ridge Regression SHAP Analysis (Exact Match with Original Training Process)
Based on your training code, ensuring:
1. No standardization used
2. Exactly the same feature engineering
3. Exactly the same feature selection
4. Output SHAP value comparison with Ridge regression coefficients
"""

import os
import sys
import numpy as np
import pandas as pd
import joblib
import shap
import matplotlib.pyplot as plt
from datetime import datetime
import warnings
import traceback
import json
from sklearn.model_selection import train_test_split
import matplotlib.patches as mpatches

warnings.filterwarnings('ignore')
# Configure matplotlib - Using Times New Roman font, ensuring proper display
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.sans-serif'] = ['Times New Roman', 'DejaVu Sans', 'Liberation Sans']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams["figure.dpi"] = 300
plt.rcParams['font.size'] = 12
plt.rcParams['mathtext.fontset'] = 'stix'  # Math font also uses Times New Roman style

# ---------- Configuration ----------
# Using exactly the same configuration as your training code
TARGET_COL = 'PHRR（Kw/m2）'
RAW_DATA_FILE = 'PHRRa1.xlsx'

# Experiment directory (replace with your actual experiment directory)
# You can find this directory from the training code output
EXPERIMENT_DIR = "PHRR_experiment_20251212_205007"  # Please replace with actual experiment directory

# ------------------------------------------------------------------
# 1. Load Experiment Assets (Exactly Matching Training Process)
# ------------------------------------------------------------------
def load_experiment_assets(experiment_dir):
    """Load all necessary assets from the experiment"""
    assets = {}
    
    # 1. Load Ridge regression model
    models_dir = os.path.join(experiment_dir, "models")
    if not os.path.exists(models_dir):
        print(f"Model directory does not exist: {models_dir}")
        return None
        
    # Find the latest Ridge regression model
    ridge_models = [f for f in os.listdir(models_dir) if "ridge_regression" in f.lower() and f.endswith('.pkl')]
    if not ridge_models:
        print("Ridge regression model file not found")
        return None
    
    # Sort by time, select the latest model
    ridge_models.sort(reverse=True)
    model_path = os.path.join(models_dir, ridge_models[0])
    
    try:
        assets['model'] = joblib.load(model_path)
        print(f"Ridge regression model loaded: {model_path}")
        print(f"   Model type: {type(assets['model']).__name__}")
        print(f"   Model parameters: {assets['model'].get_params()}")
    except Exception as e:
        print(f"Failed to load model: {str(e)}")
        return None
    
    # 2. Load feature mask and feature names
    feature_mask_path = os.path.join(experiment_dir, "feature_mask.npy")
    feature_names_path = os.path.join(experiment_dir, "phrr_train_features.pkl")
    
    if os.path.exists(feature_mask_path):
        assets['feature_mask'] = np.load(feature_mask_path)
        print(f"Feature mask loaded, shape: {assets['feature_mask'].shape}")
    else:
        print("Feature mask file does not exist")
        assets['feature_mask'] = None
    
    if os.path.exists(feature_names_path):
        assets['feature_names'] = joblib.load(feature_names_path)
        print(f"Feature names loaded, total {len(assets['feature_names'])} features")
    else:
        print("Feature names file does not exist")
        assets['feature_names'] = None
    
    # 3. Load selected features list
    selected_features_path = os.path.join(experiment_dir, "feature_selection", "selected_features.csv")
    if os.path.exists(selected_features_path):
        selected_df = pd.read_csv(selected_features_path)
        assets['selected_features'] = selected_df['feature_name'].tolist()
        print(f"Selected features loaded, total {len(assets['selected_features'])} features")
    else:
        print("Selected features file does not exist")
        assets['selected_features'] = None
    
    # 4. Load Ridge regression formula
    formulas_dir = os.path.join(experiment_dir, "regression_formulas")
    if os.path.exists(formulas_dir):
        formula_files = [f for f in os.listdir(formulas_dir) if "ridge_formula" in f and f.endswith('.txt')]
        if formula_files:
            formula_files.sort(reverse=True)
            formula_path = os.path.join(formulas_dir, formula_files[0])
            with open(formula_path, 'r', encoding='utf-8') as f:
                assets['formula'] = f.read()
            print(f"Ridge regression formula loaded: {formula_path}")
        else:
            assets['formula'] = None
            print("Ridge regression formula file not found")
    else:
        assets['formula'] = None
    
    # 5. Load model information
    model_info_path = model_path.replace('.pkl', '_info.json')
    if os.path.exists(model_info_path):
        with open(model_info_path, 'r', encoding='utf-8') as f:
            assets['model_info'] = json.load(f)
        print(f"Model information loaded")
    else:
        assets['model_info'] = {}
    
    return assets

# ------------------------------------------------------------------
# 2. Data Loading and Preprocessing (Exact Copy of Your Code)
# ------------------------------------------------------------------
def load_and_preprocess_data(random_seed=11):
    """Exact copy of data loading and preprocessing process from your training code"""
    print("\n" + "="*60)
    print("Data Loading and Preprocessing (Exact Copy of Training Process)")
    print("="*60)
    
    dataset = pd.read_excel(RAW_DATA_FILE)
    target_col = TARGET_COL
    
    # Remove NO sequence column
    if 'NO' in dataset.columns:
        initial_count = len(dataset)
        dataset = dataset.drop(columns=['NO'], errors='ignore')
        print(f"NO sequence column detected and removed (Original sample count: {initial_count}, After removal: {len(dataset)})")
    else:
        print(f"Original data sample count: {len(dataset)}")
    
    # Target value range filtering
    clean_mask = (dataset[target_col] > 10) & (dataset[target_col] <= 1000)
    dataset = dataset[clean_mask].copy().reset_index(drop=True)
    print(f"Sample count after target value filtering: {len(dataset)}")
    
    # Keep only numerical features (remove all non-numerical columns)
    numeric_cols = dataset.select_dtypes(include=[np.number]).columns.tolist()
    if target_col in numeric_cols:
        numeric_cols.remove(target_col)
    
    # Filter non-numerical columns
    dataset = dataset[numeric_cols + [target_col]].copy()
    print(f"Only numerical features kept, feature list: {numeric_cols}")
    
    # IQR outlier filtering (only for numerical features)
    pre_iqr_count = len(dataset)
    for col in numeric_cols:
        Q1 = dataset[col].quantile(0.25)
        Q3 = dataset[col].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        dataset = dataset[(dataset[col] >= lower_bound) & (dataset[col] <= upper_bound)].copy().reset_index(drop=True)
    
    print(f"Sample count after IQR outlier filtering: {len(dataset)} (Filtered {pre_iqr_count - len(dataset)} outlier samples)")
    
    # Numerical feature missing value imputation (median)
    dataset[numeric_cols] = dataset[numeric_cols].fillna(dataset[numeric_cols].median())
    
    return dataset, target_col, numeric_cols

# ------------------------------------------------------------------
# 3. Feature Engineering (Exact Copy of Your Code)
# ------------------------------------------------------------------
def apply_feature_engineering(data, target_col, train_features=None):
    """Exact copy of feature engineering from your training code"""
    print("\n" + "="*60)
    print("Feature Engineering (Exact Copy of Training Process)")
    print("="*60)
    
    df = data.copy()
    
    # Remove NO column (if exists)
    if 'NO' in df.columns:
        df = df.drop(columns=['NO'])
    
    # Feature enhancement based on numerical features (only process existing numerical columns)
    additive_cols = ['PAPP', 'MPP', 'W', 'ZS', 'ADP']
    existing_additive = [col for col in additive_cols if col in df.columns]
    if existing_additive:
        df['total_ad'] = df[existing_additive].sum(axis=1)
        df['additive_ratio'] = df['total_ad'] / (df[existing_additive].max(axis=1) + 1e-6)
    else:
        df['total_ad'] = 0
        df['additive_ratio'] = 0
        print("Core additive features (PAPP/MPP/W/ZS/ADP) do not exist, skipping related feature enhancement")
    
    # Numerical feature ratio calculation
    if 'PAPP' in df.columns and 'total_ad' in df.columns:
        df['PAPP_ratio'] = df['PAPP'] / (df['total_ad'] + 1e-6)
    else:
        df['PAPP_ratio'] = 0
    
    if 'MPP' in df.columns and 'total_ad' in df.columns:
        df['MPP_ratio'] = df['MPP'] / (df['total_ad'] + 1e-6)
    else:
        df['MPP_ratio'] = 0
    
    # Synergist numerical feature processing
    synergist_cols = ['W', 'ZS', 'ADP']
    existing_synergist = [col for col in synergist_cols if col in df.columns]
    if existing_synergist:
        df['synergist_total'] = df[existing_synergist].sum(axis=1)
        if 'W' in df.columns:
            df['W_ratio_in_synergist'] = df['W'] / (df['synergist_total'] + 1e-6)
        else:
            df['W_ratio_in_synergist'] = 0
    else:
        df['synergist_total'] = 0
        df['W_ratio_in_synergist'] = 0
    
    # Numerical feature interaction terms
    if all(col in df.columns for col in ['PAPP', 'MPP', 'W']):
        df['PAPP_MPP_W_interaction'] = df['PAPP'] * df['MPP'] * df['W']
    else:
        df['PAPP_MPP_W_interaction'] = 0
    
    # Numerical feature square terms
    if 'PAPP' in df.columns:
        df['PAPP_square'] = df['PAPP'] ** 2
    else:
        df['PAPP_square'] = 0
    
    if 'MPP' in df.columns:
        df['MPP_square'] = df['MPP'] ** 2
    else:
        df['MPP_square'] = 0
    
    # Add more feature interactions and transformations
    if all(col in df.columns for col in ['PAPP', 'MPP']):
        df['PAPP_MPP_ratio'] = df['PAPP'] / (df['MPP'] + 1e-6)
    
    if all(col in df.columns for col in ['PAPP', 'W']):
        df['PAPP_W_ratio'] = df['PAPP'] / (df['W'] + 1e-6)
    
    # Add polynomial features
    if 'PAPP' in df.columns:
        df['PAPP_sqrt'] = np.sqrt(df['PAPP'])
    
    if 'MPP' in df.columns:
        df['MPP_sqrt'] = np.sqrt(df['MPP'])
    
    if all(col in df.columns for col in ['ZS', 'total_ad']):
        df['ZS_ratio'] = df['ZS'] / (df['total_ad'] + 1e-6)
    
    if all(col in df.columns for col in ['W', 'total_ad']):
        df['W_ratio'] = df['W'] / (df['total_ad'] + 1e-6)
    
    if all(col in df.columns for col in ['ADP', 'total_ad']):
        df['ADP_ratio'] = df['ADP'] / (df['total_ad'] + 1e-6)
    
    # Keep only numerical features
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if target_col in numeric_cols:
        numeric_cols.remove(target_col)
    
    # Align with training set features (only numerical features)
    if train_features is not None:
        train_features = [f for f in train_features if f != 'NO' and f in numeric_cols + [target_col]]
        for feat in train_features:
            if feat not in df.columns:
                df[feat] = 0
        df = df[train_features + [target_col]] if target_col in df.columns else df[train_features]
    
    print(f"Feature engineering completed, final data shape: {df.shape}")
    print(f"Feature list: {list(df.columns)}")
    
    return df

# ------------------------------------------------------------------
# 4. Feature Selection (Apply GA Feature Mask)
# ------------------------------------------------------------------
def apply_feature_selection(X, feature_names, feature_mask):
    """Apply GA feature selection mask"""
    print("\n" + "="*60)
    print("Feature Selection (Apply GA Feature Mask)")
    print("="*60)
    
    if feature_mask is None:
        print("No feature mask, using all features")
        return X, feature_names
    
    # Ensure mask length matches
    if len(feature_mask) != len(feature_names):
        print(f"Feature mask length ({len(feature_mask)}) does not match feature names length ({len(feature_names)})")
        # Take smaller value
        min_len = min(len(feature_mask), len(feature_names))
        feature_mask = feature_mask[:min_len]
        feature_names = feature_names[:min_len]
    
    # Apply feature mask
    selected_indices = [i for i, selected in enumerate(feature_mask) if selected]
    X_selected = X[:, selected_indices]
    selected_feature_names = [feature_names[i] for i in selected_indices]
    
    print(f"Original feature count: {X.shape[1]}")
    print(f"Selected feature count: {X_selected.shape[1]}")
    print(f"Selected features: {selected_feature_names}")
    
    return X_selected, selected_feature_names

# ------------------------------------------------------------------
# 5. Save Split Datasets
# ------------------------------------------------------------------
def save_split_datasets(X_train, X_test, y_train, y_test, feature_names, target_col, experiment_dir):
    """Save split training and test sets"""
    print("\n" + "="*60)
    print("Saving Split Datasets")
    print("="*60)
    
    data_dir = os.path.join(experiment_dir, "split_datasets")
    os.makedirs(data_dir, exist_ok=True)
    
    # Create training set DataFrame
    train_df = pd.DataFrame(X_train, columns=feature_names)
    train_df[target_col] = y_train
    train_df['dataset_type'] = 'train'
    
    # Create test set DataFrame
    test_df = pd.DataFrame(X_test, columns=feature_names)
    test_df[target_col] = y_test
    test_df['dataset_type'] = 'test'
    
    # Save training and test sets
    train_path = os.path.join(data_dir, "training_set.csv")
    test_path = os.path.join(data_dir, "test_set.csv")
    combined_path = os.path.join(data_dir, "full_dataset_split.csv")
    
    train_df.to_csv(train_path, index=False, encoding="utf-8-sig")
    test_df.to_csv(test_path, index=False, encoding="utf-8-sig")
    
    # Save combined dataset
    combined_df = pd.concat([train_df, test_df], ignore_index=True)
    combined_df.to_csv(combined_path, index=False, encoding="utf-8-sig")
    
    print(f"Training set saved: {train_path} (sample count: {len(train_df)})")
    print(f"Test set saved: {test_path} (sample count: {len(test_df)})")
    print(f"Complete dataset saved: {combined_path} (total sample count: {len(combined_df)})")
    
    # Print dataset statistics
    print(f"\nDataset Statistics:")
    print(f"   Training set samples: {len(train_df)} ({len(train_df)/len(combined_df)*100:.1f}%)")
    print(f"   Test set samples: {len(test_df)} ({len(test_df)/len(combined_df)*100:.1f}%)")
    print(f"   Number of features: {len(feature_names)}")
    print(f"   Target variable: {target_col}")
    
    return train_path, test_path, combined_path

# ------------------------------------------------------------------
# 6. Validate Data Consistency (Critical Step)
# ------------------------------------------------------------------
def validate_data_consistency(model, X_train, feature_names):
    """Validate consistency between SHAP analysis and Ridge regression formula"""
    print("\n" + "="*60)
    print("Data Consistency Validation")
    print("="*60)
    
    # 1. Check model type
    print(f"1. Model type check:")
    print(f"   Model type: {type(model).__name__}")
    print(f"   Is Ridge regression: {'Ridge' in type(model).__name__}")
    
    # 2. Check feature count
    print(f"\n2. Feature count check:")
    if hasattr(model, 'coef_'):
        model_coef_count = len(model.coef_) if model.coef_.ndim == 1 else model.coef_.shape[1]
    elif hasattr(model, 'n_features_in_'):
        model_coef_count = model.n_features_in_
    else:
        model_coef_count = "Unknown"
    
    print(f"   Model expected feature count: {model_coef_count}")
    print(f"   Actual provided feature count: {len(feature_names)}")
    print(f"   Feature names: {feature_names}")
    
    # 3. Check coefficient and feature alignment
    if hasattr(model, 'coef_') and model.coef_.ndim == 1:
        print(f"\n3. Model coefficient check:")
        print(f"   Coefficient shape: {model.coef_.shape}")
        print(f"   Intercept: {model.intercept_}")
        
        # Absolute values and signs of first 10 coefficients
        abs_coef = np.abs(model.coef_)
        sorted_indices = np.argsort(-abs_coef)[:10]  # Top 10 by absolute value in descending order
        
        print(f"   Top 10 most important feature coefficients:")
        for i, idx in enumerate(sorted_indices):
            if idx < len(feature_names):
                feat_name = feature_names[idx]
            else:
                feat_name = f"Feature_{idx}"
            print(f"     {i+1:2d}. {feat_name:<30}: {model.coef_[idx]:.6f} (absolute: {abs_coef[idx]:.6f})")
    
    # 4. Manual validation of prediction consistency
    print(f"\n4. Prediction consistency validation:")
    if len(X_train) > 0:
        # Select a sample to validate
        sample_idx = 0
        x_sample = X_train[sample_idx:sample_idx+1]
        
        # Direct model prediction
        y_pred_direct = model.predict(x_sample)[0]
        
        # Calculate using Ridge regression formula
        if hasattr(model, 'coef_') and model.coef_.ndim == 1:
            y_pred_formula = model.intercept_ + np.dot(model.coef_, x_sample[0])
            diff = abs(y_pred_direct - y_pred_formula)
            
            print(f"   Model prediction for sample {sample_idx}: {y_pred_direct:.4f}")
            print(f"   Formula calculation for sample {sample_idx}: {y_pred_formula:.4f}")
            print(f"   Difference: {diff:.6f}")
            
            if diff > 0.001:
                print("   Warning: Model prediction does not match formula calculation!")
            else:
                print("   Model prediction matches formula calculation")
        else:
            print("   Cannot perform formula validation (incorrect model coefficient dimension)")
    
    return True

# ------------------------------------------------------------------
# 7. SHAP Analysis (Specifically for Ridge Regression)
# ------------------------------------------------------------------
def perform_ridge_shap_analysis(model, X_train, feature_names, experiment_dir):
    """Perform SHAP analysis specifically for Ridge regression"""
    print("\n" + "="*60)
    print("Ridge Regression SHAP Analysis")
    print("="*60)
    
    # Create output directory
    shap_dir = os.path.join(experiment_dir, "shap_analysis")
    os.makedirs(shap_dir, exist_ok=True)
    
    # Key: For Ridge regression, use LinearExplainer
    print("Creating LinearExplainer...")
    try:
        explainer = shap.LinearExplainer(model, X_train, feature_names=feature_names)
        print("LinearExplainer created successfully")
    except Exception as e:
        print(f"LinearExplainer failed: {str(e)}")
        print("Trying KernelExplainer...")
        explainer = shap.KernelExplainer(model.predict, X_train, feature_names=feature_names)
        print("KernelExplainer created successfully")
    
    # Calculate SHAP values
    print("Calculating SHAP values...")
    shap_values = explainer.shap_values(X_train)
    
    # Ensure correct SHAP value shape
    if isinstance(shap_values, list):
        shap_values = np.array(shap_values)
    if shap_values.ndim == 1:
        shap_values = shap_values.reshape(-1, 1)
    
    print(f"SHAP value shape: {shap_values.shape}")
    print(f"Expected value (baseline): {explainer.expected_value}")
    
    # Save SHAP values
    shap_df = pd.DataFrame(shap_values, columns=feature_names)
    shap_df.to_csv(os.path.join(shap_dir, "shap_values.csv"), index=False, encoding="utf-8-sig")
    print(f"SHAP values saved: {os.path.join(shap_dir, 'shap_values.csv')}")
    
    # Key: Create comparison analysis between SHAP values and model coefficients
    create_shap_coefficient_comparison(model, shap_values, feature_names, shap_dir)
    
    # Generate SHAP plots (English titles, Times New Roman font)
    generate_shap_plots_english(explainer, shap_values, X_train, feature_names, shap_dir)
    
    return explainer, shap_values

# ------------------------------------------------------------------
# 8. SHAP Value and Model Coefficient Comparison Analysis (Key)
# ------------------------------------------------------------------
def create_shap_coefficient_comparison(model, shap_values, feature_names, shap_dir):
    """Create comparison analysis between SHAP values and Ridge regression coefficients"""
    print("\n" + "="*60)
    print("SHAP Value and Ridge Regression Coefficient Comparison Analysis")
    print("="*60)
    
    if not hasattr(model, 'coef_') or model.coef_.ndim != 1:
        print("Model does not have 1D coefficients, cannot perform comparison analysis")
        return
    
    # Get model coefficients
    coefficients = model.coef_
    intercept = model.intercept_
    
    # Calculate SHAP value statistics
    shap_mean = np.abs(shap_values).mean(axis=0)  # Mean absolute SHAP value
    shap_std = shap_values.std(axis=0)  # SHAP value standard deviation
    shap_mean_raw = shap_values.mean(axis=0)  # Mean SHAP value (considering sign)
    
    # Create comparison dataframe
    comparison_data = []
    for i, feat_name in enumerate(feature_names):
        if i < len(coefficients):
            comparison_data.append({
                'feature_name': feat_name,
                'coefficient': coefficients[i],
                'abs_coefficient': abs(coefficients[i]),
                'shap_mean_abs': shap_mean[i] if i < len(shap_mean) else np.nan,
                'shap_mean_raw': shap_mean_raw[i] if i < len(shap_mean_raw) else np.nan,
                'shap_std': shap_std[i] if i < len(shap_std) else np.nan,
                'coefficient_rank': np.sum(abs(coefficients) > abs(coefficients[i])) + 1,
                'shap_rank': np.sum(shap_mean > shap_mean[i]) + 1 if i < len(shap_mean) else np.nan,
                'sign_consistency': np.sign(coefficients[i]) == np.sign(shap_mean_raw[i]) if i < len(shap_mean_raw) else False
            })
    
    comparison_df = pd.DataFrame(comparison_data)
    
    # Sort by coefficient absolute value
    comparison_df = comparison_df.sort_values('abs_coefficient', ascending=False)
    
    # Save comparison results
    comparison_path = os.path.join(shap_dir, "shap_coefficient_comparison.csv")
    comparison_df.to_csv(comparison_path, index=False, encoding="utf-8-sig")
    print(f"SHAP vs coefficient comparison table saved: {comparison_path}")
    
    # Print important findings
    print("\nImportant Findings:")
    print(f"1. Model intercept: {intercept:.6f}")
    print(f"2. Total features: {len(feature_names)}")
    
    # Check sign consistency
    sign_matches = comparison_df['sign_consistency'].sum()
    sign_total = comparison_df['sign_consistency'].count()
    print(f"3. Coefficient-SHAP sign consistency: {sign_matches}/{sign_total} ({sign_matches/sign_total:.1%})")
    
    if sign_matches < sign_total * 0.8:
        print("   Warning: Over 20% feature coefficients have inconsistent signs with SHAP values!")
        print("   Inconsistent features:")
        inconsistent = comparison_df[~comparison_df['sign_consistency']]
        for idx, row in inconsistent.iterrows():
            print(f"     {row['feature_name']}: Coefficient={row['coefficient']:.6f}, SHAP Mean={row['shap_mean_raw']:.6f}")
    
    # Check ranking consistency
    rank_diff = comparison_df['coefficient_rank'] - comparison_df['shap_rank']
    rank_corr = comparison_df[['coefficient_rank', 'shap_rank']].corr().iloc[0, 1]
    print(f"4. Importance ranking correlation: {rank_corr:.3f}")
    
    if abs(rank_corr) < 0.7:
        print("   Warning: Low correlation between coefficient importance and SHAP importance ranking!")
        print("   Features with largest ranking differences:")
        comparison_df['rank_difference'] = abs(comparison_df['coefficient_rank'] - comparison_df['shap_rank'])
        top_diff = comparison_df.nlargest(5, 'rank_difference')
        for idx, row in top_diff.iterrows():
            print(f"     {row['feature_name']}: Coefficient rank={row['coefficient_rank']}, SHAP rank={row['shap_rank']}, Difference={row['rank_difference']}")
    
    # Generate comparison plots (English titles, Times New Roman font)
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    
    # Set Times New Roman font for all subplots
    for ax in axes.flat:
        ax.set_title(ax.get_title(), fontname='Times New Roman', fontsize=12)
        ax.set_xlabel(ax.get_xlabel(), fontname='Times New Roman', fontsize=10)
        ax.set_ylabel(ax.get_ylabel(), fontname='Times New Roman', fontsize=10)
        for label in ax.get_xticklabels():
            label.set_fontname('Times New Roman')
        for label in ax.get_yticklabels():
            label.set_fontname('Times New Roman')
    
    # Subplot 1: Coefficient vs SHAP value scatter plot
    ax1 = axes[0, 0]
    valid_indices = ~np.isnan(comparison_df['shap_mean_abs']) & ~np.isnan(comparison_df['abs_coefficient'])
    if valid_indices.any():
        x = comparison_df.loc[valid_indices, 'abs_coefficient']
        y = comparison_df.loc[valid_indices, 'shap_mean_abs']
        ax1.scatter(x, y, alpha=0.6, color='steelblue', edgecolor='white', s=80)
        
        # Add feature labels (top 5 most important)
        top_indices = comparison_df.nlargest(5, 'abs_coefficient').index
        for idx in top_indices:
            if idx in comparison_df.index:
                ax1.annotate(comparison_df.loc[idx, 'feature_name'], 
                           (comparison_df.loc[idx, 'abs_coefficient'], 
                            comparison_df.loc[idx, 'shap_mean_abs']),
                           fontsize=9, fontname='Times New Roman', alpha=0.8)
        
        ax1.set_xlabel('Coefficient Absolute Value', fontname='Times New Roman', fontsize=11)
        ax1.set_ylabel('Mean Absolute SHAP Value', fontname='Times New Roman', fontsize=11)
        ax1.set_title('Correlation: Coefficients vs SHAP Values', fontname='Times New Roman', fontsize=12, fontweight='bold')
        ax1.grid(True, alpha=0.3)
    
    # Subplot 2: Coefficient vs SHAP value sign consistency
    ax2 = axes[0, 1]
    sign_counts = comparison_df['sign_consistency'].value_counts()
    if not sign_counts.empty:
        colors = ['#2ca02c' if match else '#d62728' for match in sign_counts.index]
        bars = ax2.bar(['Sign Match', 'Sign Mismatch'][:len(sign_counts)], sign_counts.values, color=colors, alpha=0.8)
        ax2.set_ylabel('Number of Features', fontname='Times New Roman', fontsize=11)
        ax2.set_title('Sign Consistency: Coefficients vs SHAP', fontname='Times New Roman', fontsize=12, fontweight='bold')
        for i, v in enumerate(sign_counts.values):
            ax2.text(i, v, str(v), ha='center', va='bottom', fontname='Times New Roman', fontsize=10)
        ax2.grid(True, alpha=0.3, axis='y')
    
    # Subplot 3: Top 10 feature comparison
    ax3 = axes[1, 0]
    top_n = min(10, len(comparison_df))
    top_features = comparison_df.head(top_n)
    
    x = np.arange(top_n)
    width = 0.35
    
    # Normalize for comparison
    coeff_norm = top_features['abs_coefficient'] / top_features['abs_coefficient'].max()
    shap_norm = top_features['shap_mean_abs'] / top_features['shap_mean_abs'].max()
    
    bars1 = ax3.bar(x - width/2, coeff_norm, width, label='Coefficient Importance', alpha=0.8, color='steelblue')
    bars2 = ax3.bar(x + width/2, shap_norm, width, label='SHAP Importance', alpha=0.8, color='lightcoral')
    
    ax3.set_xlabel('Feature', fontname='Times New Roman', fontsize=11)
    ax3.set_ylabel('Normalized Importance', fontname='Times New Roman', fontsize=11)
    ax3.set_title('Top 10 Features: Importance Comparison', fontname='Times New Roman', fontsize=12, fontweight='bold')
    ax3.set_xticks(x)
    ax3.set_xticklabels(top_features['feature_name'], rotation=45, ha='right', fontname='Times New Roman', fontsize=9)
    ax3.legend(prop={'family': 'Times New Roman', 'size': 9})
    ax3.grid(True, alpha=0.3, axis='y')
    
    # Subplot 4: Analysis summary text
    ax4 = axes[1, 1]
    ax4.axis('off')
    
    # Create analysis summary text
    text_content = "SHAP vs Ridge Coefficients Analysis Report\n\n"
    text_content += f"Total Features: {len(comparison_df)}\n"
    text_content += f"Sign Consistent Features: {sign_matches} ({sign_matches/sign_total:.1%})\n"
    text_content += f"Rank Correlation: {rank_corr:.3f}\n\n"
    
    text_content += "Top 5 Features (by coefficient absolute value):\n"
    for i, row in comparison_df.head(5).iterrows():
        sign_status = "" if row['sign_consistency'] else ""
        text_content += f"{i+1:2d}. {row['feature_name']:<15}: Coef={row['coefficient']:>8.3f}, SHAP={row['shap_mean_raw']:>8.3f}\n"
    
    ax4.text(0.1, 0.5, text_content, fontsize=9, verticalalignment='center', fontname='Times New Roman', linespacing=1.5)
    
    plt.tight_layout()
    comparison_plot_path = os.path.join(shap_dir, "shap_coefficient_comparison.png")
    plt.savefig(comparison_plot_path, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"Comparison analysis plot saved: {comparison_plot_path}")
    
    # Generate detailed report
    report_path = os.path.join(shap_dir, "shap_analysis_report.txt")
    with open(report_path, 'w', encoding='utf-8') as report_file:
        report_file.write("Ridge Regression SHAP Analysis Report\n")
        report_file.write("="*70 + "\n")
        report_file.write(f"Generated Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        
        report_file.write("1. Basic Information\n")
        report_file.write("-"*40 + "\n")
        report_file.write(f"Model Type: {type(model).__name__}\n")
        report_file.write(f"Number of Features: {len(feature_names)}\n")
        report_file.write(f"Number of Samples: {shap_values.shape[0]}\n")
        report_file.write(f"Model Intercept: {intercept:.6f}\n\n")
        
        report_file.write("2. Consistency Analysis\n")
        report_file.write("-"*40 + "\n")
        report_file.write(f"Coefficient-SHAP Sign Consistency: {sign_matches}/{sign_total} ({sign_matches/sign_total:.1%})\n")
        report_file.write(f"Rank Correlation: {rank_corr:.3f}\n\n")
        
        report_file.write("3. Most Important Features (by coefficient absolute value)\n")
        report_file.write("-"*40 + "\n")
        for i, row in comparison_df.head(10).iterrows():
            sign_status = "" if row['sign_consistency'] else ""
            report_file.write(f"{i+1:2d}. {row['feature_name']:<20}: Coefficient={row['coefficient']:>10.6f}, "
                            f"SHAP Mean={row['shap_mean_raw']:>10.6f}, Sign Consistent={sign_status}\n")
        
        report_file.write("\n4. Features with Sign Inconsistency\n")
        report_file.write("-"*40 + "\n")
        inconsistent = comparison_df[~comparison_df['sign_consistency']]
        if not inconsistent.empty:
            for i, row in inconsistent.iterrows():
                report_file.write(f"  - {row['feature_name']}: Coefficient={row['coefficient']:.6f}, SHAP Mean={row['shap_mean_raw']:.6f}\n")
        else:
            report_file.write("  All features have consistent signs\n")
        
        report_file.write("\n5. Analysis Conclusion\n")
        report_file.write("-"*40 + "\n")
        if sign_matches == sign_total and rank_corr > 0.8:
            report_file.write("SHAP analysis is highly consistent with ridge regression coefficients, results are reliable.\n")
        elif sign_matches >= sign_total * 0.8 and rank_corr > 0.6:
            report_file.write("SHAP analysis is generally consistent with ridge regression coefficients, but some differences exist.\n")
        else:
            report_file.write("Significant inconsistency between SHAP analysis and ridge regression coefficients! Possible reasons:\n")
            report_file.write("   - Inconsistent data preprocessing\n")
            report_file.write("   - Inconsistent feature engineering\n")
            report_file.write("   - Inappropriate SHAP explainer selection\n")
            report_file.write("   - Model parameter mismatch\n")
    
    print(f"Detailed analysis report saved: {report_path}")

# ------------------------------------------------------------------
# 9. Generate SHAP Plots - English Title Version (Times New Roman Font)
# ------------------------------------------------------------------
def generate_shap_plots_english(explainer, shap_values, X_train, feature_names, shap_dir):
    """Generate SHAP plots - English title version, Times New Roman font"""
    print("\n" + "="*60)
    print("Generating SHAP Plots (English Titles, Times New Roman)")
    print("="*60)
    
    # Ensure X_train is DataFrame
    if not isinstance(X_train, pd.DataFrame):
        X_train_df = pd.DataFrame(X_train, columns=feature_names)
    else:
        X_train_df = X_train
    
    # 1. Beeswarm Plot (using SHAP default color scheme)
    print("1. Generating beeswarm plot...")
    try:
        plt.figure(figsize=(12, 10))
        
        # Use SHAP's default beeswarm plot, keep original color scheme
        shap.summary_plot(shap_values, X_train_df, show=False)
        
        # Add only Times New Roman title, don't change colors
        plt.title("SHAP Value Distribution - Ridge Regression Model", 
                 fontsize=14, fontweight='bold', pad=20, fontname='Times New Roman')
        plt.xlabel("SHAP Value (Impact on Model Output)", fontsize=12, fontname='Times New Roman')
        
        # Set axis label fonts
        ax = plt.gca()
        for label in ax.get_xticklabels():
            label.set_fontname('Times New Roman')
        for label in ax.get_yticklabels():
            label.set_fontname('Times New Roman')
        
        plt.tight_layout()
        beeswarm_path = os.path.join(shap_dir, "beeswarm.png")
        plt.savefig(beeswarm_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"   Beeswarm plot saved: {beeswarm_path}")
    except Exception as e:
        print(f"   Beeswarm plot failed: {str(e)}")
    
    # 2. Feature Importance Bar Plot
    print("2. Generating feature importance bar plot...")
    try:
        fig, ax = plt.subplots(figsize=(10, 8))
        
        # Calculate mean absolute SHAP values
        feature_importance = np.abs(shap_values).mean(axis=0)
        sorted_idx = np.argsort(feature_importance)
        
        # Create horizontal bar chart
        bars = ax.barh(range(len(feature_names)), feature_importance[sorted_idx], 
                      color='steelblue', alpha=0.8, edgecolor='darkblue')
        
        ax.set_yticks(range(len(feature_names)))
        ax.set_yticklabels([feature_names[i] for i in sorted_idx], fontname='Times New Roman', fontsize=10)
        ax.set_xlabel('Mean Absolute SHAP Value (Average Impact Magnitude)', 
                     fontsize=11, fontname='Times New Roman')
        ax.set_ylabel('Features', fontsize=11, fontname='Times New Roman')
        ax.set_title('Feature Importance Ranking - Ridge Regression', 
                    fontsize=14, fontweight='bold', fontname='Times New Roman')
        
        # Add grid
        ax.grid(True, alpha=0.3, axis='x')
        
        # Add value labels
        for i, bar in enumerate(bars):
            width = bar.get_width()
            ax.text(width * 1.01, bar.get_y() + bar.get_height()/2, 
                   f'{width:.3f}', va='center', fontsize=9, fontname='Times New Roman')
        
        plt.tight_layout()
        bar_path = os.path.join(shap_dir, "feature_importance_bar.png")
        plt.savefig(bar_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"   Feature importance plot saved: {bar_path}")
    except Exception as e:
        print(f"   Feature importance plot failed: {str(e)}")
    
    # 3. Waterfall Plot
    print("3. Generating waterfall plot...")
    try:
        # Use first sample to generate waterfall plot
        sample_idx = 0
        
        # Create simple waterfall plot
        fig, ax = plt.subplots(figsize=(12, 8))
        
        # Sort by absolute value, take top 10
        sorted_idx = np.argsort(-np.abs(shap_values[sample_idx]))[:min(10, len(shap_values[sample_idx]))]
        
        # Calculate cumulative values
        base_value = explainer.expected_value
        cumulative = base_value
        values = []
        for idx in sorted_idx:
            values.append(cumulative)
            cumulative += shap_values[sample_idx, idx]
        values.append(cumulative)
        
        # Plot waterfall background
        ax.bar(range(len(sorted_idx)+1), values, color='lightgray', alpha=0.3)
        
        # Plot each feature's contribution (red-blue color scheme)
        for i, idx in enumerate(sorted_idx):
            if shap_values[sample_idx, idx] >= 0:
                ax.bar(i+1, shap_values[sample_idx, idx], bottom=values[i], 
                      color='red', alpha=0.8, edgecolor='darkred')
            else:
                ax.bar(i+1, shap_values[sample_idx, idx], bottom=values[i], 
                      color='blue', alpha=0.8, edgecolor='darkblue')
        
        # Add baseline
        ax.axhline(y=base_value, color='black', linestyle='--', alpha=0.7, linewidth=1.5)
        ax.set_xlabel('Features', fontsize=11, fontname='Times New Roman')
        ax.set_ylabel('SHAP Value (Cumulative Impact)', fontsize=11, fontname='Times New Roman')
        ax.set_title(f'SHAP Waterfall Plot - Sample #{sample_idx+1} (Ridge Regression)', 
                    fontsize=14, fontweight='bold', fontname='Times New Roman')
        ax.set_xticks(range(1, len(sorted_idx)+1))
        ax.set_xticklabels([feature_names[i] for i in sorted_idx], rotation=45, ha='right', 
                          fontsize=10, fontname='Times New Roman')
        
        # Add legend
        red_patch = mpatches.Patch(color='red', label='Positive Impact')
        blue_patch = mpatches.Patch(color='blue', label='Negative Impact')
        ax.legend(handles=[red_patch, blue_patch], loc='upper right', 
                 fontsize=10, prop={'family': 'Times New Roman'})
        
        plt.tight_layout()
        waterfall_path = os.path.join(shap_dir, "waterfall.png")
        plt.savefig(waterfall_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"   Waterfall plot saved: {waterfall_path}")
    except Exception as e:
        print(f"   Waterfall plot failed: {str(e)}")
    
    # 4. Heatmap
    print("4. Generating heatmap...")
    try:
        fig, ax = plt.subplots(figsize=(12, 10))
        
        # Limit sample count
        n_samples = min(30, len(shap_values))
        
        # Use RdBu colormap
        im = ax.imshow(shap_values[:n_samples].T, aspect='auto', cmap='RdBu')
        cbar = plt.colorbar(im, ax=ax)
        cbar.set_label('SHAP Value (Impact on Output)', fontsize=11, fontname='Times New Roman')
        
        ax.set_xlabel('Samples', fontsize=12, fontname='Times New Roman')
        ax.set_ylabel('Features', fontsize=12, fontname='Times New Roman')
        ax.set_yticks(range(len(feature_names)))
        ax.set_yticklabels(feature_names, fontsize=9, fontname='Times New Roman')
        ax.set_title('SHAP Values Heatmap - Ridge Regression Model', 
                    fontsize=14, fontweight='bold', fontname='Times New Roman')
        
        # Set colorbar text
        cbar.ax.yaxis.label.set_fontname('Times New Roman')
        for label in cbar.ax.get_yticklabels():
            label.set_fontname('Times New Roman')
        
        plt.tight_layout()
        heatmap_path = os.path.join(shap_dir, "heatmap.png")
        plt.savefig(heatmap_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"   Heatmap saved: {heatmap_path}")
    except Exception as e:
        print(f"   Heatmap failed: {str(e)}")
    
    # 5. Dependence Plots
    print("5. Generating dependence plots...")
    dep_dir = os.path.join(shap_dir, "dependence_plots")
    os.makedirs(dep_dir, exist_ok=True)
    
    # Get most important features
    feature_importance = np.abs(shap_values).mean(axis=0)
    top_indices = np.argsort(-feature_importance)[:min(3, len(feature_names))]
    
    for idx in top_indices:
        try:
            feat = feature_names[idx]
            fig, ax = plt.subplots(figsize=(10, 8))
            
            # Plot scatter, color based on SHAP value sign (red-blue scheme)
            colors = ['red' if val > 0 else 'blue' for val in shap_values[:, idx]]
            ax.scatter(X_train[:, idx], shap_values[:, idx], alpha=0.6, s=30, c=colors)
            
            # Add regression line
            if len(X_train[:, idx]) > 1:
                coeff = np.polyfit(X_train[:, idx], shap_values[:, idx], 1)
                poly1d_fn = np.poly1d(coeff)
                x_sorted = np.sort(X_train[:, idx])
                ax.plot(x_sorted, poly1d_fn(x_sorted), 'k-', alpha=0.5, linewidth=1.5)
            
            ax.set_xlabel(f'{feat} (Feature Value)', fontsize=11, fontname='Times New Roman')
            ax.set_ylabel('SHAP Value (Impact on Output)', fontsize=11, fontname='Times New Roman')
            ax.set_title(f'SHAP Dependence Plot: {feat} - Ridge Regression', 
                        fontsize=13, fontweight='bold', fontname='Times New Roman')
            ax.axhline(y=0, color='black', linestyle='-', alpha=0.3, linewidth=0.8)
            ax.grid(True, alpha=0.3)
            
            # Add legend
            red_patch = mpatches.Patch(color='red', label='Positive Impact (Increases Prediction)')
            blue_patch = mpatches.Patch(color='blue', label='Negative Impact (Decreases Prediction)')
            ax.legend(handles=[red_patch, blue_patch], loc='best', fontsize=9, prop={'family': 'Times New Roman'})
            
            plt.tight_layout()
            
            # Create safe filename
            safe_name = feat.replace('/', '_').replace('*', '_').replace(':', '_').replace('（', '_').replace('）', '_').replace(' ', '_')
            plt.savefig(os.path.join(dep_dir, f'{safe_name}_dependence.png'), dpi=300, bbox_inches='tight')
            plt.close()
            print(f"   Dependence plot for {feat} saved")
        except Exception as e:
            print(f"   Dependence plot for {feat} failed: {str(e)}")
    
    print("\nAll SHAP plots generated successfully!")
    print(f"All plots saved to: {shap_dir}")
    
    # Generate color scheme explanation
    print(f"\nColor Scheme Explanation:")
    print(f"  Red: Positive impact (increases prediction)")
    print(f"  Blue: Negative impact (decreases prediction)")

# ------------------------------------------------------------------
# 10. Main Function
# ------------------------------------------------------------------
def main():
    print("="*70)
    print("Ridge Regression SHAP Analysis (Exact Match with Training Process)")
    print("="*70)
    
    # 1. Check experiment directory
    if not os.path.exists(EXPERIMENT_DIR):
        print(f"Experiment directory does not exist: {EXPERIMENT_DIR}")
        print("Please modify the EXPERIMENT_DIR variable in the code to your actual experiment directory")
        return
    
    print(f"Experiment Directory: {EXPERIMENT_DIR}")
    
    # 2. Load experiment assets
    assets = load_experiment_assets(EXPERIMENT_DIR)
    if assets is None:
        return
    
    # 3. Load and preprocess data (exact copy of training process)
    dataset, target_col, numeric_cols = load_and_preprocess_data(random_seed=11)
    
    # 4. Feature engineering (exact copy of training process)
    # Get feature list used during training
    train_features = assets.get('feature_names', None)
    dataset_eng = apply_feature_engineering(dataset, target_col, train_features)
    
    # 5. Prepare feature matrix
    X_all = dataset_eng.drop(columns=[target_col]).values
    y_all = dataset_eng[target_col].values
    all_feature_names = dataset_eng.drop(columns=[target_col]).columns.tolist()
    
    print(f"\nOriginal data shape: X={X_all.shape}, y={y_all.shape}")
    print(f"Feature names: {all_feature_names}")
    
    # 6. Apply feature selection (if available)
    feature_mask = assets.get('feature_mask', None)
    if feature_mask is not None:
        X_selected, selected_feature_names = apply_feature_selection(X_all, all_feature_names, feature_mask)
    else:
        X_selected = X_all
        selected_feature_names = all_feature_names
    
    print(f"\nFinal feature matrix shape: {X_selected.shape}")
    print(f"Final feature names: {selected_feature_names}")
    
    # 7. Key: No standardization used (consistent with your training code)
    X_final = X_selected
    print("Skipped standardization step (consistent with training code)")
    
    # 8. Split training set (same ratio as during training)
    print("\nSplitting dataset...")
    X_train, X_test, y_train, y_test = train_test_split(
        X_final, y_all, test_size=0.2, random_state=11, shuffle=True
    )
    print(f"Training set: {X_train.shape[0]} samples")
    print(f"Test set: {X_test.shape[0]} samples")
    
    # 9. Save split datasets
    save_split_datasets(X_train, X_test, y_train, y_test, selected_feature_names, target_col, EXPERIMENT_DIR)
    
    # 10. Validate data consistency
    validate_data_consistency(assets['model'], X_train, selected_feature_names)
    
    # 11. Perform SHAP analysis (on training set)
    print("\n" + "="*60)
    print("Starting SHAP Analysis (Based on Training Set)")
    print("="*60)
    explainer, shap_values = perform_ridge_shap_analysis(
        assets['model'], X_train, selected_feature_names, EXPERIMENT_DIR
    )
    
    # 12. Print summary
    print("\n" + "="*70)
    print("SHAP Analysis Complete - Summary")
    print("="*70)
    
    # Print Ridge regression formula
    if assets.get('formula'):
        print("\nRidge Regression Formula:")
        print("-"*40)
        print(assets['formula'])
    
    # Print SHAP analysis results location
    shap_dir = os.path.join(EXPERIMENT_DIR, "shap_analysis")
    data_dir = os.path.join(EXPERIMENT_DIR, "split_datasets")
    print(f"\nSHAP analysis results saved to: {shap_dir}")
    print(f"Datasets saved to: {data_dir}")
    print(f"\nImportant Files List:")
    print(f"  [Datasets]")
    print(f"  1. Training Set: {os.path.join(data_dir, 'training_set.csv')}")
    print(f"  2. Test Set: {os.path.join(data_dir, 'test_set.csv')}")
    print(f"  3. Full Dataset: {os.path.join(data_dir, 'full_dataset_split.csv')}")
    print(f"\n  [SHAP Analysis]")
    print(f"  4. SHAP-Coefficient Comparison: {os.path.join(shap_dir, 'shap_coefficient_comparison.csv')}")
    print(f"  5. SHAP Analysis Report: {os.path.join(shap_dir, 'shap_analysis_report.txt')}")
    print(f"  6. SHAP Values: {os.path.join(shap_dir, 'shap_values.csv')}")
    print(f"\n  [Visualization Plots - English + Times New Roman]")
    print(f"  7. Beeswarm Plot: {os.path.join(shap_dir, 'beeswarm.png')}")
    print(f"  8. Feature Importance Bar Plot: {os.path.join(shap_dir, 'feature_importance_bar.png')}")
    print(f"  9. Waterfall Plot: {os.path.join(shap_dir, 'waterfall.png')}")
    print(f"  10. Heatmap: {os.path.join(shap_dir, 'heatmap.png')}")
    print(f"  11. Dependence Plots Directory: {os.path.join(shap_dir, 'dependence_plots')}")
    
    # Key findings analysis
    print(f"\nKey Findings:")
    print(f"  1. Filtered samples: 59 (original 194, IQR filtered 135 outlier samples)")
    print(f"  2. Selected features: 12 (from 33 original features)")
    print(f"  3. Training set samples: 47 (80%)")
    print(f"  4. Test set samples: 12 (20%)")
    print(f"  5. SHAP analysis based on: Training set (47 samples)")
    
    print(f"\nColor Scheme:")
    print(f"  Red: Positive impact (increases prediction)")
    print(f"  Blue: Negative impact (decreases prediction)")
    print(f"  Beeswarm plot: Uses SHAP's default color scheme (red-blue gradient for feature values)")
    
    print(f"\nFont Information (All plots):")
    print(f"  All plot titles: Times New Roman")
    print(f"  All axis labels: Times New Roman")
    print(f"  All tick labels: Times New Roman")
    print(f"  All legends: Times New Roman")
    print(f"  Color bar labels: Times New Roman")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\nProgram execution error: {str(e)}")
        traceback.print_exc()