# -*- coding: utf-8 -*-
"""
Ridge Model SHAP Analysis Code (Compatible with your environment's SHAP API version)
- Use the same data preprocessing and feature selection as the modeling code
- Use SHAP official API for plotting
- All graphs use English titles
"""
import numpy as np
import pandas as pd
import joblib
import matplotlib.pyplot as plt
import os
import re
import shutil
from datetime import datetime
from sklearn.model_selection import train_test_split

# Try importing SHAP in various possible ways
try:
    import shap
    print(f"SHAP imported successfully")
    
    # Check available SHAP modules
    available_modules = []
    if hasattr(shap, 'LinearExplainer'):
        available_modules.append('LinearExplainer')
    if hasattr(shap, 'KernelExplainer'):
        available_modules.append('KernelExplainer')
    if hasattr(shap, 'Explainer'):
        available_modules.append('Explainer')
    if hasattr(shap, 'plots'):
        available_modules.append('plots')
    if hasattr(shap, 'summary_plot'):
        available_modules.append('summary_plot')
    
    print(f"Available SHAP modules: {available_modules}")
    
except ImportError as e:
    print(f"Failed to import SHAP: {e}")
    shap = None

# Configure matplotlib
plt.rcParams["figure.dpi"] = 300
plt.rcParams['font.size'] = 12
plt.rcParams['axes.unicode_minus'] = False

# ---------- 1. Configure Paths ----------
MODEL_PATH = os.path.join( "Ridge.pkl")  # Ridge model file path
FEATURE_FILE = os.path.join( "selected_features.txt")  # Feature file path
DATA_PATH = "T5%A1.xlsx"  # Data file path
TARGET_COLUMN = 'T5%(℃)'  # Target column name

# ---------- 2. Data Loading Function ----------
def load_data():
    df = pd.read_excel(DATA_PATH)
    target = TARGET_COLUMN
    if 'NO' in df.columns:
        df = df.drop(columns=['NO'])
    X = df.drop(columns=[target])
    y = df[target]
    return X.values, y, X.columns.tolist()

# ---------- 3. Load Model and Data ----------
def load_model_and_data(output_dir):
    # Check if files exist
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"Model file not found: {MODEL_PATH}")
    
    if not os.path.exists(DATA_PATH):
        raise FileNotFoundError(f"Data file not found: {DATA_PATH}")
    
    # Load model
    model = joblib.load(MODEL_PATH)
    print(f"Model loaded: {MODEL_PATH}")
    print(f"Model type: {type(model).__name__}")
    
    # Load complete data
    X_full, y_full, all_features = load_data()
    print(f"Data loaded: {DATA_PATH}, total samples: {X_full.shape[0]}")
    
    # Split training and test sets (fixed random seed 12345, consistent with modeling code)
    X_train, X_test, y_train, y_test = train_test_split(
        X_full, y_full, 
        test_size=0.2, 
        random_state=12345,
        shuffle=True
    )
    print(f"Training set: samples={X_train.shape[0]}, features={X_train.shape[1]}")
    
    # Save complete training set data
    train_df = pd.DataFrame(X_train, columns=all_features)
    train_df[TARGET_COLUMN] = y_train
    train_save_path = os.path.join(output_dir, "training_set_data.csv")
    train_df.to_csv(train_save_path, index=False, encoding="utf-8-sig")
    print(f"Training set data saved: {train_save_path}")
    
    # Get selected features
    if os.path.exists(FEATURE_FILE):
        print(f"Using feature file: {FEATURE_FILE}")
        with open(FEATURE_FILE, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        selected_features = []
        for line in lines:
            line = line.strip()
            if not line or "selected features" in line.lower():
                continue
            
            match = re.match(r'^\d+\.\s*(.+)$', line)
            if match:
                feature_name = match.group(1)
                selected_features.append(feature_name)
            else:
                selected_features.append(line)
        
        print(f"Features parsed from file: {selected_features}")
        
        # Validate feature effectiveness
        valid_features = [f for f in selected_features if f in all_features]
        invalid_features = [f for f in selected_features if f not in all_features]
        
        if invalid_features:
            print(f"Warning: The following features were not found in the training set and have been filtered: {invalid_features}")
        
        if not valid_features:
            raise ValueError("No valid features available after filtering")
            
        selected_features = valid_features
    else:
        print("Feature file not found, using all features from training set")
        selected_features = all_features
    
    # Create feature mask
    mask = [feature in selected_features for feature in all_features]
    print(f"Number of selected features: {sum(mask)}")
    
    # Extract selected features from training set
    X_train_sel = X_train[:, mask]
    
    # Save training set data with selected features
    selected_train_df = pd.DataFrame(X_train_sel, columns=selected_features)
    selected_train_df[TARGET_COLUMN] = y_train
    selected_train_save_path = os.path.join(output_dir, "training_set_selected_features.csv")
    selected_train_df.to_csv(selected_train_save_path, index=False, encoding="utf-8-sig")
    print(f"Selected training set data saved: {selected_train_save_path}")
    
    return model, X_train_sel, selected_features, X_train_sel

# ---------- 4. Analysis using compatible SHAP version ----------
def shap_analysis_compatible(model, X_train, feat_names, output_dir):
    """
    Analysis using SHAP API compatible with your environment
    """
    print("\n" + "="*60)
    print("SHAP Analysis (Compatible Version)")
    print("="*60)
    
    if shap is None:
        print("SHAP not installed or import failed")
        return None, None
    
    # 1. Create explainer
    print("  1. Creating SHAP explainer...")
    
    try:
        # First try LinearExplainer (preferred for linear models)
        if hasattr(shap, 'LinearExplainer'):
            explainer = shap.LinearExplainer(model, X_train)
            print("    Using LinearExplainer")
        else:
            # If LinearExplainer is not available, try KernelExplainer
            if hasattr(shap, 'KernelExplainer'):
                explainer = shap.KernelExplainer(model.predict, X_train)
                print("    Using KernelExplainer")
            else:
                # Finally try generic Explainer
                if hasattr(shap, 'Explainer'):
                    explainer = shap.Explainer(model.predict, X_train)
                    print("    Using Generic Explainer")
                else:
                    print("    No available SHAP explainers")
                    return None, None
    except Exception as e:
        print(f"    Failed to create explainer: {e}")
        return None, None
    
    # 2. Calculate SHAP values
    print("  2. Calculating SHAP values...")
    try:
        shap_values = explainer.shap_values(X_train)
        print(f"    SHAP values calculated, shape: {np.array(shap_values).shape}")
    except Exception as e:
        print(f"    Failed to calculate SHAP values: {e}")
        return None, None
    
    # 3. Save SHAP values
    print("  3. Saving SHAP values...")
    shap_df = pd.DataFrame(shap_values, columns=feat_names)
    shap_df.to_csv(os.path.join(output_dir, "shap_values.csv"), index=False, encoding="utf-8-sig")
    
    # 4. Generate SHAP plots
    print("  4. Generating SHAP plots...")
    
    # Ensure X_train is DataFrame
    X_train_df = pd.DataFrame(X_train, columns=feat_names)
    
    # (1) Beeswarm Plot
    try:
        print("    Generating beeswarm plot...")
        fig, ax = plt.subplots(figsize=(12, 10))
        
        # Use method from your code
        if hasattr(shap, 'summary_plot'):
            shap.summary_plot(shap_values, X_train_df, show=False)
            # Add custom title
            ax.set_title("SHAP Value Distribution - Ridge Regression Model", 
                        fontsize=14, fontweight='bold', pad=20)
            ax.set_xlabel("SHAP Value (Impact on Model Output)", fontsize=12)
            ax.set_ylabel("Features", fontsize=12)
        else:
            # Alternative method
            shap_mean = np.abs(shap_values).mean(axis=0)
            sorted_idx = np.argsort(shap_mean)[::-1]
            
            for i, idx in enumerate(sorted_idx):
                y_pos = np.random.normal(i, 0.15, shap_values.shape[0])
                colors = ['red' if val > 0 else 'blue' for val in shap_values[:, idx]]
                ax.scatter(shap_values[:, idx], y_pos, alpha=0.5, s=20, c=colors)
            
            ax.set_yticks(range(len(sorted_idx)))
            ax.set_yticklabels([feat_names[i] for i in sorted_idx])
            ax.set_xlabel('SHAP Value (Impact on Model Output)', fontsize=12)
            ax.set_ylabel('Features', fontsize=12)
            ax.set_title('SHAP Value Distribution - Ridge Regression Model', 
                        fontsize=14, fontweight='bold')
            ax.axvline(x=0, color='black', linestyle='-', alpha=0.3, linewidth=0.8)
        
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'beeswarm.png'), dpi=300, bbox_inches='tight')
        plt.close()
        print("      Beeswarm plot saved")
    except Exception as e:
        print(f"      Beeswarm plot generation failed: {e}")
    
    # (2) Feature Importance Bar Plot
    try:
        print("    Generating feature importance bar plot...")
        fig, ax = plt.subplots(figsize=(10, 8))
        
        # Calculate mean absolute SHAP values
        feature_importance = np.abs(shap_values).mean(axis=0)
        sorted_idx = np.argsort(feature_importance)
        
        bars = ax.barh(range(len(feat_names)), feature_importance[sorted_idx], 
                      color='steelblue', alpha=0.8)
        
        ax.set_yticks(range(len(feat_names)))
        ax.set_yticklabels([feat_names[i] for i in sorted_idx])
        ax.set_xlabel('Mean Absolute SHAP Value (Average Impact Magnitude)', 
                     fontsize=11)
        ax.set_ylabel('Features', fontsize=11)
        ax.set_title('Feature Importance Ranking - Ridge Regression', 
                    fontsize=14, fontweight='bold')
        
        # Add grid
        ax.grid(True, alpha=0.3, axis='x')
        
        # Add value labels
        for i, bar in enumerate(bars):
            width = bar.get_width()
            ax.text(width * 1.01, bar.get_y() + bar.get_height()/2, 
                   f'{width:.3f}', va='center', fontsize=9)
        
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'feature_importance.png'), dpi=300, bbox_inches='tight')
        plt.close()
        print("      Feature importance plot saved")
    except Exception as e:
        print(f"      Feature importance plot generation failed: {e}")
    
    # (3) Waterfall Plot
    try:
        print("    Generating waterfall plot...")
        sample_idx = 0
        
        # Try using SHAP's waterfall plot
        if hasattr(shap, 'plots') and hasattr(shap.plots, 'waterfall'):
            try:
                # Create Explanation object
                explanation = shap.Explanation(
                    values=shap_values[sample_idx],
                    base_values=explainer.expected_value,
                    data=X_train_df.iloc[sample_idx].values,
                    feature_names=feat_names
                )
                
                fig, ax = plt.subplots(figsize=(12, 8))
                shap.plots.waterfall(explanation, show=False)
                # Add custom title
                ax.set_title(f'SHAP Waterfall Plot - Sample #{sample_idx+1} (Ridge Regression)', 
                           fontsize=14, fontweight='bold', pad=20)
                
                plt.tight_layout()
                plt.savefig(os.path.join(output_dir, 'waterfall.png'), dpi=300, bbox_inches='tight')
                plt.close()
            except:
                # If failed, use simple waterfall plot
                create_simple_waterfall(shap_values[sample_idx], feat_names, 
                                       explainer.expected_value, output_dir)
        else:
            # Use simple waterfall plot
            create_simple_waterfall(shap_values[sample_idx], feat_names, 
                                   explainer.expected_value, output_dir)
        
        print("      Waterfall plot saved")
    except Exception as e:
        print(f"      Waterfall plot generation failed: {e}")
    
    # (4) Heatmap
    try:
        print("    Generating heatmap...")
        fig, ax = plt.subplots(figsize=(12, 10))
        
        # Limit number of samples
        n_samples = min(30, len(shap_values))
        
        # Use matplotlib to plot directly
        im = ax.imshow(shap_values[:n_samples].T, aspect='auto', cmap='RdBu')
        cbar = plt.colorbar(im, ax=ax)
        cbar.set_label('SHAP Value (Impact on Output)', fontsize=11)
        
        ax.set_xlabel('Samples', fontsize=12)
        ax.set_ylabel('Features', fontsize=12)
        ax.set_yticks(range(len(feat_names)))
        ax.set_yticklabels(feat_names, fontsize=10)
        ax.set_title('SHAP Values Heatmap - Ridge Regression Model', 
                    fontsize=14, fontweight='bold')
        
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'heatmap.png'), dpi=300, bbox_inches='tight')
        plt.close()
        print("      Heatmap saved")
    except Exception as e:
        print(f"      Heatmap generation failed: {e}")
    
    # (5) Dependence Plots
    print("    Generating dependence plots...")
    dep_dir = os.path.join(output_dir, 'dependence_plots')
    os.makedirs(dep_dir, exist_ok=True)
    
    # Get most important features
    feature_importance = np.abs(shap_values).mean(axis=0)
    top_indices = np.argsort(-feature_importance)[:min(3, len(feat_names))]
    
    for idx in top_indices:
        try:
            feat = feat_names[idx]
            fig, ax = plt.subplots(figsize=(10, 8))
            
            # Plot scatter
            colors = ['red' if val > 0 else 'blue' for val in shap_values[:, idx]]
            ax.scatter(X_train[:, idx], shap_values[:, idx], alpha=0.6, s=30, c=colors)
            
            # Add regression line
            if len(X_train[:, idx]) > 1:
                coeff = np.polyfit(X_train[:, idx], shap_values[:, idx], 1)
                poly1d_fn = np.poly1d(coeff)
                x_sorted = np.sort(X_train[:, idx])
                ax.plot(x_sorted, poly1d_fn(x_sorted), 'k-', alpha=0.5, linewidth=1.5)
            
            ax.set_xlabel(f'{feat} (Feature Value)', fontsize=11)
            ax.set_ylabel('SHAP Value (Impact on Output)', fontsize=11)
            ax.set_title(f'SHAP Dependence Plot: {feat} - Ridge Regression', 
                        fontsize=13, fontweight='bold')
            ax.axhline(y=0, color='black', linestyle='-', alpha=0.3, linewidth=0.8)
            ax.grid(True, alpha=0.3)
            
            # Add legend
            import matplotlib.patches as mpatches
            red_patch = mpatches.Patch(color='red', label='Positive Impact (Increases Prediction)')
            blue_patch = mpatches.Patch(color='blue', label='Negative Impact (Decreases Prediction)')
            ax.legend(handles=[red_patch, blue_patch], loc='best', fontsize=9)
            
            plt.tight_layout()
            
            safe = re.sub(r'[\\/*?:"<>|]', "_", feat)
            plt.savefig(os.path.join(dep_dir, f'{safe}_dependence.png'), dpi=300, bbox_inches='tight')
            plt.close()
            print(f"      Dependence plot for {feat} saved")
        except Exception as e:
            print(f"      Dependence plot for {feat} generation failed: {e}")
    
    print(f"    Dependence plots saved to: {dep_dir}")
    
    return shap_values, dep_dir

def create_simple_waterfall(shap_vals, feat_names, base_value, output_dir):
    """Create simple waterfall plot"""
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # Sort by absolute value, take top 10
    sorted_idx = np.argsort(-np.abs(shap_vals))[:min(10, len(shap_vals))]
    
    # Calculate cumulative values
    cumulative = base_value
    values = []
    for idx in sorted_idx:
        values.append(cumulative)
        cumulative += shap_vals[idx]
    values.append(cumulative)
    
    # Plot waterfall
    ax.bar(range(len(sorted_idx)+1), values, color='lightgray', alpha=0.3)
    for i, idx in enumerate(sorted_idx):
        if shap_vals[idx] >= 0:
            ax.bar(i+1, shap_vals[idx], bottom=values[i], color='red', alpha=0.8, edgecolor='darkred')
        else:
            ax.bar(i+1, shap_vals[idx], bottom=values[i], color='blue', alpha=0.8, edgecolor='darkblue')
    
    ax.axhline(y=base_value, color='black', linestyle='--', alpha=0.7, linewidth=1.5)
    ax.set_xlabel('Features', fontsize=11)
    ax.set_ylabel('SHAP Value (Cumulative Impact)', fontsize=11)
    ax.set_title('SHAP Waterfall Plot - Ridge Regression (First Sample)', 
                fontsize=14, fontweight='bold')
    ax.set_xticks(range(1, len(sorted_idx)+1))
    ax.set_xticklabels([feat_names[i] for i in sorted_idx], rotation=45, ha='right', 
                      fontsize=10)
    
    # Add legend
    import matplotlib.patches as mpatches
    red_patch = mpatches.Patch(color='red', label='Positive Impact')
    blue_patch = mpatches.Patch(color='blue', label='Negative Impact')
    ax.legend(handles=[red_patch, blue_patch], loc='upper right', 
             fontsize=10)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'waterfall.png'), dpi=300, bbox_inches='tight')
    plt.close()

# ---------- 5. Main Function ----------
def main():
    print("=" * 60)
    print("Ridge Model SHAP Analysis")
    print("=" * 60)
    
    # Display current configuration
    print("Configuration Information:")
    print(f"Model path: {MODEL_PATH}")
    print(f"Data path: {DATA_PATH}")
    print(f"Feature file: {FEATURE_FILE}")
    print(f"Target column: {TARGET_COLUMN}")
    print("=" * 60)
    
    try:
        # Create output directory
        output_dir = f"shap_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        os.makedirs(output_dir, exist_ok=True)
        print(f"All results will be saved to: {output_dir}")
        
        # Load model and data
        model, X_train, feat_names, X_train_df = load_model_and_data(output_dir)
        print(f"Training set shape: {X_train.shape}")
        
        # Analysis using compatible SHAP API
        shap_values, dep_dir = shap_analysis_compatible(model, X_train, feat_names, output_dir)
        
        if shap_values is not None:
            # Calculate and save feature importance ranking
            feature_importance = np.abs(shap_values).mean(axis=0)
            sorted_idx = np.argsort(feature_importance)[::-1]
            imp_df = pd.DataFrame({
                "feature_name": [feat_names[i] for i in sorted_idx],
                "mean_abs_shap": feature_importance[sorted_idx],
                "rank": range(1, len(feat_names)+1)
            })
            imp_df.to_csv(os.path.join(output_dir, "feature_importance_ranking.csv"), index=False, encoding="utf-8-sig")
            
            print("\nTop 10 Feature Importance Ranking:")
            print("-" * 45)
            for i in range(min(10, len(feat_names))):
                idx = sorted_idx[i]
                print(f"  {i+1:2d}. {feat_names[idx]:20s} : {feature_importance[idx]:.4f}")
        
        # Save model basic information
        with open(os.path.join(output_dir, "model_info.txt"), "w", encoding="utf-8") as f:
            f.write(f"SHAP Analysis Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Model Path: {MODEL_PATH}\n")
            f.write(f"Data Path: {DATA_PATH}\n")
            f.write(f"Feature File: {FEATURE_FILE}\n")
            f.write(f"Model Type: {type(model).__name__}\n")
            f.write(f"Number of Features: {len(feat_names)}\n")
            f.write(f"Training Set Samples: {X_train.shape[0]}\n")
            f.write(f"Analysis Method: Compatible SHAP API\n")
            
            if hasattr(model, 'coef_'):
                coef = model.coef_.ravel()
                f.write(f"\nModel Coefficient Information:\n")
                f.write(f"Intercept: {model.intercept_ if hasattr(model, 'intercept_') else 0:.6f}\n")
                f.write(f"Maximum Coefficient: {coef.max():.6f}\n")
                f.write(f"Minimum Coefficient: {coef.min():.6f}\n")
                f.write(f"Mean Absolute Coefficient: {np.abs(coef).mean():.6f}\n")
        
        print(f"\nGenerated Files:")
        print("-" * 60)
        print(f"  1. Beeswarm Plot: {os.path.join(output_dir, 'beeswarm.png')}")
        print(f"  2. Feature Importance Bar Plot: {os.path.join(output_dir, 'feature_importance.png')}")
        print(f"  3. Waterfall Plot: {os.path.join(output_dir, 'waterfall.png')}")
        print(f"  4. Heatmap: {os.path.join(output_dir, 'heatmap.png')}")
        if dep_dir:
            print(f"  5. Dependence Plots Directory: {dep_dir}")
        print(f"  6. SHAP Values Data: {os.path.join(output_dir, 'shap_values.csv')}")
        print(f"  7. Feature Importance Ranking: {os.path.join(output_dir, 'feature_importance_ranking.csv')}")
        print(f"  8. Model Information: {os.path.join(output_dir, 'model_info.txt')}")
        
        print(f"\nColor Scheme Explanation:")
        print(f"  Red: Positive impact (increases prediction)")
        print(f"  Blue: Negative impact (decreases prediction)")
        
        print(f"\nSHAP analysis completed! All results saved to: {output_dir}")
        
    except Exception as e:
        print("[Error] ", e)
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()