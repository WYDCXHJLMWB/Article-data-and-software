# -*- coding: utf-8 -*-
"""
Inverse Design - Multi-Objective Optimization (Based on Relative Error)
Target: PHRR → 200 kW/m², T5% → 300°C
Using relative error loss function (dimensionless)
Supports resuming after interruption
"""

import numpy as np
import pandas as pd
import joblib
import warnings
import os
import re
from hyperopt import hp, tpe, fmin, Trials, STATUS_OK
from datetime import datetime

warnings.filterwarnings('ignore')

# ========== 1. Configuration ==========
TARGET_PHRR = 200.0      # Target PHRR (kW/m²)
TARGET_T5 = 300.0        # Target T5% (°C)
MAX_EVALS = 10000        # Total evaluation count

# Output files
RESULTS_PATH = 'inverse_design_results.csv'      # CSV history (for resuming)
RESULTS_XLSX = 'inverse_design_results.xlsx'     # Excel final results
VALIDATION_PATH = 'validation_predictions.csv'   # Validation set predictions

# Variable ranges
PP_MIN, PP_MAX = 60, 110
ADP_FIXED = 0.3

# Key components list
KEY_COMPONENTS = ['PP', 'PAPP', 'MPP', 'ADP', 'ZS', 'W']

VARIABLE_RANGES = {
    'PP': (60, 110),
    'PAPP': (19, 24),
    'MPP': (8.5, 14),
    'ZS': (0.4, 1.6),
    'W': (2.5, 9)
}

# ========== 2. Model paths (please modify according to actual situation) ==========
# PHRR model
PHRR_MODEL_PATH = r"C:\Users\ma'wei'bin\Desktop\聚合物复合材料机器学习 加工艺参数\热稳定性数据\6月新尝试\1113 - 副本\phrr - 0822\PHRR_experiment_20260424_144158增强\models\gradient_boosting_regressor_145248.pkl"
PHRR_FEATURES_PATH = r"C:\Users\ma'wei'bin\Desktop\聚合物复合材料机器学习 加工艺参数\热稳定性数据\6月新尝试\1113 - 副本\phrr - 0822\PHRR_experiment_20260424_144158增强\phrr_train_features.pkl"
PHRR_MASK_PATH = r"C:\Users\ma'wei'bin\Desktop\聚合物复合材料机器学习 加工艺参数\热稳定性数据\6月新尝试\1113 - 副本\phrr - 0822\PHRR_experiment_20260424_144158增强\feature_mask.npy"

# T5% model
T5_MODEL_PATH = r"C:\Users\ma'wei'bin\Desktop\聚合物复合材料机器学习 加工艺参数\热稳定性数据\6月新尝试\1113 - 副本\T5% -0901\ga_experiment_20260424_161900增强\final_iteration\models\MLP.pkl"
T5_FEATURES_PATH = r"C:\Users\ma'wei'bin\Desktop\聚合物复合材料机器学习 加工艺参数\热稳定性数据\6月新尝试\1113 - 副本\T5% -0901\ga_experiment_20260424_161900增强\final_iteration\selected_features.txt"

# Validation set path (optional)
VALIDATION_INPUT_PATH = r"C:\Users\ma'wei'bin\Desktop\聚合物复合材料机器学习 加工艺参数\热稳定性数据\6月新尝试\1113 - 副本\phrr - 0822\留出做实验验证的样本1.xlsx"

# ========== 3. Load models and features ==========
print("="*70)
print("Loading models and features...")
print("="*70)

# Load PHRR model
phrr_model = joblib.load(PHRR_MODEL_PATH)
print(f"PHRR model: {type(phrr_model).__name__}")

phrr_cols = joblib.load(PHRR_FEATURES_PATH)
print(f"PHRR features: {len(phrr_cols)}")

# Load feature mask (feature selection)
if os.path.exists(PHRR_MASK_PATH):
    feature_mask = np.load(PHRR_MASK_PATH, allow_pickle=True)
    sel_idx = [i for i, mask in enumerate(feature_mask) if mask and i < len(phrr_cols)]
    print(f"PHRR selected features: {len(sel_idx)}")
else:
    sel_idx = list(range(len(phrr_cols)))
    print(f"No feature mask found, using all {len(phrr_cols)} features")

# Load T5% model
t5_model = joblib.load(T5_MODEL_PATH)
print(f"T5 model: {type(t5_model).__name__}")

# Load T5% feature list
with open(T5_FEATURES_PATH, 'r', encoding='utf-8') as f:
    lines = f.readlines()

t5_selected_features = []
for line in lines:
    line = line.strip()
    if not line or "Selected features" in line or "选择的特征" in line:
        continue
    match = re.match(r'^\d+\.\s*(.+)$', line)
    if match:
        t5_selected_features.append(match.group(1))

print(f"T5 selected features: {len(t5_selected_features)}")
print(f"T5 features: {t5_selected_features[:10]}...")

# ========== 4. Feature engineering functions ==========
def feature_engineering_phrr(p, target_col=None):
    """PHRR feature engineering (consistent with training code)"""
    df = pd.DataFrame({k: [v] for k, v in p.items()})

    additive_cols = ['PAPP', 'MPP', 'W', 'ZS', 'ADP']
    existing_additive = [col for col in additive_cols if col in df.columns]
    if existing_additive:
        df['total_ad'] = df[existing_additive].sum(axis=1)
        max_val = df[existing_additive].max(axis=1)
        df['additive_ratio'] = df['total_ad'] / (max_val + 1e-6)
    else:
        df['total_ad'] = 0
        df['additive_ratio'] = 0

    if 'PAPP' in df.columns and 'total_ad' in df.columns:
        df['PAPP_ratio'] = df['PAPP'] / (df['total_ad'] + 1e-6)
    else:
        df['PAPP_ratio'] = 0

    if 'MPP' in df.columns and 'total_ad' in df.columns:
        df['MPP_ratio'] = df['MPP'] / (df['total_ad'] + 1e-6)
    else:
        df['MPP_ratio'] = 0

    synergist_cols = ['W', 'ZS', 'ADP']
    existing_synergist = [col for col in synergist_cols if col in df.columns]
    if existing_synergist:
        df['synergist_total'] = df[existing_synergist].sum(axis=1)
        if 'W' in df.columns:
            df['W_ratio_in_synergist'] = df['W'] / (df['synergist_total'] + 1e-6)
        else:
            df['W_ratio_in_synergist'] = 0
    else:
        df['synergist_total'] = 0
        df['W_ratio_in_synergist'] = 0

    if all(col in df.columns for col in ['PAPP', 'MPP', 'W']):
        df['PAPP_MPP_W_interaction'] = df['PAPP'] * df['MPP'] * df['W']
    else:
        df['PAPP_MPP_W_interaction'] = 0

    if 'PAPP' in df.columns:
        df['PAPP_square'] = df['PAPP'] ** 2
    else:
        df['PAPP_square'] = 0

    if 'MPP' in df.columns:
        df['MPP_square'] = df['MPP'] ** 2
    else:
        df['MPP_square'] = 0

    if all(col in df.columns for col in ['PAPP', 'MPP']):
        df['PAPP_MPP_ratio'] = df['PAPP'] / (df['MPP'] + 1e-6)
    else:
        df['PAPP_MPP_ratio'] = 0

    if all(col in df.columns for col in ['PAPP', 'W']):
        df['PAPP_W_ratio'] = df['PAPP'] / (df['W'] + 1e-6)
    else:
        df['PAPP_W_ratio'] = 0

    if 'PAPP' in df.columns:
        df['PAPP_sqrt'] = np.sqrt(df['PAPP'])
    else:
        df['PAPP_sqrt'] = 0

    if 'MPP' in df.columns:
        df['MPP_sqrt'] = np.sqrt(df['MPP'])
    else:
        df['MPP_sqrt'] = 0

    if all(col in df.columns for col in ['ZS', 'total_ad']):
        df['ZS_ratio'] = df['ZS'] / (df['total_ad'] + 1e-6)
    else:
        df['ZS_ratio'] = 0

    if all(col in df.columns for col in ['W', 'total_ad']):
        df['W_ratio'] = df['W'] / (df['total_ad'] + 1e-6)
    else:
        df['W_ratio'] = 0
        
    if all(col in df.columns for col in ['ADP', 'total_ad']):
        df['ADP_ratio'] = df['ADP'] / (df['total_ad'] + 1e-6)
    else:
        df['ADP_ratio'] = 0

    # Ensure all features used during training exist
    for feat in phrr_cols:
        if feat not in df.columns and feat != target_col:
            df[feat] = 0

    if target_col and target_col in df.columns:
        df = df.drop(columns=[target_col])

    return df


def predict_phrr(p):
    """Predict PHRR value"""
    df_eng = feature_engineering_phrr(p)
    
    x = np.zeros(len(phrr_cols))
    for i, feat in enumerate(phrr_cols):
        if feat in df_eng.columns:
            x[i] = df_eng[feat].iloc[0]
        else:
            x[i] = 0.0

    x = np.array([x])[:, sel_idx]

    # Ensure feature count matches
    if x.shape[1] != phrr_model.n_features_in_:
        if x.shape[1] > phrr_model.n_features_in_:
            x = x[:, :phrr_model.n_features_in_]
        else:
            padding = np.zeros((x.shape[0], phrr_model.n_features_in_ - x.shape[1]))
            x = np.hstack([x, padding])

    return float(phrr_model.predict(x)[0])


def predict_t5(p):
    """Predict T5% value"""
    vec = []
    for feat in t5_selected_features:
        if feat in p:
            val = p[feat]
        else:
            val = 0.0
        # Ensure PP is within reasonable range
        if feat == 'PP':
            val = max(PP_MIN, min(PP_MAX, val))
        vec.append(val)
    
    x = np.array([vec], dtype=np.float64)
    
    # Ensure feature count matches
    if x.shape[1] != t5_model.n_features_in_:
        if x.shape[1] > t5_model.n_features_in_:
            x = x[:, :t5_model.n_features_in_]
        else:
            padding = np.zeros((x.shape[0], t5_model.n_features_in_ - x.shape[1]))
            x = np.hstack([x, padding])
    
    return float(t5_model.predict(x)[0])


def check_formulation_constraints(p):
    """Check formulation constraints (total sum does not exceed 100)"""
    total = p.get('PAPP', 0) + p.get('MPP', 0) + p.get('ZS', 0) + p.get('W', 0) + ADP_FIXED
    return total <= 100


# ========== 5. Validation set prediction ==========
def validate_holdout():
    """Predict on held-out validation set"""
    if not os.path.exists(VALIDATION_INPUT_PATH):
        print(f"Validation file not found: {VALIDATION_INPUT_PATH}")
        return
    
    df = pd.read_excel(VALIDATION_INPUT_PATH)
    print(f"\nValidation set loaded: {len(df)} samples")
    
    results = []
    for idx, row in df.iterrows():
        # Build formulation dictionary
        p = {
            'PP': row.get('PP', 0),
            'PAPP': row.get('PAPP', 0),
            'MPP': row.get('MPP', 0),
            'ZS': row.get('ZS', 0),
            'W': row.get('W', 0),
            'ADP': row.get('ADP', ADP_FIXED)
        }
        
        # Predict
        try:
            phrr_pred = predict_phrr(p)
            t5_pred = predict_t5(p)
        except Exception as e:
            print(f"Error predicting sample {idx}: {e}")
            phrr_pred = np.nan
            t5_pred = np.nan
        
        # Get true values
        phrr_true = None
        for col in ['PHRR（Kw/m2）', 'PHRR(Kw/m2)', 'PHRR']:
            if col in row:
                phrr_true = row[col]
                break
        
        results.append({
            'ID': row.get('ID', row.get('编号', idx)),
            'PP': p['PP'],
            'PAPP': p['PAPP'],
            'MPP': p['MPP'],
            'ZS': p['ZS'],
            'W': p['W'],
            'ADP': p['ADP'],
            'True_PHRR': phrr_true,
            'Predicted_PHRR': phrr_pred,
            'Predicted_T5%': t5_pred,
            'PHRR_Relative_Error(%)': abs(phrr_pred - phrr_true) / phrr_true * 100 if phrr_true else np.nan
        })
    
    # Save results
    df_results = pd.DataFrame(results)
    df_results.to_csv(VALIDATION_PATH, index=False, encoding='utf-8-sig')
    print(f"Validation predictions saved to: {VALIDATION_PATH}")
    
    # Output statistics
    valid_errors = df_results['PHRR_Relative_Error(%)'].dropna()
    if len(valid_errors) > 0:
        print(f"Validation PHRR - Mean relative error: {valid_errors.mean():.2f}%")
        print(f"Validation PHRR - Max relative error: {valid_errors.max():.2f}%")


# ========== 6. Resuming function: load history ==========
def load_history():
    """Load historical results, supports resuming"""
    if not os.path.exists(RESULTS_PATH):
        return pd.DataFrame(), set()
    
    hist = pd.read_csv(RESULTS_PATH)
    # Use parameter tuple as unique key (rounded to 4 decimal places)
    param_keys = set()
    for _, row in hist.iterrows():
        tup = tuple(round(row[k], 4) for k in ['PP', 'PAPP', 'MPP', 'ZS', 'W'])
        param_keys.add(tup)
    
    print(f"Loaded {len(hist)} historical samples")
    return hist, param_keys


# ========== 7. Main optimization function ==========
def run_optimization(target_phrr, target_t5, max_evals):
    """
    Perform inverse design optimization
    Loss function: dimensionless sum of relative errors
    """
    global history_df, done_keys
    
    history_df, done_keys = load_history()
    new_results = []  # New results from this run
    already = len(history_df)
    need = max_evals - already
    
    if need <= 0:
        print(f"\nAlready evaluated {already} samples, no new evaluations needed.")
        # Return top 4 best from history
        history_df = pd.read_csv(RESULTS_PATH)
        history_df = history_df.drop_duplicates(subset=['PP', 'PAPP', 'MPP', 'ZS', 'W'])
        return history_df.nsmallest(4, 'loss').to_dict('records')
    
    print(f"\nNeed to evaluate {need} new samples (already have {already})")
    
    # Define search space
    space = {
        'PP': hp.uniform('PP', VARIABLE_RANGES['PP'][0], VARIABLE_RANGES['PP'][1]),
        'PAPP': hp.uniform('PAPP', VARIABLE_RANGES['PAPP'][0], VARIABLE_RANGES['PAPP'][1]),
        'MPP': hp.uniform('MPP', VARIABLE_RANGES['MPP'][0], VARIABLE_RANGES['MPP'][1]),
        'ZS': hp.uniform('ZS', VARIABLE_RANGES['ZS'][0], VARIABLE_RANGES['ZS'][1]),
        'W': hp.uniform('W', VARIABLE_RANGES['W'][0], VARIABLE_RANGES['W'][1])
    }
    
    def objective(opt):
        """Objective function: sum of relative errors (dimensionless)"""
        # Fast deduplication
        tup = tuple(round(opt[k], 4) for k in ['PP', 'PAPP', 'MPP', 'ZS', 'W'])
        if tup in done_keys:
            # Get loss from history
            row = history_df[
                (history_df['PP'].round(4) == tup[0]) &
                (history_df['PAPP'].round(4) == tup[1]) &
                (history_df['MPP'].round(4) == tup[2]) &
                (history_df['ZS'].round(4) == tup[3]) &
                (history_df['W'].round(4) == tup[4])
            ]
            if len(row) > 0:
                return {'loss': row.iloc[0]['loss'], 'status': STATUS_OK}
        
        # Check formulation sum constraint
        opt_sum = opt['PAPP'] + opt['MPP'] + opt['ZS'] + opt['W']
        if opt_sum + ADP_FIXED > 100:
            return {'loss': 9999.0, 'status': STATUS_OK}
        
        # Build complete formulation
        p = opt.copy()
        p['ADP'] = ADP_FIXED
        p['PP'] = max(PP_MIN, min(PP_MAX, p['PP']))
        
        try:
            # Predict
            phrr_pred = predict_phrr(p)
            t5_pred = predict_t5(p)
            
            # Loss function: sum of relative errors (dimensionless)
            # Note: avoid division by zero
            phrr_error = abs(phrr_pred - target_phrr) / max(target_phrr, 1e-6)
            t5_error = abs(t5_pred - target_t5) / max(target_t5, 1e-6)
            loss = phrr_error + t5_error
            
            # Record results
            record = {
                'PP': p['PP'],
                'PAPP': p['PAPP'],
                'MPP': p['MPP'],
                'ZS': p['ZS'],
                'W': p['W'],
                'ADP': p['ADP'],
                'phrr_pred': phrr_pred,
                't5_pred': t5_pred,
                'phrr_error': phrr_error,
                't5_error': t5_error,
                'loss': loss,
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            new_results.append(record)
            done_keys.add(tup)
            
            return {'loss': loss, 'status': STATUS_OK}
            
        except Exception as e:
            print(f"Error in objective: {e}")
            return {'loss': 9999.0, 'status': STATUS_OK}
    
    # Perform Bayesian optimization
    print("\nStarting Bayesian optimization...")
    fmin(
        fn=objective,
        space=space,
        algo=tpe.suggest,
        max_evals=need,
        trials=Trials(),
        show_progressbar=True
    )
    
    # Append new results to CSV
    if new_results:
        df_new = pd.DataFrame(new_results)
        df_new.to_csv(
            RESULTS_PATH,
            mode='a',
            header=not os.path.exists(RESULTS_PATH),
            index=False,
            encoding='utf-8-sig'
        )
        print(f"\nSaved {len(new_results)} new samples to {RESULTS_PATH}")
    
    # Reload full history, deduplicate and save to Excel
    history_df = pd.read_csv(RESULTS_PATH)
    history_df = history_df.drop_duplicates(subset=['PP', 'PAPP', 'MPP', 'ZS', 'W'])
    history_df = history_df.sort_values('loss')
    history_df.to_excel(RESULTS_XLSX, index=False)
    print(f"Full results saved to {RESULTS_XLSX}")
    
    # Return top 4 best formulations
    return history_df.head(4).to_dict('records')


# ========== 8. Main function ==========
def main():
    print('='*70)
    print('Inverse Design - Multi-Objective Optimization')
    print('Target: PHRR = 200 kW/m², T5% = 300 °C')
    print('Loss function: Relative error sum (dimensionless)')
    print('='*70)
    
    # Display constraints
    print(f'\nFormulation constraints:')
    print(f'  - PP: [{PP_MIN}, {PP_MAX}]')
    print(f'  - PAPP: [19, 24]')
    print(f'  - MPP: [8.5, 14]')
    print(f'  - ZS: [0.4, 1.6]')
    print(f'  - W: [2.5, 9]')
    print(f'  - ADP: {ADP_FIXED} (fixed)')
    print(f'  - Total composition (with ADP) ≤ 100')
    
    print(f'\nOptimization settings:')
    print(f'  - Target PHRR: {TARGET_PHRR} kW/m²')
    print(f'  - Target T5%: {TARGET_T5} °C')
    print(f'  - Max evaluations: {MAX_EVALS}')
    print(f'  - Loss function: |PHRR-{TARGET_PHRR}|/{TARGET_PHRR} + |T5%-{TARGET_T5}|/{TARGET_T5}')
    
    # Validation set prediction (optional)
    if os.path.exists(VALIDATION_INPUT_PATH):
        print('\n' + '-'*70)
        validate_holdout()
    
    # Perform optimization
    print('\n' + '-'*70)
    best_formulations = run_optimization(TARGET_PHRR, TARGET_T5, MAX_EVALS)
    
    # Output results
    print('\n' + '='*70)
    print('Top 4 Formulations (sorted by loss)')
    print('='*70)
    
    for i, sol in enumerate(best_formulations, 1):
        total_add = sol.get('PAPP', 0) + sol.get('MPP', 0) + sol.get('ZS', 0) + sol.get('W', 0)
        
        print(f'\nFormulation {i}:')
        print(f'  PP: {sol["PP"]:.2f}')
        print(f'  PAPP: {sol["PAPP"]:.2f}')
        print(f'  MPP: {sol["MPP"]:.2f}')
        print(f'  ZS: {sol["ZS"]:.2f}')
        print(f'  W: {sol["W"]:.2f}')
        print(f'  ADP: {ADP_FIXED:.2f}')
        print(f'  Total additives: {total_add:.2f}')
        print(f'  Total composition: {total_add + sol["PP"]:.2f}')
        print(f'  Predicted PHRR: {sol["phrr_pred"]:.1f} kW/m²')
        print(f'  Predicted T5%: {sol["t5_pred"]:.1f} °C')
        print(f'  Loss (relative error sum): {sol["loss"]:.4f}')
        print(f'    - PHRR relative error: {sol.get("phrr_error", sol["loss"]/2):.4f}')
        print(f'    - T5% relative error: {sol.get("t5_error", sol["loss"]/2):.4f}')
    
    print('\n' + '='*70)
    print('Optimization completed!')
    print(f'Output files:')
    print(f'  - {RESULTS_PATH} (CSV history, for resuming)')
    print(f'  - {RESULTS_XLSX} (Excel results)')
    if os.path.exists(VALIDATION_PATH):
        print(f'  - {VALIDATION_PATH} (validation predictions)')
    print('='*70)


if __name__ == '__main__':
    main()